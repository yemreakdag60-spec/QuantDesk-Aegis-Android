# QuantDesk Aegis FlowGuard V4.3.4 Compare

Side-by-side Android comparison edition of QuantDesk Aegis Pro (`com.quantdesk.aegis.flowguard.v434compare`).

## Runtime design

- Scans 200 Binance USD-M perpetual markets in the bundled UI.
- Reads 13 chart timeframes from 1 minute through 24 hours.
- Keeps a foreground service alive for background market collection.
- Tracks depth and liquidations for the 50 highest-volume USDT perpetuals in the Android foreground service, matching the PRO candidate count.
- Reads the latest 1,000 Binance aggregate trades on demand and combines them with the native 15-minute depth window.
- Stores one-minute depth pressure, separate long/short liquidations, cancellation anomalies, freshness, and sample quality in local SQLite.
- Calibrates reachable TP levels from rolling 1m/5m/15m favorable excursions and nearby market barriers.
- Calibrates SL distance from adverse excursions and structure, then learns with bounded weight from resolved on-device signals.
- Uses order-flow in the final score only when freshness and quality thresholds pass; strong contrary flow can veto a signal.
- Retains seven days of aggregated order-flow data and reconnects automatically.
- Starts after device reboot or application update.
- Uses no API key and does not submit orders.

Android may stop background collection if the user force-stops the app or restricts its battery use. Set battery usage to unrestricted for continuous collection.

## APK

The GitHub Actions workflow builds a debug-signed installable APK and publishes it as the `QuantDesk-Aegis-FlowGuard-V4.3.4-Compare` workflow artifact.
