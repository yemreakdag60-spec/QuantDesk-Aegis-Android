# QuantDesk Aegis V4.7.0 Professional

- Binance Spot ve USDⓈ-M Futures için ayrı analiz modları.
- Spot modunda spot kline, ticker, order book ve aggTrade kullanılır; funding, open interest, long/short hesap oranları, tasfiye ve kaldıraç uygulanmaz.
- Evren, seçili piyasa türünde USDT kotasyonlu ve işlemde olan en yüksek 200 parite/sözleşmeden oluşur; 24 saatlik quote hacmine göre sıralanır.
- BTC rejimi ve çoklu zaman dilimi uyumu ayrı gösterilir. Spot/Futures aynı varlık için birbirine karıştırılmaz.
- PRO kartlarında 15 dakikalık OHLC ve hacim grafiği vardır.
- TP1 yalnız en az 20 tarihsel pencere ve en az %35 stop-öncelikli hedef erişimi varsa görünür. TP2 eşiği %35, TP3 eşiği %25 ve ikisi için de asgari 20 örnektir. Stop ve hedefin aynı mumda görülmesi stop önce olmuş gibi sayılır.
- Tarihsel erişim oranları garanti ya da gelecekteki kazanma olasılığı değildir. Pencereler örtüşebilir ve aynı tarihsel fiyat serisinden türetilir.
- Spot modunda Futures arka plan order-flow kaydı giriş onayı olarak kullanılmaz; otomatik emir gönderilmez.
- GitHub Actions workflow, kaynak sürümünü, UI kontrollerini, stop-öncelikli TP senaryolarını, debug APK derlemesini ve Android lint kapısını 4.7.0 olarak doğrular.
