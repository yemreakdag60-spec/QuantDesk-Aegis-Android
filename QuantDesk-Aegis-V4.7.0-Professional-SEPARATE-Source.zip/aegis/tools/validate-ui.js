const fs = require('fs');
const vm = require('vm');

const file = 'app/src/main/assets/index.html';
const html = fs.readFileSync(file, 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/);

if (!script) throw new Error('Bundled UI script was not found');
new vm.Script(script[1], { filename: file });

const ids = [...html.matchAll(/\sid="([^"]+)"/g)].map((match) => match[1]);
const duplicates = ids.filter((id, index) => ids.indexOf(id) !== index);
if (duplicates.length) throw new Error(`Duplicate HTML IDs: ${[...new Set(duplicates)].join(', ')}`);

const referencedIds = [...script[1].matchAll(/\$\('#([^']+)'\)/g)].map((match) => match[1]);
const missing = referencedIds.filter((id) => !ids.includes(id));
if (missing.length) throw new Error(`Missing HTML IDs: ${[...new Set(missing)].join(', ')}`);

for (const name of [
  'klines', 'isActionable', 'isLiveNear', 'refreshLiveSignals', 'riskCalc',
  'shouldRevalidateLive', 'selectProCandidates', 'pushNativeWatchlist',
  'signalMaxAgeMs', 'flowReadyForSignal', 'liveDiagnostics'
]) {
  const count = (script[1].match(new RegExp(`function\\s+${name}\\b`, 'g')) || []).length;
  if (count !== 1) throw new Error(`${name} definition count is ${count}, expected 1`);
}

for (const required of ['Net R/R TP1', 'Net R/R TP2', 'Net R/R TP3', 'Adaptif Stop Loss']) {
  if (!html.includes(required)) throw new Error(`Required TP/SL field is missing: ${required}`);
}

const professionalInvariants = [
  'PRO_LIQUID_COUNT=30',
  'PRO_TECH_COUNT=20',
  'LIVE_INITIAL_LIMIT=26',
  'LIVE_REFRESH_BATCH=10',
  'LIVE_REFRESH_MS=15000',
  'MIN_FLOW_QUALITY=50',
  'MAX_SIGNAL_AGE_MS=180000',
  'flowReadyForSignal(r)',
  "flowPending?'AKIŞ ISINIYOR'",
  'pushNativeWatchlist(candidates)',
  'coverageMinutes>=1',
  'f.depthSamples>=45'
];
for (const invariant of professionalInvariants) {
  if (!script[1].includes(invariant)) throw new Error(`Professional live-engine invariant missing: ${invariant}`);
}

const forbiddenLegacyPatterns = [
  'slice(0,18)',
  "hard.push('doğrulanmış order-flow hazır değil')",
  'setInterval(refreshLiveSignals,20000)',
  'SIGNAL_MAX_AGE_MS=90000',
  "filter(r=>r.validated&&(r.now||r.nearEntry)"
];
for (const legacy of forbiddenLegacyPatterns) {
  if (script[1].includes(legacy)) throw new Error(`Legacy live-engine behavior still present: ${legacy}`);
}


for (const invariant of [
  'v.length-2',
  'priorTargetTouch(r,agg,A,levels.anchorTs)',
  "targetIssuedAt:Date.now()",
  "net R/R / hedef erişimi yetersiz",
  "hacim ciddi zayıf"
]) {
  if (!script[1].includes(invariant)) throw new Error(`V4.6 live-engine invariant missing: ${invariant}`);
}


for (const invariant of [
  "qd_aegis_v470_market",
  "https://api.binance.com/api/v3/",
  "getJSON(`${API}/fapi/v1/aggTrades?symbol=${q}&limit=1000`",
  "if(spotMode()){let [depth,agg]",
  "Funding / Açık Pozisyon",
  "r.tp1Eligible",
  "tp2Stats.reachRate>=35",
  "tp3Stats.reachRate>=25",
  "let stopped=adv>=stopAtr",
  "15 MIN • OHLC + HACİM"
]) {
  if (!html.includes(invariant)) throw new Error(`Market-mode / target-quality invariant missing: ${invariant}`);
}

if (html.includes('<option>MEXC</option>')) {
  throw new Error('UI must not imply a MEXC feed when the market-data source is Binance');
}

console.log('Bundled UI validation passed');
