QUANTDESK AEGIS V4.7.0 PROFESSIONAL — AYRI KURULUM

Paket adı: com.quantdesk.aegis.professional.v470
V4.4, V4.5 ve V4.6 ile yan yana kurulabilir.


V4.7.0 İYİLEŞTİRMELER
- Binance USDⓈ-M Futures ve Binance Spot için ayrı piyasa modu eklendi. Spot modunda yalnız Spot mum, ticker, order-book ve aggTrade verisi kullanılır; funding, açık pozisyon, long/short hesap oranları, tasfiye ve kaldıraç gösterilmez.
- İlk 200 USDT paritesi veya perpetual sözleşmesi 24 saatlik quote hacmine göre taranır.
- PRO adaylarda 15 dakikalık mum ve hacim grafiği gösterilir.
- TP1 yalnız stop-öncelikli tarihsel erişim örneği en az 20 pencere ve %35 temas eşiğini karşılarsa hedef olarak gösterilir. TP2 için en az 20 pencere ve %35; TP3 için en az 20 pencere ve %25 tarihsel temas gerekir. Stop ve hedef aynı mumda görülürse stop önce olmuş sayılır. Eşik altındaki uzak TP kademeleri gösterilmez.
- TP geçmiş erişim oranı gerçek kazanma olasılığı değildir; tarihsel, örtüşen pencerelere dayanır.
- Spot modunda canlı “Şimdi Gir” sinyali ve Futures kaynaklı order-flow doğrulaması kapalıdır; pozisyon boyutu hesabı yalnız uygun TP1 ve taze hedefle gösterilir. Uygulama emir göndermez.
- GitHub Actions sürüm kontrolü 4.7.0 ile hizalandı.
