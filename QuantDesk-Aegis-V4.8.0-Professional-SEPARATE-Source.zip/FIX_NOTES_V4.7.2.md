## V4.7.2 düzeltmesi

- TP2/TP3 tarihsel erişim koşullarını geçmediğinde `null` bırakılır. Seviye bütünlüğü doğrulaması opsiyonel TP seviyelerini artık yalnızca mevcut olduklarında kontrol eder; ulaşılabilir TP1 planı bu nedenle yapısal hata sayılmaz. Erişilebilir olmayan hedefleri zorla eklemez.

# QuantDesk Aegis V4.7.2 Professional

- Binance Spot ve USDⓈ-M Futures için ayrı analiz modları.
- Spot modunda spot kline, ticker, order book ve aggTrade kullanılır; funding, open interest, long/short hesap oranları, tasfiye ve kaldıraç uygulanmaz.
- Evren, seçili piyasa türünde USDT kotasyonlu ve işlemde olan en yüksek 200 parite/sözleşmeden oluşur; 24 saatlik quote hacmine göre sıralanır.
- BTC rejimi ve çoklu zaman dilimi uyumu ayrı gösterilir. Spot/Futures aynı varlık için birbirine karıştırılmaz.
- PRO kartlarında 15 dakikalık OHLC ve hacim grafiği vardır.
- TP1 yalnız en az 20 tarihsel pencere ve en az %35 stop-öncelikli hedef erişimi varsa görünür. TP2 eşiği %35, TP3 eşiği %25 ve ikisi için de asgari 20 örnektir. Stop ve hedefin aynı mumda görülmesi stop önce olmuş gibi sayılır.
- Tarihsel erişim oranları garanti ya da gelecekteki kazanma olasılığı değildir. Pencereler örtüşebilir ve aynı tarihsel fiyat serisinden türetilir.
- Spot modunda Futures arka plan order-flow kaydı giriş onayı olarak kullanılmaz; otomatik emir gönderilmez.
- Spot canlı adayları Binance Spot aggTrade ve order-book verisiyle yeniden doğrulanır; Futures order-flow veya türev metrikleri Spot kararına sızmaz. Spot'ta yeterli ve taze akış verisi yoksa aday bekletilir.
- Önceki akış Spot'ta canlı doğrulama adımını atladığı için hiçbir Spot kartı canlı giriş adayı olamıyordu; bu akış artık Spot modunda da çalışır.
- GitHub Actions workflow, kaynak sürümünü, UI kontrollerini, stop-öncelikli TP senaryolarını, debug APK derlemesini ve Android lint kapısını 4.7.2 olarak doğrular.
- “Canlı Fırsatlar” filtresi boş kaldığında en güçlü beş PRO izleme adayını ve elenme/bekleme nedenini gösterir; izleme satırları işlem sinyali olarak etiketlenmez.
- PRO veri çağrıları başarısız olursa hata sayısı ve son istek hatası tarama durumunda görünür.
- Android lint temizliği: minSdk 26 için gereksiz Android O öncesi servis kontrolü kaldırıldı.
