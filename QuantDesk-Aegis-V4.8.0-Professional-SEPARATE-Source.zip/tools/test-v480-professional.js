const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const mainActivity = fs.readFileSync('app/src/main/java/com/quantdesk/aegis/MainActivity.java', 'utf8');
const lines = html.split(/\r?\n/);
const functionLine = (name) => {
  const line = lines.find((x) => x.startsWith(`function ${name}(`));
  if (!line) throw new Error(`${name} was not found`);
  return line;
};

const gateContext = { Number, Math, clamp: (x, a, b) => Math.max(a, Math.min(b, x)) };
vm.createContext(gateContext);
vm.runInContext(functionLine('targetGate'), gateContext);
if (gateContext.targetGate({ n: 114, reachRate: 58 }, 0.34).eligible) {
  throw new Error('High touch rate with negative cost-adjusted expectancy must not publish TP1');
}
if (gateContext.targetGate({ n: 114, reachRate: 64 }, 0.90).eligible !== true) {
  throw new Error('A sufficiently sampled, positive-expectancy target should be publishable');
}

for (const tf of ['1m','3m','5m','10m','15m','20m','25m','30m','45m','1h','2h','3h','4h','6h','12h','24h']) {
  if (!html.includes(`'${tf}'`)) throw new Error(`Required timeframe is missing: ${tf}`);
}

for (const text of [
  'BTC bağı yetersiz',
  'BTC yönü güçlü ters',
  'function btcTradeGate(',
  'PRO_BTC_COUNT=15',
  'if(!tp1Eligible){tp2=null;tp3=null;rr2=null;rr3=null}',
  'MIN_LIVE_WATCH=2',
  'işlem sinyali değil',
  'Azami marjin kullanımı %',
  'v480-context'
]) {
  if (!html.includes(text)) throw new Error(`Professional behavior is missing: ${text}`);
}

for (const text of ['function notifyNewActionables(', 'qd_v480_notified', 'AegisNative.notifySignal']) {
  if (!html.includes(text)) throw new Error(`Live notification behavior is missing: ${text}`);
}
for (const text of ['notifySignal(String symbol', 'IMPORTANCE_HIGH', 'setOnlyAlertOnce(true)']) {
  if (!mainActivity.includes(text)) throw new Error(`Native live notification bridge is missing: ${text}`);
}

if (html.includes('Günlük zarar uyarısı %')) {
  throw new Error('The UI must not imply automatic daily-loss monitoring');
}

console.log('V4.8 BTC, timeframe, TP publication, live-watch and risk-plan invariants passed');
