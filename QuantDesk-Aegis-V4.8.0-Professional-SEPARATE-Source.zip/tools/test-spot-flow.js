const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const lines = html.split(/\r?\n/);
const depthLine = lines.find((line) => line.startsWith('function depthStats('));
const flowLine = lines.find((line) => line.startsWith('function spotFlowMetrics('));
if (!depthLine || !flowLine) throw new Error('Spot flow validation functions were not found');
const context = { clamp: (x, a, b) => Math.max(a, Math.min(b, x)) };
vm.createContext(context);
vm.runInContext(`${depthLine}\n${flowLine}`, context);

const now = Date.now();
const trades = Array.from({ length: 100 }, (_, i) => ({
  T: now - 20000 + i * 190,
  p: '100', q: '1', m: i % 3 === 0
}));
const book = {
  bids: [['99.99', '10'], ['99.98', '8']],
  asks: [['100.01', '5'], ['100.02', '4']]
};
const ready = context.spotFlowMetrics(trades, book);
if (!ready.ready || ready.quality < 50 || ready.trades !== 100) {
  throw new Error('Fresh, adequately sampled Spot flow should pass the flow-quality gate');
}
const burst = context.spotFlowMetrics(Array.from({ length: 1000 }, (_, i) => ({ T: now - 2500 + i * 2, p: '100', q: '1', m: i % 3 === 0 })), book);
if (!burst.ready) throw new Error('A fresh high-throughput Spot trade window should not be rejected just because it spans fewer than five seconds');
const stale = context.spotFlowMetrics(trades.map((x) => ({ ...x, T: now - 30000 })), book);
if (stale.ready) throw new Error('Stale Spot aggTrade data must not pass live validation');
console.log('Spot live-flow freshness and quality scenarios passed');
