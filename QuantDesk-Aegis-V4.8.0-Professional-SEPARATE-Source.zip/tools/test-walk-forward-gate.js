const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const line = html.split(/\r?\n/).find((x) => x.startsWith('function walkForwardCheck('));
if (!line) throw new Error('Walk-forward policy was not found');

const context = { Number, clamp: (x, lo, hi) => Math.max(lo, Math.min(hi, x)) };
vm.createContext(context);
vm.runInContext(line, context);

const thinSample = context.walkForwardCheck({ n: 11, rate: 0 });
if (thinSample.penalty !== 0 || thinSample.hard) throw new Error('An undersized walk-forward sample must not veto a setup');

const weak = context.walkForwardCheck({ n: 18, rate: 42 });
if (weak.hard || !(weak.penalty > 0 && weak.penalty < 12)) throw new Error('Moderately weak walk-forward evidence should reduce score, not hard-block');

const severe = context.walkForwardCheck({ n: 35, rate: 24 });
if (!severe.hard) throw new Error('A sufficiently large, severely underperforming sample must remain a hard veto');

const borderline = context.walkForwardCheck({ n: 35, rate: 32 });
if (borderline.hard) throw new Error('A poor but non-catastrophic walk-forward result should be a score penalty');

console.log('Walk-forward sample-size and severity gate scenarios passed');
