const fs = require('fs');
const vm = require('vm');

const file = 'app/src/main/assets/index.html';
const html = fs.readFileSync(file, 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/);

if (!script) throw new Error('Bundled UI script was not found');
new vm.Script(script[1], { filename: file });

const ids = [...html.matchAll(/\sid="([^"]+)"/g)].map((match) => match[1]);
const duplicates = ids.filter((id, index) => ids.indexOf(id) !== index);
if (duplicates.length) throw new Error(`Duplicate HTML IDs: ${[...new Set(duplicates)].join(', ')}`);

const referencedIds = [...script[1].matchAll(/\$\('#([^']+)'\)/g)].map((match) => match[1]);
const missing = referencedIds.filter((id) => !ids.includes(id));
if (missing.length) throw new Error(`Missing HTML IDs: ${[...new Set(missing)].join(', ')}`);

for (const name of [
  'klines', 'isActionable', 'isLiveNear', 'refreshLiveSignals', 'riskCalc', 'optionalTargetValid',
  'shouldRevalidateLive', 'selectProCandidates', 'pushNativeWatchlist',
  'signalMaxAgeMs', 'flowReadyForSignal', 'liveDiagnostics', 'liveWatchRows', 'validTradePlanForSize', 'canCalculatePositionSize'
]) {
  const count = (script[1].match(new RegExp(`function\\s+${name}\\b`, 'g')) || []).length;
  if (count !== 1) throw new Error(`${name} definition count is ${count}, expected 1`);
}

for (const required of ['Net R/R TP1', 'Net R/R TP2', 'Net R/R TP3', 'Adaptif Stop Loss']) {
  if (!html.includes(required)) throw new Error(`Required TP/SL field is missing: ${required}`);
}

const professionalInvariants = [
  'PRO_LIQUID_COUNT=20',
  'PRO_BTC_COUNT=15',
  'PRO_TECH_COUNT=15',
  'MIN_LIVE_WATCH=2',
  'LIVE_INITIAL_LIMIT=30',
  'LIVE_REFRESH_BATCH=12',
  'LIVE_REFRESH_MS=15000',
  'MIN_FLOW_QUALITY=50',
  'MAX_STRETCH_ATR=2.0',
  'if(stretchAtr>MAX_STRETCH_ATR)',
  'MAX_SIGNAL_AGE_MS=180000',
  'flowReadyForSignal(r)',
  "flowPending?'AKIŞ ISINIYOR'",
  'pushNativeWatchlist(candidates)',
  'coverageMinutes>=1',
  'f.depthSamples>=45'
];
for (const invariant of professionalInvariants) {
  if (!script[1].includes(invariant)) throw new Error(`Professional live-engine invariant missing: ${invariant}`);
}

const forbiddenLegacyPatterns = [
  'slice(0,18)',
  "hard.push('doğrulanmış order-flow hazır değil')",
  'setInterval(refreshLiveSignals,20000)',
  'SIGNAL_MAX_AGE_MS=90000',
  "filter(r=>r.validated&&(r.now||r.nearEntry)"
];
for (const legacy of forbiddenLegacyPatterns) {
  if (script[1].includes(legacy)) throw new Error(`Legacy live-engine behavior still present: ${legacy}`);
}


for (const invariant of [
  'v.length-1',
  'priorTargetTouch(r,agg,A,levels.anchorTs)',
  "targetIssuedAt:Date.now()",
  "net R/R / hedef erişimi yetersiz",
  "hacim ciddi zayıf"
]) {
  if (!script[1].includes(invariant)) throw new Error(`V4.6 live-engine invariant missing: ${invariant}`);
}


for (const invariant of [
  "qd_aegis_v480_market",
  "https://api.binance.com/api/v3/",
  "getJSON(`${API}/fapi/v1/aggTrades?symbol=${q}&limit=1000`",
  "if(spotMode()){let [depth,agg]",
  "function spotFlowMetrics(agg,depth)",
  "flowData=spotMode()?spotFlowMetrics(agg,liveDepth):verifiedFlow(r.symbol,agg)",
  "function shouldRevalidateLive(r){if(!r||!r.pro||r.dir==='BEKLE')return false;",
  "await revalidateActionables(gen);if(gen!==scanGeneration)return;",
  "proErrors++;lastProError=String(e&&e.message||e)",
  "CANLI İZLE",
  "Funding / Açık Pozisyon",
  "r.tp1Eligible",
  "tp2Stats.reachRate>=35",
  "tp3Stats.reachRate>=25",
  "let stopped=adv>=stopAtr",
  "15 DK • KAPANMIŞ MUM + HACİM"
]) {
  if (!html.includes(invariant)) throw new Error(`Market-mode / target-quality invariant missing: ${invariant}`);
}

const nativeActivity = fs.readFileSync('app/src/main/java/com/quantdesk/aegis/MainActivity.java', 'utf8');
if (!nativeActivity.includes('startForegroundService(update);')) throw new Error('Foreground service bridge call is missing');
if (nativeActivity.includes('if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(update); else startService(update);')) throw new Error('Obsolete API 26 branch triggers Android Lint');
if (!nativeActivity.includes('WebViewAssetLoader') || !nativeActivity.includes('setAllowUniversalAccessFromFileURLs(false)') || nativeActivity.includes('setAllowUniversalAccessFromFileURLs(true)')) throw new Error('WebView bundled content must use the secure asset loader');
if (!nativeActivity.includes('https://appassets.androidplatform.net/assets/index.html') || nativeActivity.includes('file:///android_asset/index.html')) throw new Error('Bundled UI must load from the appassets origin');
if (!html.includes('BTC Yönü') || !html.includes('İŞLEME HAZIR') || !html.includes('canCalculatePositionSize(r)')) throw new Error('Trade direction, status, or strict size eligibility is missing');

for (const invariant of [
  "['1m','3m','5m','10m','15m','20m','25m','30m','45m','1h','2h','3h','4h','6h','12h','24h']",
  "BTC bağı yetersiz",
  "BTC yönü güçlü ters",
  "function targetGate(stats,rr)",
  "if(!tp1Eligible){tp2=null;tp3=null;rr2=null;rr3=null}",
  "function refreshWatchShelf(base)",
  "function professionalCard(r,idx)",
  "qd_v480_journal",
  "v480-context",
  "maxMarginPct"
]) {
  if (!html.includes(invariant)) throw new Error(`V4.8 professional invariant missing: ${invariant}`);
}

if (html.includes('<option>MEXC</option>')) {
  throw new Error('UI must not imply a MEXC feed when the market-data source is Binance');
}

console.log('Bundled UI validation passed');
