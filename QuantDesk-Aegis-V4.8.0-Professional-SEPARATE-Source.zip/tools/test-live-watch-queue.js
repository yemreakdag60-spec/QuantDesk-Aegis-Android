const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const line = html.split(/\r?\n/).find((x) => x.startsWith('function liveWatchRows('));
if (!line) throw new Error('Live watch queue renderer was not found');
const context = {
  isActionable: () => false,
  isLiveNear: () => false,
  shouldRevalidateLive: (r) => !!r.flowPending || !!r.validated,
  Math
};
vm.createContext(context);
vm.runInContext(line, context);
const htmlOut = context.liveWatchRows([
  { pro: true, symbol: 'BTCUSDT', dir: 'SHORT', entryScore: 63, validated: true, hardBlocks: ['net R/R yetersiz'], quoteVolume: 10 },
  { pro: true, symbol: 'ETHUSDT', dir: 'LONG', entryScore: 59, flowPending: true, hardBlocks: [], quoteVolume: 9 }
]);
if (!htmlOut.includes('BTCUSDT') || !htmlOut.includes('ETHUSDT')) {
  throw new Error('Non-actionable PRO candidates should remain visible in the live watch queue');
}
if (!htmlOut.includes('işlem sinyali değildir') || !htmlOut.includes('net R/R yetersiz')) {
  throw new Error('Watch candidates must be clearly distinguished from confirmed trade signals and show blockers');
}
console.log('Live watch queue shows blocked candidates without treating them as entries');
