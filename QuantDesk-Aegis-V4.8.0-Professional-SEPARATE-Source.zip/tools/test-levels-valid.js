const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const lines = html.split(/\r?\n/);
const optionalLine = lines.find((line) => line.startsWith('function optionalTargetValid('));
const validLine = lines.find((line) => line.startsWith('function levelsValid('));
if (!optionalLine || !validLine) throw new Error('Level validation functions were not found');
const context = { isFinite: Number.isFinite };
vm.createContext(context);
vm.runInContext(`${optionalLine}\n${validLine}`, context);

const tp1OnlyLong = { entry1: 100, entry2: 101, sl: 98, tp1: 104, tp2: null, tp3: null, rr1: 1.4, rr2: null, rr3: null };
const tp1Tp2Long = { ...tp1OnlyLong, tp2: 106, rr2: 2 };
const tp1Tp2Tp3Short = { entry1: 99, entry2: 100, sl: 102, tp1: 96, tp2: 94, tp3: 92, rr1: 1.4, rr2: 2, rr3: 2.7 };
if (!context.levelsValid('LONG', tp1OnlyLong)) throw new Error('A valid TP1-only plan must pass when unreachable TP2/TP3 are omitted');
if (!context.levelsValid('LONG', tp1Tp2Long)) throw new Error('A valid plan with a reachable TP2 and omitted TP3 must pass');
if (!context.levelsValid('SHORT', tp1Tp2Tp3Short)) throw new Error('A valid short plan with ordered targets must pass');
if (context.levelsValid('LONG', { ...tp1OnlyLong, tp2: 106, rr2: null })) throw new Error('A target without its R/R must fail');
if (context.levelsValid('LONG', { ...tp1OnlyLong, tp3: 107, rr3: 2 })) throw new Error('TP3 without TP2 must fail');
if (context.levelsValid('LONG', { ...tp1Tp2Long, tp2: 103 })) throw new Error('A TP2 inside/before TP1 must fail');
if (context.levelsValid('SHORT', { ...tp1Tp2Tp3Short, tp3: 95 })) throw new Error('A TP3 ordered incorrectly for a short must fail');
console.log('Optional reachable TP level validation scenarios passed');
