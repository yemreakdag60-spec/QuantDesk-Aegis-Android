const fs = require('fs');
const vm = require('vm');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const line = html.split(/\r?\n/).find((x) => x.startsWith('function miniChart('));
if (!line) throw new Error('15-minute chart renderer is missing');
const context = { Math, Number, fmt: (x) => Number(x).toFixed(2) };
vm.createContext(context);
vm.runInContext(line, context);
const candles = Array.from({ length: 32 }, (_, i) => 100 + i * 0.1);
const data = { o: candles, h: candles.map((x) => x + 0.5), l: candles.map((x) => x - 0.5), c: candles.map((x) => x + 0.1), v: candles.map((_, i) => i + 1) };
const r = { pro: true, chart15: data, entry1: 102, entry2: 103, sl: 99, tp1: 106, tp1Eligible: false, price: 103.2 };
const rejected = context.miniChart(r, 0);
for (const x of ['15 DK • KAPANMIŞ MUM + HACİM', 'O 103.10', 'H 103.60', 'L 102.60', 'C 103.20', 'Hacim 32.00 (coin)', 'TP1 uygun değil', 'Son fiyat']) {
  if (!rejected.includes(x)) throw new Error(`Chart should disclose ${x}`);
}
if (rejected.includes('class="tpmark">TP1</span>')) throw new Error('Rejected TP1 must not be drawn as a qualified target');
const qualified = context.miniChart({ ...r, tp1Eligible: true }, 0);
if (!qualified.includes('class="tpmark">TP1</span>')) throw new Error('Qualified TP1 should be marked on the chart');
console.log('Trade chart shows closed-candle OHLCV and only marks a qualified TP1');
