const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const lines = html.split(/\r?\n/);
const atrLine = lines.find((x) => x.startsWith('function atrSeries('));
const supertrendLine = lines.find((x) => x.startsWith('function supertrendDirection('));
const adxLine = lines.find((x) => x.startsWith('function adx('));
if (!atrLine || !supertrendLine || !adxLine) throw new Error('ATR/ADX/Supertrend calculation was not found');

const context = {
  avg: (a) => a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0,
  last: (a) => a && a.length ? a[a.length - 1] : 0,
};
vm.createContext(context);
vm.runInContext(`${atrLine}\n${supertrendLine}\n${adxLine}`, context);

const close = [10, 11, 12, 13];
const high = [11, 12, 13, 14];
const low = [9, 10, 11, 12];
const atr = context.atrSeries(high, low, close, 2);
if (Math.abs(atr[1] - 2) > 1e-9 || Math.abs(atr[2] - 2) > 1e-9 || Math.abs(atr[3] - 2) > 1e-9) {
  throw new Error('Wilder RMA ATR must keep a constant true range stable');
}

const rising = Array.from({ length: 80 }, (_, i) => 100 + i);
const falling = rising.map((_, i) => i < 55 ? 100 + i : 155 - (i - 55) * 2);
const makeBands = (c) => ({ c, h: c.map((x) => x + 1), l: c.map((x) => x - 1) });
const up = makeBands(rising);
const down = makeBands(falling);
if (context.supertrendDirection(up.h, up.l, up.c, 10, 3) !== 1) throw new Error('Supertrend should identify a sustained rising trend');
if (context.supertrendDirection(down.h, down.l, down.c, 10, 3) !== -1) throw new Error('Supertrend should flip after a sustained decline');

const flat = Array(50).fill(100);
const flatHigh = Array(50).fill(101);
const flatLow = Array(50).fill(99);
const trend = Array.from({ length: 50 }, (_, i) => 100 + i);
const trendHigh = trend.map((x) => x + 1);
const trendLow = trend.map((x) => x - 1);
if (Math.abs(context.adx(trendHigh, trendLow, trend, 14) - 100) > 1e-9) throw new Error('Wilder ADX should show strong, consistent directional movement');
if (Math.abs(context.adx(flatHigh, flatLow, flat, 14)) > 1e-9) throw new Error('Wilder ADX should stay near zero in a directionless flat market');

console.log('Wilder ATR/ADX and Supertrend direction scenarios passed');
