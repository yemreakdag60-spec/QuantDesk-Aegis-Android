const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const line = html.split(/\r?\n/).find((x) => x.startsWith('function chooseTargetCandidate('));
if (!line) throw new Error('Target candidate selector was not found');

const context = {};
vm.createContext(context);
vm.runInContext(line, context);

const candidates = [
  { price: 101, type: 'near, weak R/R' },
  { price: 102, type: 'farther, qualified' },
  { price: 103, type: 'farther, weak reach' },
];
const metrics = {
  'near, weak R/R': { eligible: false, rr: 0.31, reach: 72 },
  'farther, qualified': { eligible: true, rr: 0.74, reach: 58 },
  'farther, weak reach': { eligible: false, rr: 1.1, reach: 29 },
};
const selected = context.chooseTargetCandidate(candidates, 'LONG', 100, 0.2, (x) => metrics[x.type]);
if (!selected || selected.candidate.type !== 'farther, qualified') {
  throw new Error('A nearby weak-R/R target must not hide a farther reachable, qualified target');
}

const noneQualified = context.chooseTargetCandidate(candidates, 'LONG', 100, 0.2, (x) => ({ ...metrics[x.type], eligible: false }));
if (!noneQualified || noneQualified.candidate.type !== 'near, weak R/R' || noneQualified.plan.eligible) {
  throw new Error('When no target qualifies, preserve a diagnostic candidate without marking it eligible');
}

console.log('Reachable target selection scenarios passed');
