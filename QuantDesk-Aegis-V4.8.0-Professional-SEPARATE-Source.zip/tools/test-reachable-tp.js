const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const lines = html.split(/\r?\n/);
const parseLine = lines.find((line) => line.startsWith('function parseK('));
const targetLine = lines.find((line) => line.startsWith('function targetPathStats('));
if (!parseLine || !targetLine) throw new Error('Target validation functions were not found');

const context = {};
vm.createContext(context);
vm.runInContext(`${parseLine}\n${targetLine}`, context);

function candles(hitBeforeStop) {
  return Array.from({ length: 80 }, (_, i) => {
    const hit = i >= 21;
    const open = 100;
    const high = hit ? 101 : 100.1;
    const low = hit && !hitBeforeStop ? 99.9 : hit ? 98.8 : 99.9;
    return [i * 60000, open, high, low, 100, 10, 0, 0, 0, 5];
  });
}

const sets = (bars) => ({ '1m': bars, '5m': bars, '15m': bars });
const targetFirst = context.targetPathStats(sets(candles(false)), 'LONG', 1, 0.5, 1.1);
const stopFirst = context.targetPathStats(sets(candles(true)), 'LONG', 1, 0.5, 1.1);
if (targetFirst.n <= 0 || targetFirst.hits <= 0 || targetFirst.reachRate <= 0) {
  throw new Error('A target touched before the stop should count as reachable');
}
if (stopFirst.n <= 0 || stopFirst.hits !== 0 || stopFirst.reachRate !== 0) {
  throw new Error('A same-candle target/stop collision must conservatively count as stop first');
}
console.log('Reachable TP stop-first scenarios passed');
