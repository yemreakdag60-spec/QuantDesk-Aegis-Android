# QuantDesk Aegis V4.8.0 Professional

Android decision-support scanner for Binance USDⓈ-M Futures and Spot. It scans 200 USDT pairs, evaluates 16 unique timeframes, applies BTC regime/correlation, liquidity, reachable-target, cost, freshness and live order-flow gates, and publishes a plan only when every required check passes.

- Separate install package: `com.quantdesk.aegis.professional.v480`.
- Existing V4.7.4 remains installed.
- No exchange credentials and no order execution.
- No forced signals: when no plan qualifies, Live Opportunities shows clearly labelled watch candidates.
- TP2/TP3 are never published without a qualified TP1.
- Contextual on-device learning cannot override hard safety gates.

See `FIX_NOTES_V4.8.0.md` and `RESEARCH_NOTES_V4.8.0.md`.

## Verification

```bash
for f in tools/validate-ui.js tools/test-*.js; do node "$f"; done
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
```

GitHub Actions installs Java and Gradle, runs all source/UI invariants, builds the debug APK and enforces Android Lint.
