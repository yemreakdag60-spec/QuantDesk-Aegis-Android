# QuantDesk Aegis V4.4.0 - Toplu Düzeltme Notları

Bu paket, GitHub Actions Lint raporundaki 4 hata ve 13 uyarıya göre düzenlenmiştir.

- Java kaynakları bildirilen `com.quantdesk.aegis` paketiyle aynı dizin yapısına taşındı.
- Manifest içindeki Activity/Service/Receiver sınıfları tam paket adıyla tanımlandı.
- Geri gezinme AndroidX `OnBackPressedDispatcher` yapısına geçirildi.
- Periyodik görevler `scheduleWithFixedDelay` ile Android süreç davranışına uygun hale getirildi.
- BootReceiver yalnızca beklenen sistem yayınlarını kabul edecek şekilde doğrulandı.
- minSdk 26 nedeniyle gereksiz API seviye kontrolleri kaldırıldı.
- Android 12+ data extraction ve Android 11- backup kuralları eklendi; uygulama verisi yedekleme dışı tutuldu.
- Gereksiz `screenOrientation="unspecified"` kaldırıldı.
- AndroidX Activity 1.13.0 ve OkHttp 5.5.0 kullanıldı.
- Lint uyarıları hata kabul edilir (`warningsAsErrors=true`); yalnızca mevcut AGP 8.13.x / API 36 araç zinciriyle kasıtlı uyumluluk nedeniyle `OldTargetApi` denetimi devre dışı bırakılmıştır.

Not: API 37'ye geçiş, AGP 9.x + Gradle 9.x ile CI araç zincirinin birlikte yükseltilmesini gerektirir; mevcut GitHub Actions akışının Gradle 8.13 uyumluluğunu bozmamak için bu paket API 36'da tutulmuştur.

## CI compatibility fix
- OkHttp was changed from 5.5.0 to 4.12.0.
- Reason: OkHttp 5.5.0 requires compile SDK 37, while this project is pinned to compileSdk 36 with Android Gradle Plugin 8.13.2.
- `android.useAndroidX=true` is preserved.

## Final lint policy adjustment
- `NewerVersionAvailable` is explicitly disabled.
- Rationale: OkHttp 4.12.0 is intentionally pinned because OkHttp 5.5.0 requires compileSdk 37, while this project is intentionally built with compileSdk 36 / AGP 8.13.2.
- `warningsAsErrors` remains enabled for all other lint warnings.
