# V4.7.4 kaynak ve yöntem kontrolü

## İncelenen resmi ve teknik kaynaklar

- Binance Spot REST Market API: https://developers.binance.com/en/docs/catalog/core-trading-spot-trading/api/rest-api/market
- Binance Spot WebSocket Market Streams: https://developers.binance.com/en/docs/catalog/core-trading-spot-trading/api/ws-streams
- Binance Spot REST genel güvenlik / endpoint sınıfları: https://developers.binance.com/en/docs/products/spot/rest-api
- Binance USDⓈ-M Futures WebSocket market streams: https://developers.binance.info/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/ws-streams/market
- TradingView RSI tanımı ve RMA hesabı: https://www.tradingview.com/support/solutions/43000502338-relative-strength-index-rsi/
- TradingView ATR ve varsayılan RMA yumuşatma: https://www.tradingview.com/support/solutions/43000501823-average-true-range-atr/
- TradingView Supertrend bant ve trend yönü hesabı: https://www.tradingview.com/support/solutions/43000634738-supertrend/
- TradingView VWAP kullanım açıklaması: https://www.tradingview.com/support/solutions/43000502018-volume-weighted-average-price-vwap/
- Finansal zaman serilerinde walk-forward ve overfit kıyaslaması: https://doi.org/10.1016/j.knosys.2024.112477

Bu, uygulamanın kullandığı pazar verileri ve indikatörler için odaklı kaynak kontrolüdür; web üzerindeki bütün sitelerin, forumların ve uygulamaların eksiksiz tarandığı iddiası değildir.

## Kod denetiminde bulunan ve giderilen konular

1. **TP adayı sırası:** Önce en yakın TP seçiliyor, ardından R/R filtresinde kalıyordu. Diğer erişilebilir TP adayları değerlendirme dışında kalabiliyordu. V4.7.4 bütün adaylar için stop-öncelikli temas, yapısal SL ve maliyet sonrası net R/R'yi ölçer; koşulları geçenler arasından en yakını seçer.
2. **Walk-forward sert vetosu:** Önce 12 örnek ve %45 altı sonuç sert veto idi. Pencereler örtüşebildiği için küçük örneğe aşırı ağırlık veriyordu. Şimdi 12+ örnekte düşük sonuç puan cezası verir; en az 30 örnekte %25 altı sonuç sert korumadır.
3. **Açık mum:** REST mum yanıtı açık son mumu da taşıyabildiğinden EMA/RSI/ATR ve hacim değerleri tamamlanmadan değişebiliyordu. İndikatör/teknik karar girdileri artık kapanmış mumlarla hesaplanır; canlı fiyat ve order-book ayrı doğrulama adımında güncel kalır. Hacim karşılaştırması son kapanan mumu kullanır.
4. **ATR, ADX ve Supertrend:** ATR basit ortalama, ADX ise basit pencere toplamları/ortalamalarıyla hesaplanıyor; `supertrend` alanı gerçek Supertrend değil, SMA merkezli ATR uzaklığı kullanıyordu. ATR Wilder RMA'ya, ADX Wilder'ın yumuşatılmış DMI/ADX hesabına geçirildi; Supertrend sürüklenen üst/alt bantlar ile yön geçişleri kullanılarak yeniden hesaplandı.
5. **Spot yönü:** Spot piyasada kısa satış mümkünmüş gibi SHORT canlı işlem adayı üretilebilecek yol kapatıldı. Spot canlı işlem yönü yalnız alım (LONG) olabilir.

## Kapsam ve yorumlama

Uygulamada OHLCV, çoklu zaman dilimi, EMA, RSI, MACD, ATR, ADX, MFI, Stochastic, Bollinger konumu, OBV eğimi, 20 mumluk hacim ağırlıklı fiyat, Ichimoku, Supertrend, swing yapı/BOS, Donchian, hacim profili POC, hacim/taker, CVD, order-book derinliği, Futures OI/funding/long-short ve BTC rejim/ilişki bileşenleri zaten bulunuyordu. Aynı bilgiyi anlatan yeni osilatörleri körlemesine eklemek yerine mevcut göstergelerin teknik doğruluğu ve veto sırası düzeltildi.

TP temas oranı gerçek kazanma olasılığı değildir; örtüşen geçmiş pencerelerden gelen bir erişim ölçüsüdür. Bu nedenle uygulama, sonuç sayısını doldurmak için işlem üretmez. Gösterilen adaylar emir göndermez; gerçek ücret, kayma, fonlama ve kullanıcı hesabı pozisyon durumları ayrı olabilir.

## Doğrulama

- `test-target-selection.js`: başarısız yakın TP'nin daha uzaktaki uygun hedefi saklamadığını sınar.
- `test-walk-forward-gate.js`: örnek sayısı ve veto/puan cezası ayrımını sınar.
- `test-indicator-core.js`: RMA ATR ve Supertrend yön değişim senaryolarını sınar.
- `test-closed-candles.js`: açık mumu dışlama ve Spot'ta SHORT'u engelleme kurallarını sınar.
- Diğer UI, reachable TP, seviye bütünlüğü, Spot akışı, watch queue ve stretch testleri CI dosyasında çalışır.

## Son Android ve işlem kartı kontrolü
- Android resmi rehberi `file://` + `setAllowUniversalAccessFromFileURLs(true)` birleşimini dosya tabanlı saldırı yüzeyi olarak işaretliyor ve `WebViewAssetLoader` öneriyor. V4.7.4 kabuğu bu nedenle asset-loader HTTPS benzeri kaynağa geçirildi; uzak ana sayfa gezinmesi kapatıldı, CSP bağlantıları Binance API/WebSocket uçlarına sınırlandı. Kaynak: https://developer.android.com/develop/ui/views/layout/webapps/load-local-content ve https://developer.android.com/privacy-and-security/risks/webview-unsafe-file-inclusion
- AndroidX WebKit 1.16.0 kararlı sürümü resmi sürüm notlarında yer alıyor ve minSdk 24 gerektiriyor; uygulamanın minSdk 26 değeriyle uyumlu. Kaynak: https://developer.android.com/jetpack/androidx/releases/webkit
- İşlem kartında yönün görünmemesi, başarısız TP1 için R/R gösterimi ve Spot canlı onaysız pozisyonda hesaplayıcıya erişim düzeltildi. Grafik artık kapanmış mum OHLCV sayılarını ve pozisyon seviyelerini açıklar; testleri CI’ye eklendi.
