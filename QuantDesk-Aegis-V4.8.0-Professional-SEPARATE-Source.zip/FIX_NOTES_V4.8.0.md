# QuantDesk Aegis V4.8.0 Professional

Bu sürüm V4.7.4 kaynak ağacından geliştirilmiş ayrı kurulumdur.

- Paket: `com.quantdesk.aegis.professional.v480`
- Sürüm: `4.8.0` (`versionCode 480`)
- V4.7.4 kaldırılmaz veya üzerine yazılmaz.
- Uygulama analiz ve karar destek aracıdır; borsaya emir göndermez.

## Canlı fırsat karar hattı

1. Binance USDⓈ-M Futures veya Spot evrenindeki ilk 200 USDT çifti taranır.
2. Düşük hacim, yüksek spread ve kararlı veri üretemeyen çiftler elenir.
3. PRO havuzu yalnız hacimden oluşmaz: 20 likit + 15 BTC bağlantısı yüksek + 15 teknik aday seçilir ve çakışmalar tekilleştirilir.
4. Bitcoin'in mikro, gün içi, swing ve makro yönü hesaplanır. Altcoin-BTC korelasyonu 0.25'in altındaysa işlem açılmaz. Korelasyon yeterliyken güçlü BTC yönüne ters altcoin yönü veto edilir.
5. Teknik yapı, mum, RSI/MFI, Wilder ATR/ADX, Supertrend, hacim, VWAP/POC, spread ve maliyetler faktör aileleri içinde değerlendirilir; aynı gösterge farklı adlarla iki kez puanlanmaz.
6. Futures için OI, funding, long/short, taker CVD, ilk 20 kademe order-book ve tasfiye akışı ikinci doğrulama katmanıdır; tek başına işlem üretmez.
7. TP1 yalnız yeterli stop-öncelikli tarihsel örnek, erişim, net R/R ve pozitif tarihsel beklenti birlikte varsa yayımlanır. TP1 yoksa TP2/TP3 de yayımlanmaz.
8. Son fiyat, giriş bandı, hedef tazeliği, SL geometrisi ve order-flow yeniden doğrulanır. Yalnız bütün kapıları geçen kart `İŞLEME HAZIR` olur.

## Zaman dilimleri

Analiz edilen 16 benzersiz zaman dilimi:

`1m, 3m, 5m, 10m, 15m, 20m, 25m, 30m, 45m, 1h, 2h, 3h, 4h, 6h, 12h, 24h`

Binance'in doğal mumları `1m, 3m, 5m, 15m, 1h, 4h` olarak alınır. Diğer süreler kapanmış mumlar birleştirilerek üretilir. “30 dakika” ve “yarım saat” aynı süre olduğu için bir kez kullanılır. Mikro, gün içi, swing ve makro aileleri ayrı puanlanarak yakın zaman dilimlerinin toplam skoru şişirmesi önlenir.

## Canlı Fırsatlar ve bildirimler

- Gerçek işlem yoksa eşikler gevşetilip sahte sinyal üretilmez.
- Koşullara uyan en az iki güçlü `CANLI İZLE` adayı gösterilmeye çalışılır; bunlar işlem sinyali değildir.
- Bütün kapıları geçen yeni kurulum için Android yüksek önem bildirim kanalı kullanılır.
- Aynı sembol/yön/setup/TP1 parmak izi ikinci kez bildirilmez.
- Sabit 45 saniyelik imha yoktur. Tazelik penceresi volatilite ve veri durumuna göre yeniden doğrulama tetikler; fırsat hâlâ geçerliyse korunur, yapı/SL/TP geçmişse iptal edilir.

## TP/SL ve cihaz öğrenmesi

- Cihaz günlüğü sonuçlanmış sinyalleri piyasa modu, sembol, yön, rejim ve volatilite kovasıyla saklar.
- Son gözlemlere 21 günlük üstel ağırlık uygulanır; küçük örnekler yumuşatılır.
- Öğrenme katkısı en çok %35'tir ve BTC, hedef, tazelik, maliyet veya risk kapılarını geçersiz kılamaz.
- “Yükseliş/düşüş” değerleri kalibre edilmiş kazanma olasılığı değil, yön skorudur.

## Risk ve emir planı

- Önceki sürekli açık hesaplayıcı, yalnız `İŞLEME HAZIR` kartından açılan `RİSK VE EMİR PLANI`na dönüştürüldü.
- Bakiye, işlem riski, kaldıraç, azami marjin kullanımı, komisyon ve kayma hesaba katılır.
- Binance lot adımı, minimum miktar ve minimum notional sınırları doğrulanır.
- Uygulama hesap bakiyesi, açık emir, gerçek gerçekleşme veya günlük P/L okumaz; bu nedenle otomatik zarar durdurma iddiası göstermez.

## Arayüz

- Kartın ilk ekranında yalnız karar, gerekçe, giriş, SL, geçerli TP1 ve net R/R bulunur.
- Teknik ayrıntılar açılır bölümde toplanmıştır; yinelenen uzun koruma metinleri kaldırılmıştır.
- Veri sağlığı, hazır aday ve canlı izleme sayıları üst özet alanında gösterilir.
- Ulaşılamayan hedef sayı olarak gösterilmez; `YAYINLANMADI` ifadesi kullanılır.

## Doğrulama

Kaynakta UI, kapanmış mum, gösterge çekirdeği, TP erişimi, hedef seçimi, Spot akışı, canlı izleme, pozisyon koruması, walk-forward ve V4.8 BTC/zaman-dilimi/bildirim değişmezlerini sınayan testler bulunur.
