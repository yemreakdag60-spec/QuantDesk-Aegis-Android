## V4.7.3 — EMA uzaması filtresi kalibrasyonu

- 1.55 ATR EMA21 uzaklığı sert veto olmaktan çıkarıldı. Bu mesafe zaten fırsat puanını düşürdüğü için aynı bulgunun hem puan hem veto olarak iki kez uygulanması kaldırıldı.
- Sert EMA uzaklığı vetosu 2.0 ATR seviyesine taşındı. SMART TP/ANTI-LATE (yakın dönem impulsu), giriş bölgesi, stop, R/R, tarihsel hedef erişimi, BTC yönü ve canlı order-flow kontrolleri değişmedi.
- Bu ayar belirli sayıda sinyal veya kârlı işlem vaat etmez. Orta uzamaya rağmen kalan TP alanı, R/R ve canlı doğrulama yetersizse aday yine elenir.
- Ayrı paket: `com.quantdesk.aegis.professional.v473`, versionCode `473`.
