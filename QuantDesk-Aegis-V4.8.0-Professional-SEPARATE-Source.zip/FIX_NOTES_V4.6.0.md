# QuantDesk Aegis V4.6.0 — Live Opportunity Engine Corrections

- Fixed false low-volume veto caused by using the active 15m candle.
- Removed retroactive TP freshness look-back on a newly calculated target.
- Added target issuance/setup lifecycle tracking for live TP consumption.
- Rebalanced R/R gating: soft penalty for marginal R/R, hard veto only for poor R/R/target reach combinations.
- Rebalanced volume gating: hard veto only for severe closed-candle volume weakness.
- Dynamic pre-live blocks now remain eligible for periodic live revalidation.
- Separate package/application identity for side-by-side comparison.
