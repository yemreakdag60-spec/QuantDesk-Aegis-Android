## V4.7.4 — TP hedefi ve R/R seçim çakışması

- Önceki sürüm aday TP'ler arasından yalnızca fiyata en yakın olanı seçiyor, sonra bu hedefin net R/R ve stop-öncelikli tarihsel erişimini kontrol ediyordu. Daha uzaktaki ama erişim/R/R kapılarını geçen hedefler hiç değerlendirilmiyordu.
- Yeni seçim, her TP adayı için tarihsel stop-öncelikli erişimi, yapısal SL mesafesini ve tahmini maliyet sonrası net R/R'yi birlikte hesaplar. Koşulları geçen hedeflerden en yakını seçilir.
- Hiçbir hedef kapıları geçmezse mevcut en yakın aday yalnızca izleme/gerekçe üretimi içindir; TP1 uygun sayılmaz ve işlem sinyali oluşturmaz.
- Eşikler işlem sayısını yükseltmek için düşürülmedi. Tarihsel temas oranı gerçek kazanma olasılığı değildir; örtüşen geçmiş mum pencerelerinden elde edilen doğrulama ölçüsüdür.
- Walk-forward kısa örneklerinde %45 altı artık tek başına sert veto değildir: 12+ örnekte skor cezası uygular; 30+ örnekte %25 altı sert koruma olarak kalır.
- Teknik göstergeler kapanmış mumları kullanır; açık mumun yeniden çizilmesi karar skorunu oynatmaz. Canlı fiyat ve defter son doğrulamada kalır.
- ATR/ADX hesapları Wilder yumuşatmasına düzeltildi; `supertrend` yanlış ATR-midpoint vekili olmaktan çıkarılıp sürüklenen bant ve dönüş koşullarıyla hesaplanır.
- Spot modunda yalnız LONG alım canlı işlem adayı olabilir; Spot SHORT satım sinyaline dönüştürülemez.
- Hatalı, yeni fiyata göre yeniden kurulan giriş bandına kıyas yapan etkisiz geç giriş kontrolü kaldırıldı. Önceden yayımlanan TP/SL aynı setup süresince izlenir; eski setup seviyesi geçilirse geçersizleşir.
- `test-target-selection.js` daha yakındaki yetersiz hedefin daha uzaktaki uygun hedefi saklamadığını ve uygun hedef yokken sinyal uygunluğu verilmediğini sınar.
- `test-walk-forward-gate.js`, `test-indicator-core.js` ve `test-closed-candles.js` küçük örnek cezasını, Wilder ATR/ADX + Supertrend yönünü, kapanmış mum kullanımını, Spot yönünü ve önceki SL sınırını sınar.
- Ayrı paket: `com.quantdesk.aegis.professional.v474`, versionCode `474`.

## Son kullanıcı arayüzü ve güvenlik gözden geçirmesi
- Kart başlığında LONG/SHORT yönü ve CANLI ADAY/İZLE/KORUMA durumu ayrı gösterilir.
- Nitelik kapısından geçmeyen TP1 için R/R değeri saklanır; chart uygun olmayan TP1 seviyesini yeşil hedef olarak çizmez.
- 15dk mum grafiği son kapanmış mum OHLCV sayısal değerlerini ve giriş bandı/SL/uygun TP1/son fiyat işaretlerini gösterir.
- Pozisyon hesaplama eylemi yalnızca `isActionable` ve geçerli yön/TP/SL geometrisi sağlandığında sunulur; Spot SHORT ve canlı onaysız Spot adayları kapsam dışıdır.
- Yuvarlanmış miktarın gerçek stop+kayma+komisyon tahmini ayrıca gösterilir; borsa minimum tutarı/miktarı sağlanmıyorsa hesap bloke edilir.
- WebView `file://` evrensel erişiminden AndroidX WebViewAssetLoader tabanlı güvenli yerel kaynağa geçirildi; bağlantılar CSP ile Binance veri hostlarıyla sınırlandırıldı.
