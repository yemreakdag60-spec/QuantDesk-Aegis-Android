# V4.8.0 araştırma → özellik matrisi

Araştırmanın amacı rakip ekranlarını kopyalamak değil, doğrulanabilen profesyonel davranışları tek ve tutarlı karar hattına çevirmektir.

| Kaynak/ürün davranışı | V4.8.0 karşılığı | Karar |
|---|---|---|
| Binance resmi USDⓈ-M market-data API: kline, ticker, book, open interest, taker ve oran verileri | Kapanmış mum teknikleri + canlı fiyat/defter doğrulaması + Futures türev ailesi | Entegre |
| TradingView: gelişmiş grafik, uyarı ve watchlist odaklı akış | 15dk kapanmış mum grafiği, otomatik canlı izleme listesi, yinelenmeyen Android fırsat bildirimi | Entegre |
| CoinGlass: OI, funding, long/short, tasfiye ve order-flow görünürlüğü | Bu metrikler tek “türev doğrulama” ailesinde; teknik yönü tek başına değiştirmez | Entegre |
| CoinMarketCap / Crypto Bubbles: geniş piyasa evreni, watchlist ve hızlı piyasa özeti | 200 çiftlik evren, piyasa genişliği, likidite/BTC/teknik bileşik sıralama, 2–5 canlı izleme adayı | Entegre |
| Uygulama mağazalarındaki sinyal ürünleri: entry/TP/SL ve anlık bildirim | Yalnız canlı doğrulanmış kartta entry/TP1/SL; geçersiz TP yayınlanmaz; tekrar bildirim engellenir | Daha sıkı biçimde entegre |
| Forumlarda sık görülen “çok gösterge = yüksek güven” yaklaşımı | Korelasyonlu göstergeler faktör ailesinde birleştirilir; skorlar olasılık diye sunulmaz | Bilinçli olarak reddedildi |
| Haber/sosyal duygu, on-chain, harici likidasyon haritası | Yeni API anahtarı, lisans ve veri sürekliliği gerektirir; mevcut sürüme sahte/eksik veriyle eklenmedi | Ertelendi |
| Borsa hesabına bağlanma ve otomatik emir | Kimlik bilgisi, izin, açık pozisyon ve yürütme riski gerektirir | Kapsam dışı |

## Başlıca kaynaklar

- Binance Developer Docs: https://developers.binance.com/en/docs
- Binance USDⓈ-M Futures market data: https://developers.binance.com/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data
- TradingView App Store açıklaması: https://apps.apple.com/us/app/tradingview-track-all-markets/id1205990992
- CoinGlass ürün sayfası: https://www.coinglass.com/
- CoinGlass open-interest/volume: https://www.coinglass.com/pro/futures/Cryptofutures
- CoinGlass liquidation heatmap rehberi: https://www.coinglass.com/learn/how-to-use-liqmap-to-assist-trading-en
- CoinMarketCap App Store açıklaması: https://apps.apple.com/us/app/coinmarketcap-crypto-tracker/id1282107098
- Crypto Bubbles App Store açıklaması: https://apps.apple.com/us/app/crypto-bubbles/id1599892658

## Tasarım ilkesi

Yeni özellik ancak veri kaynağı, tazelik ölçütü, karar hattındaki yeri ve otomatik testi tanımlanabiliyorsa eklenir. Aynı piyasa olgusunu ölçen göstergeler bağımsız oylar gibi toplanmaz. Canlı fırsat bulunmaması hata kabul edilmez; veri kesintisi ile piyasanın koşul üretmemesi ayrı durumlar olarak gösterilir.
