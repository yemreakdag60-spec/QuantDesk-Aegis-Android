package com.quantdesk.aegis;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.content.Intent;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.webkit.JavascriptInterface;
import android.database.Cursor;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.database.sqlite.SQLiteDatabase;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.activity.ComponentActivity;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import androidx.activity.OnBackPressedCallback;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Locale;

public class MainActivity extends ComponentActivity {
    private WebView webView;
    private WebViewAssetLoader assetLoader;

    @SuppressLint({"SetJavaScriptEnabled", "Deprecated"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7, 17, 31));
        getWindow().setNavigationBarColor(Color.rgb(7, 17, 31));

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setAllowContentAccess(false);
        s.setAllowFileAccess(false);
        // Bundled UI is served from a secure appassets origin; avoid file:// universal access.
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                boolean trustedAppPage = "https".equals(uri.getScheme())
                        && "appassets.androidplatform.net".equals(uri.getHost())
                        && uri.getPath() != null && uri.getPath().startsWith("/assets/");
                return request.isForMainFrame() && !trustedAppPage;
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AegisBridge(), "AegisNative");

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                    return;
                }
                setEnabled(false);
                getOnBackPressedDispatcher().onBackPressed();
                setEnabled(true);
            }
        });

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 41);
        Intent svc = new Intent(this, MarketDataService.class);
        startForegroundService(svc);

        if (savedInstanceState == null) {
            webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    public final class AegisBridge {
        @JavascriptInterface public String status() {
            return getSharedPreferences("aegis", MODE_PRIVATE).getString("status", "Başlatılıyor");
        }
        @JavascriptInterface public String flow(String symbol) {
            String s=symbol==null?"BTCUSDT":symbol.replaceAll("[^A-Z0-9]","");
            double buy=0,sell=0,bid=0,ask=0,longLiq=0,shortLiq=0,spoof=0; int trades=0,depthSamples=0,minutes=0; long updated=0;
            try(SQLiteDatabase db=openOrCreateDatabase("aegis_flow.db",MODE_PRIVATE,null); Cursor c=db.rawQuery("SELECT SUM(buy),SUM(sell),SUM(trades),AVG(bid_depth),AVG(ask_depth),SUM(long_liq),SUM(short_liq),MAX(spoof),SUM(depth_samples),MAX(updated_ms),COUNT(*) FROM flow_minute WHERE symbol=? AND minute>?",new String[]{s,String.valueOf(System.currentTimeMillis()/60000-15)})){
                if(c.moveToFirst()){buy=c.getDouble(0);sell=c.getDouble(1);trades=c.getInt(2);bid=c.getDouble(3);ask=c.getDouble(4);longLiq=c.getDouble(5);shortLiq=c.getDouble(6);spoof=c.getDouble(7);depthSamples=c.getInt(8);updated=c.getLong(9);minutes=c.getInt(10);}
            }catch(Exception ignored){}
            long age=updated>0?Math.max(0,(System.currentTimeMillis()-updated)/1000):9999;
            double delta=buy-sell,imb=(bid+ask)>0?(bid-ask)/(bid+ask)*100:0,liq=longLiq+shortLiq;
            int quality=(int)Math.round(Math.min(100,Math.min(depthSamples/2.0,trades/5.0)));if(age>45)quality=Math.min(quality,35);if(minutes<2)quality=Math.min(quality,45);
            boolean ready=age<=45&&depthSamples>=30&&trades>=50&&minutes>=2;
            if(!ready)spoof=0;
            return "{\"symbol\":\""+s+"\",\"windowMinutes\":15,\"buy\":"+buy+",\"sell\":"+sell+",\"delta\":"+delta+",\"trades\":"+trades+",\"bookImbalance\":"+imb+",\"longLiquidations\":"+longLiq+",\"shortLiquidations\":"+shortLiq+",\"liquidations\":"+liq+",\"spoofRisk\":"+spoof+",\"depthSamples\":"+depthSamples+",\"coverageMinutes\":"+minutes+",\"ageSeconds\":"+age+",\"quality\":"+quality+",\"ready\":"+ready+"}";
        }
        @JavascriptInterface public void setMarketMode(String mode) {
            String selected="SPOT".equalsIgnoreCase(mode)?"SPOT":"FUTURES";
            getSharedPreferences("aegis", MODE_PRIVATE).edit().putString("market_mode", selected).apply();
            Intent update = new Intent(MainActivity.this, MarketDataService.class);
            update.setAction(MarketDataService.ACTION_SET_MARKET_MODE);
            update.putExtra(MarketDataService.EXTRA_MARKET_MODE, selected);
            startForegroundService(update);
        }
        @JavascriptInterface public void watch(String csv) {
            if (csv == null || csv.isEmpty()) return;
            LinkedHashSet<String> unique = new LinkedHashSet<>();
            for (String token : csv.toUpperCase(Locale.US).split(",")) {
                String symbol = token.replaceAll("[^A-Z0-9]", "");
                if (symbol.endsWith("USDT") && symbol.length() >= 7 && symbol.length() <= 20) {
                    unique.add(symbol);
                    if (unique.size() >= 50) break;
                }
            }
            if (unique.isEmpty()) return;
            Intent update = new Intent(MainActivity.this, MarketDataService.class);
            update.setAction(MarketDataService.ACTION_SET_PRIORITY);
            update.putStringArrayListExtra(MarketDataService.EXTRA_PRIORITY_SYMBOLS, new ArrayList<>(unique));
            startForegroundService(update);
        }
        @JavascriptInterface public void notifySignal(String symbol, String direction, String entry, String tp, String sl, String fingerprint) {
            String safeSymbol=symbol==null?"":symbol.toUpperCase(Locale.US).replaceAll("[^A-Z0-9]","");
            String safeDirection="SHORT".equalsIgnoreCase(direction)?"SHORT":"LONG";
            String safeFingerprint=fingerprint==null?"":fingerprint.replaceAll("[^A-Za-z0-9_.|:-]","");
            if(!safeSymbol.endsWith("USDT")||safeSymbol.length()<7||safeSymbol.length()>20||safeFingerprint.isEmpty())return;
            if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
            String channelId="aegis_live_opportunity_v480";
            NotificationManager manager=getSystemService(NotificationManager.class);
            NotificationChannel channel=new NotificationChannel(channelId,"Canlı fırsat uyarıları",NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Tüm canlı doğrulama kapılarını geçen yeni işlem planları");
            manager.createNotificationChannel(channel);
            Intent open=new Intent(MainActivity.this,MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pending=PendingIntent.getActivity(MainActivity.this,safeFingerprint.hashCode(),open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
            String cleanEntry=entry==null?"—":entry.replaceAll("[^0-9.–—]","");
            String cleanTp=tp==null?"—":tp.replaceAll("[^0-9.–—]","");
            String cleanSl=sl==null?"—":sl.replaceAll("[^0-9.–—]","");
            Notification notification=new Notification.Builder(MainActivity.this,channelId)
                    .setSmallIcon(android.R.drawable.stat_notify_more)
                    .setContentTitle(safeSymbol+" • "+safeDirection+" • canlı doğrulandı")
                    .setContentText("Giriş "+cleanEntry+"  TP1 "+cleanTp+"  SL "+cleanSl)
                    .setStyle(new Notification.BigTextStyle().bigText("Giriş "+cleanEntry+" • TP1 "+cleanTp+" • SL "+cleanSl+" • uygulamada güncelliği yeniden kontrol et"))
                    .setAutoCancel(true).setOnlyAlertOnce(true).setContentIntent(pending).build();
            manager.notify(8000+Math.floorMod(safeFingerprint.hashCode(),1000),notification);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.evaluateJavascript("if(window.refreshLiveSignals){refreshLiveSignals();}if(window.nativeFlow){nativeFlow();}", null);
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }
}
