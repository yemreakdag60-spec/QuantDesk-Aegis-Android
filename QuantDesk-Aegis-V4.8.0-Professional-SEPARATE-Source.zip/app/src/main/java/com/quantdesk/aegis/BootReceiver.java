package com.quantdesk.aegis;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        if (i == null) return;
        String action = i.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) return;

        Intent s = new Intent(c, MarketDataService.class);
        try {
            c.startForegroundService(s);
        } catch (RuntimeException ignored) {
            // OEM/Android engellerse servis, kullanıcı uygulamayı açtığında başlar.
        }
    }
}
