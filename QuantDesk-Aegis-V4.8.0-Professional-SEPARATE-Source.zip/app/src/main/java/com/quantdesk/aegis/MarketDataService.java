package com.quantdesk.aegis;

import android.app.*;
import android.content.*;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import android.os.*;
import org.json.*;
import java.util.*;
import java.util.concurrent.*;
import okhttp3.*;

public class MarketDataService extends Service {
    public static final String ACTION_SET_PRIORITY="com.quantdesk.aegis.v480.SET_PRIORITY";
    public static final String ACTION_SET_MARKET_MODE="com.quantdesk.aegis.v480.SET_MARKET_MODE";
    public static final String EXTRA_MARKET_MODE="market_mode";
    public static final String EXTRA_PRIORITY_SYMBOLS="priority_symbols";
    private static final int BASE_FLOW_SYMBOLS=50, MAX_FLOW_SYMBOLS=80, MAX_PRIORITY_SYMBOLS=30;
    private static final String CHANNEL="aegis_market", REST="https://fapi.binance.com", WS="wss://fstream.binance.com/stream?streams=";
    private final OkHttpClient http=new OkHttpClient.Builder().pingInterval(20,TimeUnit.SECONDS).retryOnConnectionFailure(true).build();
    private final ScheduledExecutorService timer=Executors.newSingleThreadScheduledExecutor();
    private final Map<String,Bucket> buckets=new ConcurrentHashMap<>();
    private final Map<String,double[]> depthPrev=new ConcurrentHashMap<>();
    private final LinkedHashSet<String> prioritySymbols=new LinkedHashSet<>();
    private volatile WebSocket socket;
    private volatile String[] liquidSymbols={"BTCUSDT","ETHUSDT","SOLUSDT","BNBUSDT","XRPUSDT","DOGEUSDT","ADAUSDT","LINKUSDT","AVAXUSDT","SUIUSDT"};
    private volatile String[] symbols=liquidSymbols;
    private SQLiteDatabase db; private int retry=1; private volatile long lastEventMs=0; private volatile boolean paused;

    static final class Bucket {
        long minute, updatedMs;
        double buy, sell, bid, ask, longLiq, shortLiq, spoof, lastDepthTrade;
        int trades, depthSamples, cancelAnomalies;
    }

    @Override public void onCreate(){super.onCreate();channel();startForeground(41,notification("Order-flow başlatılıyor"));db=openOrCreateDatabase("aegis_flow.db",MODE_PRIVATE,null);db.enableWriteAheadLogging();db.execSQL("CREATE TABLE IF NOT EXISTS flow_minute(symbol TEXT,minute INTEGER,buy REAL DEFAULT 0,sell REAL DEFAULT 0,trades INTEGER DEFAULT 0,bid_depth REAL DEFAULT 0,ask_depth REAL DEFAULT 0,long_liq REAL DEFAULT 0,short_liq REAL DEFAULT 0,spoof REAL DEFAULT 0,depth_samples INTEGER DEFAULT 0,updated_ms INTEGER DEFAULT 0,PRIMARY KEY(symbol,minute))");migrateFlowSchema();paused="SPOT".equals(getSharedPreferences("aegis",MODE_PRIVATE).getString("market_mode","FUTURES"));if(!paused){connect();refreshUniverse();}else status("Spot modu • Futures order-flow duraklatıldı");timer.scheduleWithFixedDelay(this::flush,10,10,TimeUnit.SECONDS);timer.scheduleWithFixedDelay(this::refreshUniverse,30,30,TimeUnit.MINUTES);timer.scheduleWithFixedDelay(()->{if(!paused&&lastEventMs>0&&System.currentTimeMillis()-lastEventMs>60000){status("Derinlik akışı yenileniyor");connect();}},30,30,TimeUnit.SECONDS);timer.scheduleWithFixedDelay(this::connect,6,6,TimeUnit.HOURS);}
    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i!=null&&ACTION_SET_MARKET_MODE.equals(i.getAction())){
            boolean nextPaused="SPOT".equals(i.getStringExtra(EXTRA_MARKET_MODE));
            paused=nextPaused;
            if(paused){if(socket!=null){socket.cancel();socket=null;}lastEventMs=0;status("Spot modu • Futures order-flow duraklatıldı");}
            else{status("Futures order-flow yeniden bağlanıyor");refreshUniverse();connect();}
        }
        if(i!=null&&ACTION_SET_PRIORITY.equals(i.getAction())){
            ArrayList<String> requested=i.getStringArrayListExtra(EXTRA_PRIORITY_SYMBOLS);
            synchronized(this){
                prioritySymbols.clear();
                if(requested!=null)for(String raw:requested){
                    if(raw==null)continue;
                    String symbol=raw.toUpperCase(Locale.US).replaceAll("[^A-Z0-9]","");
                    if(symbol.endsWith("USDT")&&symbol.length()>=7&&symbol.length()<=20){
                        prioritySymbols.add(symbol);
                        if(prioritySymbols.size()>=MAX_PRIORITY_SYMBOLS)break;
                    }
                }
                rebuildSymbols();
            }
        }
        return START_STICKY;
    }
    @Override public IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){flush();if(socket!=null)socket.cancel();timer.shutdownNow();http.dispatcher().executorService().shutdown();super.onDestroy();}

    private void channel(){NotificationChannel c=new NotificationChannel(CHANNEL,"QuantDesk piyasa verisi",NotificationManager.IMPORTANCE_LOW);c.setDescription("Order-flow verilerini arka planda toplar");getSystemService(NotificationManager.class).createNotificationChannel(c);}
    private Notification notification(String text){Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);Notification.Builder b=new Notification.Builder(this,CHANNEL);return b.setContentTitle("Aegis V4.8.0 Professional").setContentText(text).setSmallIcon(android.R.drawable.stat_notify_sync).setOngoing(true).setContentIntent(pi).build();}
    private void migrateFlowSchema(){String[] columns={"long_liq REAL DEFAULT 0","short_liq REAL DEFAULT 0","spoof REAL DEFAULT 0","depth_samples INTEGER DEFAULT 0","updated_ms INTEGER DEFAULT 0"};for(String column:columns){try{db.execSQL("ALTER TABLE flow_minute ADD COLUMN "+column);}catch(Exception ignored){}}}
    private void status(String s){getSharedPreferences("aegis",MODE_PRIVATE).edit().putString("status",s).putLong("last",System.currentTimeMillis()).apply();getSystemService(NotificationManager.class).notify(41,notification(s));}
    private synchronized void rebuildSymbols(){
        LinkedHashSet<String> merged=new LinkedHashSet<>();
        for(String s:liquidSymbols){if(s!=null&&!s.isEmpty()){merged.add(s);if(merged.size()>=BASE_FLOW_SYMBOLS)break;}}
        for(String s:prioritySymbols){if(s!=null&&!s.isEmpty()){merged.add(s);if(merged.size()>=MAX_FLOW_SYMBOLS)break;}}
        if(merged.isEmpty())return;
        String[] next=merged.toArray(new String[0]);
        if(!Arrays.equals(next,symbols)){
            symbols=next;
            depthPrev.keySet().retainAll(merged);
            connect();
        }
    }
    private String streamUrl(){StringBuilder u=new StringBuilder(WS);for(int i=0;i<symbols.length;i++){if(i>0)u.append('/');String s=symbols[i].toLowerCase(Locale.US);u.append(s).append("@depth20@500ms/").append(s).append("@aggTrade");}u.append("/!forceOrder@arr");return u.toString();}
    private synchronized void connect(){if(paused)return;if(socket!=null)socket.cancel();lastEventMs=0;socket=http.newWebSocket(new Request.Builder().url(streamUrl()).build(),new WebSocketListener(){@Override public void onOpen(WebSocket w,Response r){if(w!=socket)return;retry=1;status("Canlı order-flow • "+symbols.length+" coin");}@Override public void onMessage(WebSocket w,String text){if(w!=socket)return;lastEventMs=System.currentTimeMillis();parse(text);}@Override public void onFailure(WebSocket w,Throwable t,Response r){if(w!=socket)return;status("Derinlik bağlantısı yenileniyor");int d=Math.min(60,retry*=2);timer.schedule(MarketDataService.this::connect,d,TimeUnit.SECONDS);}});}
    private Bucket bucket(String symbol){long m=System.currentTimeMillis()/60000;String key=symbol+":"+m;return buckets.computeIfAbsent(key,k->{Bucket b=new Bucket();b.minute=m;try(Cursor c=db.rawQuery("SELECT buy,sell,trades,bid_depth,ask_depth,long_liq,short_liq,spoof,depth_samples,updated_ms FROM flow_minute WHERE symbol=? AND minute=?",new String[]{symbol,String.valueOf(m)})){if(c.moveToFirst()){b.buy=c.getDouble(0);b.sell=c.getDouble(1);b.trades=c.getInt(2);b.bid=c.getDouble(3);b.ask=c.getDouble(4);b.longLiq=c.getDouble(5);b.shortLiq=c.getDouble(6);b.spoof=c.getDouble(7);b.depthSamples=c.getInt(8);b.updatedMs=c.getLong(9);b.lastDepthTrade=b.buy+b.sell;}}catch(Exception ignored){}return b;});}
    private void parse(String text){try{JSONObject root=new JSONObject(text);String stream=root.optString("stream").toLowerCase(Locale.US);Object raw=root.has("data")?root.opt("data"):root;if(raw instanceof JSONArray){JSONArray a=(JSONArray)raw;for(int i=0;i<a.length();i++)parseLiquidation(a.optJSONObject(i));return;}if(!(raw instanceof JSONObject))return;JSONObject d=(JSONObject)raw;String event=d.optString("e").toLowerCase(Locale.US);if(stream.equals("!forceorder@arr")||event.equals("forceorder")){parseLiquidation(d);return;}String s=d.optString("s");if(s.isEmpty())return;Bucket b=bucket(s);if(stream.contains("@aggtrade")||event.equals("aggtrade")){double n=d.optDouble("p")*d.optDouble("q");if(n<=0)return;if(d.optBoolean("m"))b.sell+=n;else b.buy+=n;b.trades++;b.updatedMs=System.currentTimeMillis();}else if(stream.contains("@depth")||event.equals("depthupdate")){double bid=sum(d.optJSONArray("b")),ask=sum(d.optJSONArray("a"));double[] p=depthPrev.get(s);b.depthSamples++;if(p!=null&&p[0]>0&&p[1]>0){double disappeared=Math.max(0,p[0]-bid)+Math.max(0,p[1]-ask);double base=Math.max(1,p[0]+p[1]);double ratio=disappeared/base;double totalTrade=b.buy+b.sell,tradedSince=Math.max(0,totalTrade-b.lastDepthTrade);if(ratio>.12&&disappeared>10000&&tradedSince<disappeared*.20)b.cancelAnomalies++;double confidence=Math.min(1,b.depthSamples/30.0);b.spoof=b.depthSamples<10?0:Math.min(75,100.0*b.cancelAnomalies/Math.max(1,b.depthSamples)*confidence);b.lastDepthTrade=totalTrade;}depthPrev.put(s,new double[]{bid,ask});b.bid=bid;b.ask=ask;b.updatedMs=System.currentTimeMillis();}}catch(Exception ignored){}}
    private void parseLiquidation(JSONObject event){if(event==null)return;JSONObject o=event.optJSONObject("o");if(o==null)o=event;String s=o.optString("s");if(s.isEmpty())return;double value=o.optDouble("ap",o.optDouble("p"))*o.optDouble("q");Bucket b=bucket(s);if("SELL".equals(o.optString("S")))b.longLiq+=value;else if("BUY".equals(o.optString("S")))b.shortLiq+=value;b.updatedMs=System.currentTimeMillis();}
    private double sum(JSONArray a){double x=0;if(a!=null)for(int i=0;i<a.length();i++){JSONArray r=a.optJSONArray(i);if(r!=null)x+=r.optDouble(0)*r.optDouble(1);}return x;}
    private synchronized void flush(){if(db==null)return;for(Map.Entry<String,Bucket> e:new ArrayList<>(buckets.entrySet())){Bucket b=e.getValue();db.execSQL("INSERT OR REPLACE INTO flow_minute(symbol,minute,buy,sell,trades,bid_depth,ask_depth,long_liq,short_liq,spoof,depth_samples,updated_ms) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",new Object[]{e.getKey().split(":")[0],b.minute,b.buy,b.sell,b.trades,b.bid,b.ask,b.longLiq,b.shortLiq,b.spoof,b.depthSamples,b.updatedMs});if(b.minute<System.currentTimeMillis()/60000)buckets.remove(e.getKey());}db.execSQL("DELETE FROM flow_minute WHERE minute<?",new Object[]{System.currentTimeMillis()/60000-7*24*60});}
    private void refreshUniverse(){
        if(paused)return;
        Request metaRequest=new Request.Builder().url(REST+"/fapi/v1/exchangeInfo").build();
        http.newCall(metaRequest).enqueue(new Callback(){
            public void onFailure(Call c,java.io.IOException e){status("Coin evreni yenilenemedi");}
            public void onResponse(Call c,Response metaResponse){
                try(ResponseBody metaBody=metaResponse.body()){
                    if(!metaResponse.isSuccessful()||metaBody==null)return;
                    JSONObject meta=new JSONObject(metaBody.string());Set<String> eligible=new HashSet<>();
                    Set<String> stable=new HashSet<>(Arrays.asList("USDC","FDUSD","TUSD","USDP","DAI","BUSD","EUR","TRY","AEUR","EURI"));
                    JSONArray contracts=meta.optJSONArray("symbols");
                    if(contracts!=null)for(int i=0;i<contracts.length();i++){
                        JSONObject x=contracts.optJSONObject(i);if(x==null)continue;
                        if("PERPETUAL".equals(x.optString("contractType"))&&"USDT".equals(x.optString("quoteAsset"))&&"TRADING".equals(x.optString("status"))&&!stable.contains(x.optString("baseAsset")))eligible.add(x.optString("symbol"));
                    }
                    try(Response tickerResponse=http.newCall(new Request.Builder().url(REST+"/fapi/v1/ticker/24hr").build()).execute();ResponseBody tickerBody=tickerResponse.body()){
                        if(!tickerResponse.isSuccessful()||tickerBody==null)return;
                        JSONArray a=new JSONArray(tickerBody.string());List<JSONObject> rows=new ArrayList<>();
                        for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&eligible.contains(x.optString("symbol"))&&x.optDouble("quoteVolume")>0)rows.add(x);}
                        rows.sort((x,y)->Double.compare(y.optDouble("quoteVolume"),x.optDouble("quoteVolume")));
                        String[] next=new String[Math.min(BASE_FLOW_SYMBOLS,rows.size())];
                        for(int i=0;i<next.length;i++)next[i]=rows.get(i).optString("symbol");
                        if(next.length>0){
                            liquidSymbols=next;
                            rebuildSymbols();
                        }
                    }
                }catch(Exception e){status("Coin evreni yenilenemedi");}
            }
        });
    }
}
