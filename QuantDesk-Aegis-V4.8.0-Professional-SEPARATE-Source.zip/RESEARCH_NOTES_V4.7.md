# QuantDesk Aegis V4.7 — Research notes and implementation choices

## Scope

This is a focused design review of primary exchange documentation, established charting/order-flow products listed in the Apple App Store and Google Play, and research on backtest overfitting. It is not an exhaustive crawl of every website, forum thread, lesson, or app-store listing; those catalogs change constantly and contain both unsupported claims and user anecdotes. Product listings were used to understand feature expectations, not as evidence that any app's trading signals are profitable.

## Sources reviewed

- Binance Spot REST API and market-data documentation: https://developers.binance.com/en/docs/products/spot/rest-api and https://developers.binance.com/en/docs/binance-spot-api-docs/rest-api/market-data-endpoints
- Binance USDⓈ-M Futures API overview: https://developers.binance.com/en/docs/products/derivatives-trading-usds-futures/Introduction
- TradingView mobile listing: https://play.google.com/store/apps/details?id=com.tradingview.tradingviewapp and https://apps.apple.com/tr/app/tradingview-track-all-markets/id1205990992
- GoCharting order-flow listing: https://play.google.com/store/apps/details?id=com.gocharting.gocharting and https://apps.apple.com/tr/app/gocharting/id1666068250
- Bailey, Borwein, López de Prado and Zhu, “Pseudo-Mathematics and Financial Charlatanism: The Effects of Backtest Overfitting on Out-of-Sample Performance”: https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2308659

## Design changes tied to that review

- Spot and USDⓈ-M Futures use separate Binance REST routes and separate field sets. Spot mode uses Spot ticker, klines, depth and aggregate trades. Funding, open interest, futures account ratios and liquidation events are not displayed as Spot observations.
- A user can see BTC's multi-timeframe regime before the ranked coin list. The coin universe is capped at the top 200 eligible USDT markets by 24-hour quote volume.
- PRO cards now include a compact 15-minute OHLC and volume chart. The card keeps direction scores, live-entry status, and target reach history as separate concepts.
- Futures order-flow remains a Futures-only input. Switching to Spot stops the Android foreground service's Futures depth/trade stream; Spot analysis requests Spot market data instead.
- TP reach samples are evaluated stop-first: if both stop and target appear in one OHLC candle, the sample is counted as stopped. TP1 is hidden unless there are at least 20 historical paths and at least 35% stop-first target touches; TP2 requires 20 paths and 35%; TP3 requires 20 paths and 25%.

## Limits

The TP thresholds are conservative display rules, not learned or independently validated performance guarantees. The historical paths overlap and are not an untouched out-of-sample test. Their touch rates are descriptive frequencies, not calibrated future win probabilities. No source or app-store survey can establish that a signal will avoid losses. The app still does not place exchange orders. Before relying on the rankings or TP filters for live trading, performance needs a separate fee/slippage-aware, walk-forward validation with untouched time periods and instrument-level results.
