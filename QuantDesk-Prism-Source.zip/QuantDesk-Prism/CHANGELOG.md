# Changelog

## 2.0.0
- Replaced the previous APK-derived web interface with an original QuantDesk Prism dashboard and modular assets.
- Implemented an independent explainable market model and synthetic-regression checks.
- Renamed the Android application ID and launcher identity to QuantDesk Prism.
- Clarified that score is not probability and documented backend, model and data limitations.
