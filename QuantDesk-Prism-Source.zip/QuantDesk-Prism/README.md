# QuantDesk Prism 2.0.0

QuantDesk Prism is an independently implemented Android market-analysis app for Binance USDⓈ-M perpetual contracts. Its user interface, analysis module and app identity are original to this project; they do not reuse the referenced Play Store app's code or assets. Android application ID: `com.emreakdag.quantdesk.prism`.

## Included

- Original, responsive Turkish dashboard and custom vector launcher icon.
- BTC and ETH 24-hour contract quotes; optional Alternative.me Fear & Greed reading.
- USDT contract list sorted by 24-hour quote volume, with a bounded top-contract scanner.
- Binance Futures candles and OHLCV table (open, high, low, close, base volume and quote volume); lightweight custom candlestick canvas.
- Explainable `Prism Explainable Ensemble v1`: EMA trend, RSI momentum, recent range structure, taker participation, 1h/4h trend alignment, funding and order-book imbalance. Factors and input coverage are shown. The 0–100 score is not a win probability; default factor weights are trend 27%, momentum 20%, structure 16%, taker flow 15%, higher-timeframe alignment 12% and derivatives 10%.
- ATR and recent swing-based entry/stop/targets, labeled as an analysis scenario. The model labels a 12-bar analysis horizon; it does not automatically expire or reevaluate saved signals.
- Current open interest, funding, order book, taker-volume snapshot, plus a native WebSocket collector for aggregate trades and published force-order events. The native collector stores selected-symbol aggregate trades, observed force-order events and best bid/ask samples in local SQLite (not the full-depth book). No hosted custom service or exchange account is included.
- On-device signal journal stored in browser local storage.

## Boundaries

This is a market-information and decision-support app. It does not connect exchange accounts, place orders, send push notifications, or have a hosted backend/community. The current model is deterministic and rule-based; it is not trained AI, has no completed walk-forward performance study, and does not promise profitability. The scanner processes the first eight liquid symbols per run. Order-book imbalance is a public snapshot, not spoofing detection. Binance and Alternative.me availability varies by network and region. The app has not been built on this machine because Android SDK/Gradle are unavailable; use the supplied GitHub Actions workflow for a clean build.

## Verify and build

Run `node scripts/test-analysis.cjs` to check model directionality on synthetic candles, bounds, insufficient-history rejection, OHLCV parsing, and expected UI assets. These checks are software regression checks; they are not a backtest or live profitability test.

The workflow can build from an extracted `QuantDesk-Prism/` directory or from `QuantDesk-Prism-Source.zip` at repository root. It runs the Node regression checks before `:app:assembleDebug` and uploads `QuantDesk-Prism-2.0.0`.
