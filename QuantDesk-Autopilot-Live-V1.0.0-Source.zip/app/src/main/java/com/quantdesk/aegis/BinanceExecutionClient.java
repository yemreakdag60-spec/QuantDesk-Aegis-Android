package com.quantdesk.aegis;

import android.app.Activity;
import android.webkit.WebView;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/** Live USD-M Futures executor. Credentials remain in process memory and are never persisted. */
final class BinanceExecutionClient {
    private static final String BASE = "https://fapi.binance.com";
    private final Activity activity;
    private final WebView webView;
    private final OkHttpClient http = new OkHttpClient();
    private final Set<String> submitted = ConcurrentHashMap.newKeySet();
    private volatile String apiKey = "";
    private volatile String apiSecret = "";
    private volatile boolean enabled;

    BinanceExecutionClient(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    synchronized String configure(String key, String secret, String confirmation) {
        String k = key == null ? "" : key.trim();
        String s = secret == null ? "" : secret.trim();
        if (!"CANLI İŞLEMİ ONAYLIYORUM".equals(confirmation)) {
            clear();
            return json(false, "Canlı işlem onay cümlesi eşleşmedi.");
        }
        if (k.length() < 16 || s.length() < 16) {
            clear();
            return json(false, "API anahtarı veya secret geçersiz.");
        }
        apiKey = k;
        apiSecret = s;
        enabled = true;
        return json(true, "CANLI emir motoru etkin. Anahtarlar yalnız bellekte tutuluyor.");
    }

    synchronized void clear() {
        enabled = false;
        apiKey = "";
        apiSecret = "";
        submitted.clear();
    }

    String status() {
        return json(enabled, enabled ? "CANLI emir motoru etkin" : "Binance bağlantısı kapalı");
    }

    void submit(String symbol, String direction, String quantity, String stop, String takeProfit, int leverage, String fingerprint) {
        final String sym = safeSymbol(symbol);
        final String dir = "SHORT".equals(direction) ? "SHORT" : "LONG";
        final String qty = safeNumber(quantity);
        final String sl = safeNumber(stop);
        final String tp = safeNumber(takeProfit);
        final String fp = fingerprint == null ? "" : fingerprint.replaceAll("[^A-Za-z0-9_.|:-]", "");
        if (!enabled) { callback(json(false, "Emir motoru etkin değil.")); return; }
        if (sym.isEmpty() || qty.isEmpty() || sl.isEmpty() || tp.isEmpty() || fp.isEmpty()) { callback(json(false, "Emir parametreleri geçersiz.")); return; }
        if (!submitted.add(fp)) { callback(json(false, "Bu sinyal daha önce işlendi; tekrar emir gönderilmedi.")); return; }
        final int lev=Math.max(1,Math.min(20,leverage));
        new Thread(() -> execute(sym, dir, qty, sl, tp, lev, fp), "binance-live-order").start();
    }

    private void execute(String symbol, String direction, String qty, String sl, String tp, int leverage, String fp) {
        try {
            JSONObject account = new JSONObject(signed("GET", "/fapi/v3/account", new LinkedHashMap<>()));
            if (!account.optBoolean("canTrade", false)) throw new IllegalStateException("Binance hesabında Futures işlem yetkisi yok.");
            JSONObject positionMode = new JSONObject(signed("GET", "/fapi/v1/positionSide/dual", new LinkedHashMap<>()));
            if (positionMode.optBoolean("dualSidePosition", false)) throw new IllegalStateException("Hedge Mode desteklenmiyor; Binance Futures Position Mode ayarını One-way yap.");
            JSONArray positions = new JSONArray(signed("GET", "/fapi/v3/positionRisk", new LinkedHashMap<>()));
            for (int i=0;i<positions.length();i++) if (Math.abs(positions.getJSONObject(i).optDouble("positionAmt",0))>0) throw new IllegalStateException("Azami bir pozisyon kuralı: hesapta zaten açık Futures pozisyonu var.");
            JSONArray orders = new JSONArray(signed("GET", "/fapi/v1/openOrders", map("symbol", symbol)));
            if (orders.length()>0) throw new IllegalStateException("Bu sembolde açık emir var.");
            JSONArray algoOrders = new JSONArray(signed("GET", "/fapi/v1/openAlgoOrders", map("symbol", symbol)));
            if (algoOrders.length()>0) throw new IllegalStateException("Bu sembolde açık koşullu/algo emir var.");
            signed("POST", "/fapi/v1/leverage", map("symbol",symbol,"leverage",String.valueOf(leverage)));

            String entrySide = "LONG".equals(direction) ? "BUY" : "SELL";
            String exitSide = "LONG".equals(direction) ? "SELL" : "BUY";
            Map<String,String> entry = map("symbol",symbol,"side",entrySide,"type","MARKET","quantity",qty,
                    "newOrderRespType","RESULT","newClientOrderId",clientId("qdE",fp));
            JSONObject filled = new JSONObject(signed("POST", "/fapi/v1/order", entry));
            double executed = filled.optDouble("executedQty", 0);
            if (executed <= 0) throw new IllegalStateException("Piyasa emri dolmadı; koruma emirleri gönderilmedi.");

            boolean slOk=false, tpOk=false;
            try {
                signed("POST", "/fapi/v1/algoOrder", map("algoType","CONDITIONAL","symbol",symbol,"side",exitSide,
                        "type","STOP_MARKET","triggerPrice",sl,"closePosition","true","workingType","MARK_PRICE",
                        "clientAlgoId",clientId("qdS",fp)));
                slOk=true;
                signed("POST", "/fapi/v1/algoOrder", map("algoType","CONDITIONAL","symbol",symbol,"side",exitSide,
                        "type","TAKE_PROFIT_MARKET","triggerPrice",tp,"closePosition","true","workingType","MARK_PRICE",
                        "clientAlgoId",clientId("qdT",fp)));
                tpOk=true;
            } finally {
                if (!slOk || !tpOk) {
                    // Fail closed: flatten the just-opened one-way position if both protections are not confirmed.
                    try { signed("DELETE", "/fapi/v1/algoOpenOrders", map("symbol",symbol)); } catch (Exception ignored) { }
                    try { signed("POST", "/fapi/v1/order", map("symbol",symbol,"side",exitSide,"type","MARKET",
                            "quantity",qty,"reduceOnly","true","newOrderRespType","RESULT","newClientOrderId",clientId("qdX",fp))); }
                    catch (Exception ignored) { }
                }
            }
            if (!slOk || !tpOk) throw new IllegalStateException("SL/TP birlikte onaylanmadı; acil reduce-only kapatma denendi. Binance hesabını hemen kontrol et.");
            callback("{\"ok\":true,\"message\":\"CANLI pozisyon açıldı; SL ve TP Binance tarafından onaylandı.\",\"symbol\":\""+symbol+"\"}");
        } catch (Exception e) {
            submitted.remove(fp);
            callback(json(false, e.getMessage()==null?"Binance emir hatası":e.getMessage()));
        }
    }

    private String signed(String method, String path, Map<String,String> params) throws Exception {
        String key=apiKey, secret=apiSecret;
        if (!enabled || key.isEmpty() || secret.isEmpty()) throw new IllegalStateException("Emir motoru kapalı.");
        long serverTime = new JSONObject(publicGet("/fapi/v1/time")).getLong("serverTime");
        params.put("timestamp", String.valueOf(serverTime));
        params.put("recvWindow", "5000");
        String query = encode(params);
        params.put("signature", hmac(query, secret));
        Request.Builder builder = new Request.Builder().header("X-MBX-APIKEY", key);
        if ("GET".equals(method) || "DELETE".equals(method)) {
            HttpUrl.Builder url = HttpUrl.parse(BASE+path).newBuilder();
            for (Map.Entry<String,String> e:params.entrySet()) url.addQueryParameter(e.getKey(),e.getValue());
            builder.url(url.build());
            if ("GET".equals(method)) builder.get(); else builder.delete();
        } else {
            FormBody.Builder body = new FormBody.Builder();
            for (Map.Entry<String,String> e:params.entrySet()) body.add(e.getKey(),e.getValue());
            builder.url(BASE+path).post(body.build());
        }
        try(Response response=http.newCall(builder.build()).execute()) {
            String text=response.body()==null?"":response.body().string();
            if(!response.isSuccessful()) throw new IllegalStateException("Binance "+response.code()+": "+sanitize(text));
            return text;
        }
    }

    private String publicGet(String path) throws Exception {
        try(Response response=http.newCall(new Request.Builder().url(BASE+path).get().build()).execute()) {
            String text=response.body()==null?"":response.body().string();
            if(!response.isSuccessful()) throw new IllegalStateException("Binance saat servisi yanıt vermedi.");
            return text;
        }
    }

    private void callback(String json) {
        activity.runOnUiThread(() -> webView.evaluateJavascript("window.onAutoTradeResult&&window.onAutoTradeResult("+JSONObject.quote(json)+")", null));
    }
    private static String safeSymbol(String s){String v=s==null?"":s.toUpperCase(Locale.US).replaceAll("[^A-Z0-9]","");return v.endsWith("USDT")&&v.length()>=7&&v.length()<=20?v:"";}
    private static String safeNumber(String s){if(s==null||!s.matches("[0-9]+(?:\\.[0-9]+)?"))return"";double v=Double.parseDouble(s);return Double.isFinite(v)&&v>0?s:"";}
    private static String sanitize(String s){return s==null?"":s.replaceAll("[\\r\\n]"," ").substring(0,Math.min(300,s.length()));}
    private static String json(boolean ok,String message){return "{\"ok\":"+ok+",\"message\":"+JSONObject.quote(message==null?"":message)+"}";}
    private static String clientId(String prefix,String fp){String clean=fp.replaceAll("[^A-Za-z0-9]","");return (prefix+clean).substring(0,Math.min(32,prefix.length()+clean.length()));}
    private static Map<String,String> map(String... pairs){Map<String,String> m=new LinkedHashMap<>();for(int i=0;i+1<pairs.length;i+=2)m.put(pairs[i],pairs[i+1]);return m;}
    private static String encode(Map<String,String> p){FormBody.Builder b=new FormBody.Builder();for(Map.Entry<String,String>e:p.entrySet())b.add(e.getKey(),e.getValue());RequestBody body=b.build();okio.Buffer buf=new okio.Buffer();try{body.writeTo(buf);}catch(Exception e){throw new IllegalStateException(e);}return buf.readUtf8();}
    private static String hmac(String value,String secret)throws Exception{Mac mac=Mac.getInstance("HmacSHA256");mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8),"HmacSHA256"));StringBuilder out=new StringBuilder();for(byte b:mac.doFinal(value.getBytes(StandardCharsets.UTF_8)))out.append(String.format(Locale.US,"%02x",b&0xff));return out.toString();}
}
