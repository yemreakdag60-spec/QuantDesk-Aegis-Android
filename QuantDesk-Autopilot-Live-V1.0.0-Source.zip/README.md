# QuantDesk Autopilot Live

Bu paket Binance USDⓈ-M Futures ve Spot için Android analiz aracıdır. 200 USDT paritesini tarar, 6 doğal ve 10 türetilmiş zaman dilimini değerlendirir; BTC rejimi/bağı, likidite, erişilebilir hedef, maliyet, tazelik ve canlı order-flow kapıları geçilmeden plan yayımlamaz.

- Ayrı kurulum kimliği: `com.quantdesk.autopilot.live.v100`; V4.7.4/V4.8.2 ile yan yana kurulabilir.
- BTC teknik motoru OI, funding, taker akışı, CVD, defter baskısı, long/short kalabalığı ve tasfiye eğilimiyle canlı doğrulanır.
- Coin-BTC bağı kısa/orta/uzun korelasyon, kararlılık ve düşüş korelasyonuyla ölçülür.
- TP geçmiş testi bağımsız 15 dakikalık pencereler, rejim/volatilite eşleşmesi ve güven alt sınırı kullanır.
- Düşük R/R planı iki ardışık güçlü canlı order-flow desteği olmadan yayımlanmaz.
- Arka plan servisi order-flow verisini ve yayımlanan planların TP1/SL sonucunu ekran kapalıyken izler.
- Kullanıcı açıkça CANLI modu etkinleştirince USDⓈ-M Futures piyasa emri gönderir; ardından Binance'in koşullu emir sistemiyle SL ve TP kurar.
- API Key ve Secret yalnız işlem belleğinde tutulur, diske yazılmaz; uygulama kapanınca silinir. Anahtara çekim yetkisi verilmemelidir.
- One-way Position Mode, aynı anda en fazla bir açık Futures pozisyonu, tekrarlı sinyal koruması ve iki ardışık SL sonrası risk kilidi uygulanır.
- SL veya TP birlikte onaylanmazsa reduce-only acil kapatma denenir ve otomatik mod kapatılır.

Kurulum: ZIP'i açıp içindekileri GitHub deposunun ana dizinine yükleyin. **Actions > Build QuantDesk Autopilot Live Separate APK > Run workflow** yolunu çalıştırın. Tamamlanınca Artifacts bölümündeki `QuantDesk-Autopilot-Live-V1.0.0-SEPARATE` paketinden `app-debug.apk` dosyasını kurun.

Platform sınırı: ekran kapalıyken order-flow ve daha önce yayımlanan planların sonucu izlenir. 200 coinlik tam teknik yeniden tarama WebView açıkken yapılır; gerçek 7/24 tam tarama ayrıca sunucu tarafı motor gerektirir.

Canlı kullanım: Binance'te yalnız Futures işlem yetkili, çekim yetkisiz bir API anahtarı oluşturun. Uygulamada anahtarları girin, `CANLI İŞLEMİ ONAYLIYORUM` yazın ve canlı otomatiği etkinleştirin. Testnet kullanılmaz.

## Verification

```bash
for f in tools/validate-ui.js tools/test-*.js; do node "$f"; done
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
```

GitHub Actions installs Java and Gradle, runs all source/UI invariants, builds the debug APK and enforces Android Lint.
