import base64, hashlib, sys, zipfile

apk, sf_out = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(apk, 'r') as z:
    names = [n for n in z.namelist() if not n.upper().startswith('META-INF/') and not n.endswith('/')]
    sections = []
    for name in names:
        digest = base64.b64encode(hashlib.sha256(z.read(name)).digest()).decode()
        sections.append(f"Name: {name}\r\nSHA-256-Digest: {digest}\r\n\r\n")
manifest = "Manifest-Version: 1.0\r\nCreated-By: QuantDesk Aegis Pro\r\n\r\n" + ''.join(sections)
sf = ("Signature-Version: 1.0\r\nCreated-By: QuantDesk Aegis Pro\r\n"
      "SHA-256-Digest-Manifest: " + base64.b64encode(hashlib.sha256(manifest.encode()).digest()).decode() + "\r\n\r\n")
open('MANIFEST.MF','wb').write(manifest.encode())
open(sf_out,'wb').write(sf.encode())
