# FlowScope Futures 1.0.1

Android app for Binance USDⓈ-M Futures market analysis. This is a separate app identity (`com.emreakdag.flowscope`) and does not replace the uploaded APK.

## Included

- Live order flow from Binance Futures: aggregate trades and force-order publications over the `/market` route, depth updates over `/public`.
- Order book snapshot plus update-ID and previous-update-ID (`pu`) sequencing; the book is resynchronized after gaps and both sockets reconnect with backoff.
- Aggressor-side buy/sell notional and a 15-minute rolling CVD, near-mid bid/ask notional imbalance, and liquidation totals.
- OHLCV table for the selected contract with interval controls; base volume and USDT quote volume are shown separately.
- Existing multi-timeframe market analysis and risk calculator are retained in a newly branded app.
- A foreground Android service stores minute-level trade-flow, observed force-order publications, and best-bid/ask notional in a local SQLite database, so summaries remain available after the screen closes. It restarts after normal device boot when Android permits the service start.
- Public market data only. No trading, private account access, or API keys.

Flow measurements are market data summaries, not a promise of direction or execution. The app labels the live flow as warming up until it has fresh trades and a synchronized book. Binance may publish only observed force-order updates; these are shown as observed publications, not a complete liquidation ledger. It does not claim to detect spoofing from public snapshots.

## Build APK

Open this folder as an Android project in Android Studio, or push it to a GitHub repository and run **Actions → Build FlowScope Futures APK → Run workflow**. The workflow builds `app-debug.apk` as a downloadable artifact. Install it alongside the old app; the package IDs differ.
