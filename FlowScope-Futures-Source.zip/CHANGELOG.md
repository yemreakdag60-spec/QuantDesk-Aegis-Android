# 1.0.0

- Introduced FlowScope Futures as a separate Android app/package identity.
- Replaced the unavailable native order-flow dependency with the public Binance USDⓈ-M stream.
- Added stream reconnect, initial depth snapshot, update sequence checks, and recovery after sequence gaps.
- Added rolling CVD, buyer/seller aggressor notional, near-mid depth imbalance, and liquidation flow.
- Added selectable interval OHLCV table with both base and quote volume.


# 1.0.1

- Restored the Android foreground collector and local SQLite flow history missing from the first source package.
- Added a boot receiver that attempts to resume the last selected symbol.
- Exposed the saved 15-minute background summary to the analysis screen.
- Background stream uses separated Binance market/public routes; full synchronized depth remains in the active app panel.
