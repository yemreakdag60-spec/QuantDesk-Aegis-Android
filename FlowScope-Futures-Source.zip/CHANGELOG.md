# 1.0.0

- Introduced FlowScope Futures as a separate Android app/package identity.
- Replaced the unavailable native order-flow dependency with the public Binance USDⓈ-M stream.
- Added stream reconnect, initial depth snapshot, update sequence checks, and recovery after sequence gaps.
- Added rolling CVD, buyer/seller aggressor notional, near-mid depth imbalance, and liquidation flow.
- Added selectable interval OHLCV table with both base and quote volume.
