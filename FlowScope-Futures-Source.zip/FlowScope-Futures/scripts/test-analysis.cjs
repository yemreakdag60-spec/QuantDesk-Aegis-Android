const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const htmlPath = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const match = html.match(/<script>([\s\S]*?)<\/script>/);
assert.ok(match, 'analysis script exists');
const appJs = match[1];
new vm.Script(appJs, { filename: 'index.html inline script' });

const start = appJs.indexOf("const API='https://fapi.binance.com';");
const end = appJs.indexOf('function moveProbabilities(');
assert.ok(start >= 0 && end > start, 'indicator/model functions are in expected section');
const prelude = appJs.slice(start, end);
const sandbox = {};
vm.runInNewContext(`${prelude}\nthis.__api={tfScore,flowScopeModel,buildSets,aggregateMs};`, sandbox);
const { tfScore, flowScopeModel, buildSets, aggregateMs } = sandbox.__api;

function candles(count, trend = 1, step = 60_000) {
  const rows = [];
  let price = 100;
  for (let i = 0; i < count; i++) {
    price *= 1 + trend * 0.0008;
    const open = price * (1 - trend * 0.0002);
    const high = Math.max(open, price) * 1.002;
    const low = Math.min(open, price) * 0.998;
    const volume = 100 + (i % 7) * 3;
    rows.push([i * step, open, high, low, price, volume, (i + 1) * step - 1, volume * price, 20, volume * 0.6, volume * price * 0.6, '0']);
  }
  return rows;
}

const insufficient = tfScore(candles(20));
assert.equal(insufficient.valid, false, 'short history is excluded from scoring');
const enough = tfScore(candles(100));
assert.equal(enough.valid, true, 'adequate history is marked valid');
assert.ok(Number.isFinite(enough.score) && enough.score >= -90 && enough.score <= 90, 'technical score is finite and bounded');

const intervals = ['15m','30m','1h','2h','3h','4h','6h','12h','24h'];
const up = Object.fromEntries(intervals.map(tf => [tf, { valid: true, score: 55, rsi: 62, macd: 1, atr: 1, last: 100, taker: .58, vr: 1.4, structure: 'HH-HL', ichi: 1, supertrend: 1, donchian: 'Kırılım ↑' }]));
const down = Object.fromEntries(intervals.map(tf => [tf, { ...up[tf], score: -55, rsi: 38, macd: -1, taker: .42, structure: 'LH-LL', ichi: -1, supertrend: -1, donchian: 'Kırılım ↓' }]));
const bullish = flowScopeModel(up, 1.5, .05);
const bearish = flowScopeModel(down, -1.5, .05);
assert.ok(bullish.bias > 0 && bullish.bias <= 100, 'bullish factors produce a bounded positive model bias');
assert.ok(bearish.bias < 0 && bearish.bias >= -100, 'bearish factors produce a bounded negative model bias');
assert.equal(bullish.coverage, 9, 'full model coverage counts valid horizons');
const sparse = { ...up, '24h': { ...up['24h'], valid: false, score: -90 } };
const reduced = flowScopeModel(sparse, 1.5, .05);
assert.equal(reduced.coverage, 8, 'invalid timeframe is not counted as coverage');
assert.ok(reduced.bias > 0, 'invalid timeframe cannot reverse the model');
assert.ok(Number.isFinite(flowScopeModel({}, 0, 0).bias), 'empty input stays finite');
assert.equal(flowScopeModel({}, 0, 0).quality, 0, 'empty input cannot receive a positive quality rating');

const base = { '1m': candles(160, 1, 60_000), '5m': candles(240, 1, 300_000), '15m': candles(300, 1, 900_000), '1h': candles(360, 1, 3_600_000), '4h': candles(300, 1, 14_400_000) };
const sets = buildSets(base);
for (const tf of intervals) assert.ok(Array.isArray(sets[tf]), `${tf} horizon is produced`);
assert.ok(sets['24h'].length >= 30, '4h history supports at least 30 aggregated daily candles');
assert.ok(sets['12h'].length >= 30, '4h history supports at least 30 aggregated 12h candles');
assert.ok(aggregateMs(candles(20), 600_000).length > 0, 'aggregation produces buckets');

console.log('PASS: script syntax, candle sufficiency, bounded scores, ensemble direction/coverage, and higher-timeframe history');
