# FlowScope Futures 1.1.0

A separate Android app (`com.emreakdag.flowscope`) for Binance USDⓈ-M market analysis. It installs beside the original app and does not replace it.

## What is included

- **FlowScope Atlas**, a purpose-built, explainable ensemble. It scores multi-timeframe trend, momentum, price structure, taker/volume participation, relative strength versus BTC, derivatives and live order-flow. The UI exposes factor scores and data coverage.
- Missing or short candle histories are excluded from the ensemble and timeframe alignment. Kline requests now supply enough history for the 12h and 24h aggregates to pass the 30-candle minimum.
- Direction percentages are normalized model scores, not calibrated event probabilities. Atlas is a deterministic rule-based model, not a trained or independently performance-certified forecasting model.
- PRO pass for the leading candidates adds open interest, crowding, taker volume and order-book depth. A final live check revalidates price levels and can veto a setup when live trades or book data oppose it.
- Live Binance Futures order flow: aggregate trades, force-order publications and synchronized depth snapshots/deltas. Depth sequence gaps trigger resynchronization; sockets reconnect with backoff.
- Rolling aggressive buy/sell quote notional, CVD, near-mid book imbalance, observed liquidation publications, plus an OHLCV table with selectable interval and separate base/quote volumes.
- A native Android foreground collector records the selected symbol's trade flow, observed force orders and best-bid/ask notional in local SQLite. This is the app's local persistence layer; there is no hosted proprietary server or private-account connection.
- Custom FlowScope icon and app identity. No API key, trading permission or order execution.

## Build and checks

Open this directory in Android Studio, or push it to GitHub and run **Actions → Build FlowScope Futures APK → Run workflow**. The workflow uploads the debug APK as `FlowScope-Futures-1.1.0`.

Run the analysis and timeframe regression checks with:

```sh
node scripts/test-analysis.cjs
```

The Node checks cover script syntax, short-history exclusion, bounded scores, ensemble direction and coverage, and higher-timeframe candle sufficiency. They do not replace an Android SDK build or a live exchange test. The project does not contain a compiled APK.

Market data and model scores are informational; they do not predict execution quality or guarantee returns. Binance force-order streams show published observations, not a complete liquidation ledger. The app does not claim to detect spoofing from public snapshots.
