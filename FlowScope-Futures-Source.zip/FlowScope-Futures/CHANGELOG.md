# 1.0.0

- Introduced FlowScope Futures as a separate Android app/package identity.
- Replaced the unavailable native order-flow dependency with the public Binance USDⓈ-M stream.
- Added stream reconnect, initial depth snapshot, update sequence checks, and recovery after sequence gaps.
- Added rolling CVD, buyer/seller aggressor notional, near-mid depth imbalance, and liquidation flow.
- Added selectable interval OHLCV table with both base and quote volume.


# 1.0.1

- Restored the Android foreground collector and local SQLite flow history missing from the first source package.
- Added a boot receiver that attempts to resume the last selected symbol.
- Exposed the saved 15-minute background summary to the analysis screen.
- Background stream uses separated Binance market/public routes; full synchronized depth remains in the active app panel.

# 1.1.0

- Added FlowScope Atlas, a transparent weighted ensemble with trend, momentum, structure, participation, BTC-relative strength, derivative and live-flow factors.
- Added explicit data-coverage tracking; incomplete timeframes no longer count as neutral inputs or alignment votes.
- Increased 1h/4h candle history so aggregated 12h/24h horizons can meet the minimum history requirement.
- Relabeled sigmoid outputs as model scores and stated that they are not calibrated probabilities.
- Added synthetic regression checks for model bounds, direction, data sufficiency and higher-timeframe aggregation.
- Updated the Android version and CI artifact name to 1.1.0.
