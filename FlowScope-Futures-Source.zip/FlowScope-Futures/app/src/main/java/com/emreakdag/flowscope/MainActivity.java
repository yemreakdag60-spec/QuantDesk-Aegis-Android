package com.emreakdag.flowscope;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;

public final class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(6, 16, 28));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(6, 16, 28));
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},71);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true); settings.setSupportZoom(false); settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false); settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW); settings.setAllowFileAccessFromFileURLs(true); settings.setAllowUniversalAccessFromFileURLs(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){return !"file".equalsIgnoreCase(request.getUrl().getScheme());}});
        webView.addJavascriptInterface(new AegisBridge(this),"AegisNative");
        setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
    }
    public static final class AegisBridge {
        private final Context context;
        AegisBridge(Context c){context=c.getApplicationContext();}
        @JavascriptInterface public void setSymbol(String symbol){if(symbol==null||!symbol.matches("[A-Z0-9]{3,24}USDT"))return;try{MarketDataService.start(context,symbol);}catch(RuntimeException ignored){}}
        @JavascriptInterface public String flow(String symbol){if(symbol==null||!symbol.matches("[A-Z0-9]{3,24}USDT"))return "{}";FlowDb db=new FlowDb(context);try{return db.summary(symbol,System.currentTimeMillis()/60000-14);}finally{db.close();}}
        @JavascriptInterface public String status(){long t=context.getSharedPreferences("flowscope",MODE_PRIVATE).getLong("last_data_ms",0);String s=context.getSharedPreferences("flowscope",MODE_PRIVATE).getString("service_status","Başlatılıyor");return s+(t>0?" • son kayıt "+Math.max(0,(System.currentTimeMillis()-t)/1000)+" sn önce":"");}
    }
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(webView!=null){webView.stopLoading();webView.destroy();webView=null;}super.onDestroy();}
}
