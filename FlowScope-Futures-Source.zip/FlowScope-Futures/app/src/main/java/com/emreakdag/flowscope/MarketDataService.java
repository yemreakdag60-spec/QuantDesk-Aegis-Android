package com.emreakdag.flowscope;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;
import org.json.JSONObject;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ScheduledFuture;

public final class MarketDataService extends Service {
    public static final String ACTION_SET_SYMBOL="com.emreakdag.flowscope.SET_SYMBOL";
    private static final String CHANNEL="flowscope_market_data";
    private final OkHttpClient http=new OkHttpClient.Builder().pingInterval(30,TimeUnit.SECONDS).retryOnConnectionFailure(true).build();
    private final Map<Long,FlowDb.Bucket> buckets=new ConcurrentHashMap<>();
    private final ScheduledExecutorService timer=Executors.newSingleThreadScheduledExecutor();
    private FlowDb db; private WebSocket marketSocket,bookSocket; private ScheduledFuture<?> reconnectTask; private String symbol="BTCUSDT"; private long lastMessage; private int backoff=2,generation=0; private volatile boolean stopped;

    public static void start(Context c,String symbol) {
        Intent i=new Intent(c,MarketDataService.class).setAction(ACTION_SET_SYMBOL).putExtra("symbol",symbol);
        if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);
    }
    @Override public void onCreate(){super.onCreate();db=new FlowDb(this);createChannel();startForeground(71,notification("Piyasa verisi hazırlanıyor"));timer.scheduleAtFixedRate(this::flush,5,5,TimeUnit.SECONDS);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String next=intent==null?null:intent.getStringExtra("symbol");
        if(next==null||!next.matches("[A-Z0-9]{3,24}USDT"))next=getSharedPreferences("flowscope",MODE_PRIVATE).getString("symbol","BTCUSDT");
        if(!next.equals(symbol)||marketSocket==null||bookSocket==null){symbol=next;getSharedPreferences("flowscope",MODE_PRIVATE).edit().putString("symbol",symbol).apply();connectStreams();}
        return START_STICKY;
    }
    private synchronized void connectStreams(){
        stopped=true;final int gen=++generation;if(reconnectTask!=null){reconnectTask.cancel(false);reconnectTask=null;}closeSockets();stopped=false;buckets.clear();db.restore(symbol,System.currentTimeMillis()/60000-15,buckets);lastMessage=0;
        final String s=symbol.toLowerCase();
        marketSocket=http.newWebSocket(new Request.Builder().url("wss://fstream.binance.com/market/stream?streams="+s+"@aggTrade/"+s+"@forceOrder").build(),new WebSocketListener(){
            @Override public void onOpen(WebSocket ws,Response r){backoff=2;updateNotification("Canlı işlem akışı: "+symbol);}
            @Override public void onMessage(WebSocket ws,String text){handleMarket(text);}
            @Override public void onMessage(WebSocket ws,ByteString bytes){handleMarket(bytes.utf8());}
            @Override public void onFailure(WebSocket ws,Throwable t,Response r){if(gen==generation)scheduleReconnect();}
            @Override public void onClosed(WebSocket ws,int code,String reason){if(gen==generation)scheduleReconnect();}
        });
        bookSocket=http.newWebSocket(new Request.Builder().url("wss://fstream.binance.com/public/stream?streams="+s+"@bookTicker").build(),new WebSocketListener(){
            @Override public void onOpen(WebSocket ws,Response r){backoff=2;}
            @Override public void onMessage(WebSocket ws,String text){handleBook(text);}
            @Override public void onFailure(WebSocket ws,Throwable t,Response r){if(gen==generation)scheduleReconnect();}
            @Override public void onClosed(WebSocket ws,int code,String reason){if(gen==generation)scheduleReconnect();}
        });
    }
    private synchronized void handleMarket(String text){try{JSONObject root=new JSONObject(text),d=root.optJSONObject("data");if(d==null)return;String stream=root.optString("stream","");long t=System.currentTimeMillis();FlowDb.Bucket b=bucket(t);if(stream.contains("@aggTrade")){double n=d.optDouble("p")*d.optDouble("q");if(d.optBoolean("m"))b.sell+=n;else b.buy+=n;b.trades++;lastMessage=t;}else if(stream.contains("@forceOrder")){JSONObject o=d.optJSONObject("o");if(o!=null){double n=o.optDouble("ap",o.optDouble("p"))*o.optDouble("q");if("SELL".equals(o.optString("S")))b.longLiq+=n;else if("BUY".equals(o.optString("S")))b.shortLiq+=n;lastMessage=t;}}}catch(Exception ignored){}}
    private synchronized void handleBook(String text){try{JSONObject root=new JSONObject(text),d=root.optJSONObject("data");if(d==null)return;double bid=d.optDouble("b")*d.optDouble("B"),ask=d.optDouble("a")*d.optDouble("A");FlowDb.Bucket b=bucket(System.currentTimeMillis());b.bidDepth=bid;b.askDepth=ask;b.depthSamples++;lastMessage=System.currentTimeMillis();}catch(Exception ignored){}}
    private FlowDb.Bucket bucket(long time){long minute=time/60000;return buckets.computeIfAbsent(minute,k->new FlowDb.Bucket());}
    private synchronized void flush(){try{if(db==null)return;long now=System.currentTimeMillis(),cut=now/60000-15;for(Map.Entry<Long,FlowDb.Bucket> e:new LinkedHashMap<>(buckets).entrySet()){if(e.getKey()>=cut)db.save(symbol,e.getKey(),e.getValue(),lastMessage);}buckets.keySet().removeIf(m->m<cut);db.getWritableDatabase().delete("flow_minute","minute<?",new String[]{String.valueOf(now/60000-1440)});if(lastMessage>0){getSharedPreferences("flowscope",MODE_PRIVATE).edit().putLong("last_data_ms",lastMessage).putString("service_status","Kayıt sürüyor").apply();updateNotification("Order-flow kayıtlı • "+symbol+" • "+Math.max(0,(now-lastMessage)/1000)+" sn önce");}}catch(Exception ignored){}}
    private synchronized void scheduleReconnect(){if(stopped||(reconnectTask!=null&&!reconnectTask.isDone()))return;int delay=backoff;backoff=Math.min(60,backoff*2);reconnectTask=timer.schedule(()->{reconnectTask=null;if(!stopped)connectStreams();},delay,TimeUnit.SECONDS);}
    private void closeSockets(){if(marketSocket!=null){marketSocket.close(1000,"switch");marketSocket=null;}if(bookSocket!=null){bookSocket.close(1000,"switch");bookSocket=null;}}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"FlowScope piyasa verisi",NotificationManager.IMPORTANCE_LOW);c.setDescription("Kullanıcı isteğiyle canlı order-flow verisini kaydeder");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    private Notification notification(String text){Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);return b.setSmallIcon(android.R.drawable.ic_menu_info_details).setContentTitle("FlowScope Futures").setContentText(text).setContentIntent(pi).setOngoing(true).build();}
    private void updateNotification(String s){try{((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(71,notification(s));}catch(Exception ignored){}}
    @Override public void onDestroy(){stopped=true;closeSockets();if(timer!=null)timer.shutdownNow();if(reconnectTask!=null)reconnectTask.cancel(false);if(db!=null)db.close();getSharedPreferences("flowscope",MODE_PRIVATE).edit().putString("service_status","Durduruldu").apply();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
