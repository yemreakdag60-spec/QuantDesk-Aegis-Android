package com.emreakdag.flowscope;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public final class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || !Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        String symbol=context.getSharedPreferences("flowscope",Context.MODE_PRIVATE).getString("symbol","BTCUSDT");
        try { MarketDataService.start(context,symbol); } catch (RuntimeException ignored) { }
    }
}
