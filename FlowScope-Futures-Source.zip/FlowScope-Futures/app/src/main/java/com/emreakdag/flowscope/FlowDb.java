package com.emreakdag.flowscope;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONObject;

final class FlowDb extends SQLiteOpenHelper {
    FlowDb(Context c) { super(c, "flowscope_flow.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE flow_minute(symbol TEXT NOT NULL, minute INTEGER NOT NULL, buy REAL NOT NULL DEFAULT 0, sell REAL NOT NULL DEFAULT 0, trades INTEGER NOT NULL DEFAULT 0, bid_depth REAL NOT NULL DEFAULT 0, ask_depth REAL NOT NULL DEFAULT 0, long_liq REAL NOT NULL DEFAULT 0, short_liq REAL NOT NULL DEFAULT 0, depth_samples INTEGER NOT NULL DEFAULT 0, updated_ms INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(symbol,minute))");
        db.execSQL("CREATE INDEX flow_minute_time ON flow_minute(minute)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    synchronized void save(String symbol, long minute, Bucket b, long updated) {
        ContentValues v = new ContentValues();
        v.put("symbol", symbol); v.put("minute", minute); v.put("buy", b.buy); v.put("sell", b.sell);
        v.put("trades", b.trades); v.put("bid_depth", b.bidDepth); v.put("ask_depth", b.askDepth);
        v.put("long_liq", b.longLiq); v.put("short_liq", b.shortLiq); v.put("depth_samples", b.depthSamples); v.put("updated_ms", updated);
        getWritableDatabase().insertWithOnConflict("flow_minute", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }

    synchronized void restore(String symbol, long fromMinute, java.util.Map<Long, Bucket> into) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT minute,buy,sell,trades,bid_depth,ask_depth,long_liq,short_liq,depth_samples FROM flow_minute WHERE symbol=? AND minute>=? ORDER BY minute", new String[]{symbol, String.valueOf(fromMinute)})) {
            while (c.moveToNext()) {
                Bucket b = new Bucket(); long minute = c.getLong(0);
                b.buy=c.getDouble(1); b.sell=c.getDouble(2); b.trades=c.getInt(3); b.bidDepth=c.getDouble(4); b.askDepth=c.getDouble(5); b.longLiq=c.getDouble(6); b.shortLiq=c.getDouble(7); b.depthSamples=c.getInt(8);
                into.put(minute,b);
            }
        }
    }

    synchronized String summary(String symbol, long sinceMinute) {
        JSONObject out = new JSONObject();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COALESCE(SUM(buy),0),COALESCE(SUM(sell),0),COALESCE(SUM(trades),0),COALESCE(AVG(bid_depth),0),COALESCE(AVG(ask_depth),0),COALESCE(SUM(long_liq),0),COALESCE(SUM(short_liq),0),COALESCE(SUM(depth_samples),0),COALESCE(MAX(updated_ms),0),COUNT(*) FROM flow_minute WHERE symbol=? AND minute>=?", new String[]{symbol, String.valueOf(sinceMinute)})) {
            if (c.moveToFirst()) {
                out.put("symbol",symbol); out.put("buy",c.getDouble(0)); out.put("sell",c.getDouble(1)); out.put("trades",c.getLong(2)); out.put("bidDepthAvg",c.getDouble(3)); out.put("askDepthAvg",c.getDouble(4)); out.put("longLiquidations",c.getDouble(5)); out.put("shortLiquidations",c.getDouble(6)); out.put("depthSamples",c.getLong(7)); out.put("updatedAt",c.getLong(8)); out.put("minutes",c.getInt(9));
            }
        } catch (Exception ignored) { }
        return out.toString();
    }

    static final class Bucket {
        double buy, sell, bidDepth, askDepth, longLiq, shortLiq;
        int trades, depthSamples;
    }
}
