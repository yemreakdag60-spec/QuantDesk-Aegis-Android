const fs = require('fs');

const java = fs.readFileSync('app/src/main/java/com/quantdesk/aegis/BinanceExecutionClient.java', 'utf8');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');

for (const required of [
  'confirmation.trim()',
  'verifyConfiguration',
  '"/fapi/v2/account"',
  '"/fapi/v1/positionSide/dual"',
  'account.optBoolean("canTrade", false)',
  'enabled = true',
  'configurationCallback'
]) {
  if (!java.includes(required)) throw new Error(`Live API verification guard missing: ${required}`);
}

if (java.includes('new JSONObject(signed("GET", "/fapi/v3/account"')) {
  throw new Error('V3 account response omits canTrade and must not be used for the permission guard');
}

for (const required of [
  'window.onLiveConfigurationResult',
  'BAĞLANTIYI DOĞRULA VE ETKİNLEŞTİR',
  'type="password" autocomplete="off" placeholder="Binance Futures API Key"'
]) {
  if (!html.includes(required)) throw new Error(`Live API verification UI missing: ${required}`);
}

console.log('Signed Binance API, Futures permission, IP response and One-way verification invariants passed');
