# QuantDesk Autopilot Live V1.1.0

## Binance bağlantı güvenliği

- API Key alanı ekranda maskelendi.
- Onay cümlesinde baştaki/sondaki görünmez boşluklar temizleniyor.
- Otomatik motor, Binance'e imzalı bağlantı kurulmadan etkinleşmiyor.
- Futures işlem yetkisi, IP cevabı, kullanılabilir bakiye ve One-way pozisyon modu doğrulanıyor.
- API/Secret yalnız uygulama belleğinde tutuluyor; kalıcı depolamaya yazılmıyor.
- Para çekme veya transfer izni gerekmiyor.

## Dengeli fırsat motoru

- 200 coin taraması korunurken PRO havuzu 50'den 60'a çıkarıldı.
- Likidite/BTC bağı/teknik aday dağılımı 24/18/18 olarak genişletildi.
- İlk canlı doğrulama 30 yerine 40 adaya, periyodik doğrulama 12 yerine 16 adaya uygulanıyor.
- Asgari 24 saat hacim eşiği 25 milyon USDT'den 20 milyon USDT'ye indirildi.
- Canlı order-flow veri kalite eşiği 50'den 45'e dengeli biçimde indirildi.
- BTC bağı alt sınırı ve kararlılık eşiği, güçlü adayların gereksiz elenmesini azaltacak biçimde ayarlandı.
- İşleme uygunluk skoru 62; girişe yakın skoru 54 olarak düzenlendi.
- En az üç güçlü kurulum canlı izleme rafında tutuluyor.

## Korunan sert kapılar

- Geçersiz giriş/SL/TP geometrisi
- Ulaşılamayan veya negatif maliyet-sonrası beklentili TP
- İki canlı kontrolde devam eden güçlü ters order-flow
- Güçlü ters BTC rejimi
- Aşırı spread/volatilite ve fiyatın aşırı uzaması
- Walk-forward ciddi başarısızlığı
- Aynı setup için daha önce alınmış TP veya kırılmış SL
- Aynı anda azami bir Futures pozisyonu
- SL ve TP birlikte onaylanmazsa reduce-only acil kapatma

Bu sürüm fırsat sayısını artırmak için sert zarar korumalarını kaldırmaz. Hiçbir sistem her işlemde kazanç veya belirli sayıda işlem garantisi veremez.
