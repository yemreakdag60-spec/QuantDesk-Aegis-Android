# QuantDesk Aegis V4.5.0 Professional — Separate Install

Standalone Android package: `com.quantdesk.aegis.professional.v450`.
It installs side-by-side with the V4.4 package and uses separate Android app storage/database.

## Live opportunity engine
- 200 USDT perpetual contracts, 5 native + 8 derived timeframes.
- PRO pool is diversified: 30 liquidity leaders + 20 technically strongest viable candidates.
- Native order-flow service keeps the liquid baseline plus priority PRO candidates.
- Order-flow warm-up is a WAIT state, not an automatic rejection.
- Transient live vetoes are rechecked every 15 seconds.
- Signal freshness is adaptive (roughly 90–180 seconds) and still requires current structure, TP freshness, R/R and order-flow.
- No threshold is loosened merely to force a signal.

## Build
Use the included GitHub Actions workflow or Android Studio / Gradle with Java 17, Gradle 8.13 and Android SDK 36.
