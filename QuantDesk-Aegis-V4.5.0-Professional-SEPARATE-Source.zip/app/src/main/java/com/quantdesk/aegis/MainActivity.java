package com.quantdesk.aegis;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.content.Intent;
import android.os.Build;
import android.Manifest;
import android.webkit.JavascriptInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Locale;

public class MainActivity extends ComponentActivity {
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7, 17, 31));
        getWindow().setNavigationBarColor(Color.rgb(7, 17, 31));

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setAllowContentAccess(false);
        s.setAllowFileAccess(true);
        // Required because the bundled local UI retrieves HTTPS public market data.
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AegisBridge(), "AegisNative");

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                    return;
                }
                setEnabled(false);
                getOnBackPressedDispatcher().onBackPressed();
                setEnabled(true);
            }
        });

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 41);
        Intent svc = new Intent(this, MarketDataService.class);
        startForegroundService(svc);

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    public final class AegisBridge {
        @JavascriptInterface public String status() {
            return getSharedPreferences("aegis", MODE_PRIVATE).getString("status", "Başlatılıyor");
        }
        @JavascriptInterface public String flow(String symbol) {
            String s=symbol==null?"BTCUSDT":symbol.replaceAll("[^A-Z0-9]","");
            double buy=0,sell=0,bid=0,ask=0,longLiq=0,shortLiq=0,spoof=0; int trades=0,depthSamples=0,minutes=0; long updated=0;
            try(SQLiteDatabase db=openOrCreateDatabase("aegis_flow.db",MODE_PRIVATE,null); Cursor c=db.rawQuery("SELECT SUM(buy),SUM(sell),SUM(trades),AVG(bid_depth),AVG(ask_depth),SUM(long_liq),SUM(short_liq),MAX(spoof),SUM(depth_samples),MAX(updated_ms),COUNT(*) FROM flow_minute WHERE symbol=? AND minute>?",new String[]{s,String.valueOf(System.currentTimeMillis()/60000-15)})){
                if(c.moveToFirst()){buy=c.getDouble(0);sell=c.getDouble(1);trades=c.getInt(2);bid=c.getDouble(3);ask=c.getDouble(4);longLiq=c.getDouble(5);shortLiq=c.getDouble(6);spoof=c.getDouble(7);depthSamples=c.getInt(8);updated=c.getLong(9);minutes=c.getInt(10);}
            }catch(Exception ignored){}
            long age=updated>0?Math.max(0,(System.currentTimeMillis()-updated)/1000):9999;
            double delta=buy-sell,imb=(bid+ask)>0?(bid-ask)/(bid+ask)*100:0,liq=longLiq+shortLiq;
            int quality=(int)Math.round(Math.min(100,Math.min(depthSamples/2.0,trades/5.0)));if(age>45)quality=Math.min(quality,35);if(minutes<2)quality=Math.min(quality,45);
            boolean ready=age<=45&&depthSamples>=30&&trades>=50&&minutes>=2;
            if(!ready)spoof=0;
            return "{\"symbol\":\""+s+"\",\"windowMinutes\":15,\"buy\":"+buy+",\"sell\":"+sell+",\"delta\":"+delta+",\"trades\":"+trades+",\"bookImbalance\":"+imb+",\"longLiquidations\":"+longLiq+",\"shortLiquidations\":"+shortLiq+",\"liquidations\":"+liq+",\"spoofRisk\":"+spoof+",\"depthSamples\":"+depthSamples+",\"coverageMinutes\":"+minutes+",\"ageSeconds\":"+age+",\"quality\":"+quality+",\"ready\":"+ready+"}";
        }
        @JavascriptInterface public void watch(String csv) {
            if (csv == null || csv.isEmpty()) return;
            LinkedHashSet<String> unique = new LinkedHashSet<>();
            for (String token : csv.toUpperCase(Locale.US).split(",")) {
                String symbol = token.replaceAll("[^A-Z0-9]", "");
                if (symbol.endsWith("USDT") && symbol.length() >= 7 && symbol.length() <= 20) {
                    unique.add(symbol);
                    if (unique.size() >= 50) break;
                }
            }
            if (unique.isEmpty()) return;
            Intent update = new Intent(MainActivity.this, MarketDataService.class);
            update.setAction(MarketDataService.ACTION_SET_PRIORITY);
            update.putStringArrayListExtra(MarketDataService.EXTRA_PRIORITY_SYMBOLS, new ArrayList<>(unique));
            startForegroundService(update);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.evaluateJavascript("if(window.refreshLiveSignals){refreshLiveSignals();}if(window.nativeFlow){nativeFlow();}", null);
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }
}
