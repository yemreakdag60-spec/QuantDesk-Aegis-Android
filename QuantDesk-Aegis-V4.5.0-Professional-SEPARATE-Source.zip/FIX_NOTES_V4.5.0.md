# QuantDesk Aegis V4.5.0 — Professional Live Engine

- Separate Android applicationId: `com.quantdesk.aegis.professional.v450`.
- Preserved 200-coin scan and strict risk gates.
- Replaced volume-only PRO selection with 30 liquid + 20 technically viable candidates.
- Added dynamic native order-flow priority watchlist so technical candidates outside the top-50 volume universe are covered.
- Order-flow warm-up is now pending/retry instead of a hard rejection.
- Reduced arbitrary order-flow warm-up delay while retaining minimum depth, REST trade-window and quality requirements.
- Transient vetoes are periodically revalidated; structural/fatal vetoes wait for the next full scan.
- Adaptive signal freshness window replaces a single rigid expiry cutoff.
- Added no-signal diagnostics with top blocker categories.
- Kept anti-late, TP freshness, net R/R, spread, volatility, BTC conflict, volume and structure protections.
- Kept OkHttp 4.12.0 intentionally for compileSdk 36 / AGP 8.13.x compatibility; corresponding newer-version lint rule remains explicitly disabled.
