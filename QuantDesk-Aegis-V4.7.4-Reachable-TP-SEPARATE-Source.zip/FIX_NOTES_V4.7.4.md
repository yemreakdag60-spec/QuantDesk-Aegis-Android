## V4.7.4 — TP hedefi ve R/R seçim çakışması

- Önceki sürüm aday TP'ler arasından yalnızca fiyata en yakın olanı seçiyor, sonra bu hedefin net R/R ve stop-öncelikli tarihsel erişimini kontrol ediyordu. Daha uzaktaki ama erişim/R/R kapılarını geçen hedefler hiç değerlendirilmiyordu.
- Yeni seçim, her TP adayı için tarihsel stop-öncelikli erişimi, yapısal SL mesafesini ve tahmini maliyet sonrası net R/R'yi birlikte hesaplar. Koşulları geçen hedeflerden en yakını seçilir.
- Hiçbir hedef kapıları geçmezse mevcut en yakın aday yalnızca izleme/gerekçe üretimi içindir; TP1 uygun sayılmaz ve işlem sinyali oluşturmaz.
- Eşikler işlem sayısını yükseltmek için düşürülmedi. Tarihsel temas oranı gerçek kazanma olasılığı değildir; örtüşen geçmiş mum pencerelerinden elde edilen doğrulama ölçüsüdür.
- `test-target-selection.js` daha yakındaki yetersiz hedefin daha uzaktaki uygun hedefi saklamadığını ve uygun hedef yokken sinyal uygunluğu verilmediğini sınar.
- Ayrı paket: `com.quantdesk.aegis.professional.v474`, versionCode `474`.
