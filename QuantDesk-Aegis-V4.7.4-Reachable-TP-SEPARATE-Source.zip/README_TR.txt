QUANTDESK AEGIS V4.7.4 PROFESSIONAL — AYRI KURULUM

Paket adı: com.quantdesk.aegis.professional.v474
V4.4, V4.5, V4.6 ve V4.7.x sürümleriyle yan yana kurulabilir.


V4.7.4 İYİLEŞTİRMELER
- TP seçimi artık yalnız en yakın hedefe bakmaz: tarihsel stop-öncelikli erişim ve tahmini maliyet sonrası net R/R kapılarını geçen en yakın hedef seçilir. Uygun hedef yoksa sinyal verilmez; izleme satırında hedef erişimi/R/R engeli korunur.
- TP1 uygunluğu ile işlemdeki net R/R eşiği aynı seçim adımında uygulanır; uygun bir sonraki hedefin gözden kaçması önlenir.
- Ulaşılabilir TP2/TP3 koşulları sağlanmadığında bu hedefler boş bırakılır; seviye doğrulaması yalnızca mevcut, ulaşılabilir hedefleri sıralı denetler. Eksik opsiyonel hedefler artık geçerli TP1 planını hatalı biçimde veto etmez.
- EMA21 uzaklığı orta düzeydeyken aday artık tek başına sert biçimde elenmez; bu uzaklık fırsat puanında ceza almaya devam eder. 2 ATR üzerindeki aşırı uzaklık sert engeldir. TP tazeliği ve giriş bölgesi kontrolleri aynen uygulanır.
- Binance USDⓈ-M Futures ve Binance Spot için ayrı piyasa modu eklendi. Spot modunda yalnız Spot mum, ticker, order-book ve aggTrade verisi kullanılır; funding, açık pozisyon, long/short hesap oranları, tasfiye ve kaldıraç gösterilmez.
- İlk 200 USDT paritesi veya perpetual sözleşmesi 24 saatlik quote hacmine göre taranır.
- PRO adaylarda 15 dakikalık mum ve hacim grafiği gösterilir.
- “Canlı Fırsatlar”da anlık onaylı işlem yoksa en güçlü beş izleme adayı ve elenme/ bekleme gerekçesi gösterilir; izleme adayı işlem sinyali değildir.
- TP1 yalnız stop-öncelikli tarihsel erişim örneği en az 20 pencere ve %35 temas eşiğini karşılarsa hedef olarak gösterilir. TP2 için en az 20 pencere ve %35; TP3 için en az 20 pencere ve %25 tarihsel temas gerekir. Stop ve hedef aynı mumda görülürse stop önce olmuş sayılır. Eşik altındaki uzak TP kademeleri gösterilmez.
- TP geçmiş erişim oranı gerçek kazanma olasılığı değildir; tarihsel, örtüşen pencerelere dayanır.
- Spot modunda Futures order-flow kullanılmaz. Spot adayları güncel Spot fiyatı, order-book, aggTrade akışı, BTC uyumu, hedef tazeliği ve risk kontrolleriyle ayrıca canlı doğrulanır. Yalnız doğrulamayı geçen adaylar “Şimdi Gir/Girişe Yakın” olarak görünür; uygulama emir göndermez.
- GitHub Actions sürüm kontrolü 4.7.4 ile hizalandı.
