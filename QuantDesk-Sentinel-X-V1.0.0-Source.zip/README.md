# QuantDesk Sentinel X 1.0.0

Bu paket Binance USDⓈ-M Futures ve Spot için Android analiz aracıdır. 200 USDT paritesini tarar, 6 doğal ve 10 türetilmiş zaman dilimini değerlendirir; BTC rejimi/bağı, likidite, erişilebilir hedef, maliyet, tazelik ve canlı order-flow kapıları geçilmeden plan yayımlamaz.

- Ayrı kurulum kimliği: `com.quantdesk.sentinel.analysis.v100`; V4.7.4/V4.8.2 ile yan yana kurulabilir.
- BTC teknik motoru OI, funding, taker akışı, CVD, defter baskısı, long/short kalabalığı ve tasfiye eğilimiyle canlı doğrulanır.
- Coin-BTC bağı kısa/orta/uzun korelasyon, kararlılık ve düşüş korelasyonuyla ölçülür.
- TP geçmiş testi bağımsız 15 dakikalık pencereler, rejim/volatilite eşleşmesi ve güven alt sınırı kullanır.
- Düşük R/R planı iki ardışık güçlü canlı order-flow desteği olmadan yayımlanmaz.
- Arka plan servisi order-flow verisini ve yayımlanan planların TP1/SL sonucunu ekran kapalıyken izler.
- Emir göndermez; borsa anahtarı istemez; cihaz öğrenmesi sert risk kapılarını değiştiremez.

Kurulum: ZIP'i açıp içindekileri GitHub deposunun ana dizinine yükleyin. **Actions > Build QuantDesk Sentinel X Separate APK > Run workflow** yolunu çalıştırın. Tamamlanınca Artifacts bölümündeki `QuantDesk-Sentinel-X-V1.0.0-SEPARATE` paketinden `app-debug.apk` dosyasını kurun.

Platform sınırı: ekran kapalıyken order-flow ve daha önce yayımlanan planların sonucu izlenir. 200 coinlik tam teknik yeniden tarama WebView açıkken yapılır; gerçek 7/24 tam tarama ayrıca sunucu tarafı motor gerektirir.

Bu sürüm yalnız analiz ve işlem planı üretir; Binance API anahtarı istemez ve emir gönderemez.

## Verification

```bash
for f in tools/validate-ui.js tools/test-*.js; do node "$f"; done
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
```

GitHub Actions installs Java and Gradle, runs all source/UI invariants, builds the debug APK and enforces Android Lint.
