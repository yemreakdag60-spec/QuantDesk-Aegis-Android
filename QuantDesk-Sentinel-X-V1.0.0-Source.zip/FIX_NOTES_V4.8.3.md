# QuantDesk Aegis V4.8.3 Professional

V4.8.3 ayrı uygulama kimliği `com.quantdesk.aegis.professional.v483` ile V4.8.2'nin yanına kurulabilir.

## Kritik karar düzeltmeleri

- PRO aşamasındaki yön değişimi, güçlü ters akış ve ciddi walk-forward engelleri canlı yenilemede korunur.
- Güçlü ters canlı order-flow ilk kontrolde sinyali beklemeye alır; ikinci ardışık kontrolde devam ederse sert veto üretir.
- Yükseliş/düşüş sonrası ters akış için geç giriş koruması eklendi.
- Yüksek BTC korelasyonu + nötr/çatışmalı BTC, düşük R/R veya ters akış durumunda risk sınıfı yükseltilir.
- BTC teknik rejimi 60 saniyede bir yenilenir; veri yaşı ekranda gösterilir ve yeterli kaliteli BTC order-flow sınırlı katkı verir.
- BTC bileşik puanı, türetilmiş zaman dilimlerinin sahte bağımsız çoğunluk oluşturmasını azaltmak için mikro/gün içi/swing/makro aileleri üzerinden hesaplanır.

## Sonuçtan öğrenme

- Sinyal günlüğünün tarama tamamlanmadan çalışması düzeltildi.
- Açık sinyaller her canlı yenilemede kontrol edilir; yalnız TP veya SL ile sonuçlanan örnekler modele girer.
- Sonuçlanmamış sinyal eğitim örneği yapılmaz. Öğrenme BTC, TP/SL, maliyet, veri kalitesi ve risk kapılarını değiştiremez.

## Arayüz doğruluğu

- `Akış Güveni` etiketi `Akış Veri Kalitesi` olarak düzeltildi.
- Fırsat puanı ve yön gücü ayrıldı.
- Kart sırası `Fırsat #` olarak açıklandı.
- Tarihsel temasın bağımsız kazanma olasılığı olmadığı, pencere sayısı olduğu belirtildi.
- 6 doğal ve 10 türetilmiş zaman dilimi açıkça ayrıldı.

## Yapay zekâ sınırı

- Uygulama ücretsiz cihaz-içi istatistiksel öğrenmeyle çalışır.
- APK içine API anahtarı gömülmez. Harici üretken yapay zekâ risk kapılarını veya işlem kararını değiştirmez.
