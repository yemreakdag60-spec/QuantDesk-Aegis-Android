# V4.8.4 düzeltme notları

- BTC yönüne OI, funding, agresif alış/satış, CVD, emir defteri, long/short kalabalığı ve tasfiye doğrulaması eklendi.
- BTC bağında kısa/orta/uzun pencere, korelasyon kararlılığı, düşüş korelasyonu ve negatif korelasyon yönü desteklendi.
- En hacimli ilk 30 sözleşme dinamik MAJOR havuzuna alındı; sabit tanınmış coin listesi korundu.
- PRO engellerinin canlı yenilemede kaybolması önlendi.
- Ters akış iki kontrolle veto edilir; R/R 0,65 altı plan iki güçlü destekleyici canlı akış görmeden yayımlanmaz.
- TP örnekleri örtüşmeyen 15 dakikalık pencerelere ayrıldı; rejim/volatilite eşleşmesi ve %90 güven alt sınırı eklendi.
- Öğrenme günlüğü yalnız sonuçlanmış TP/SL verisini piyasa rejimi, BTC rejimi ve volatilite bağlamında kullanır.
- Android servisi ekran kapalıyken yayımlanmış planların TP1/SL sonucunu izler ve uygulama açılınca günlüğe aktarır.
- Yanıltıcı “Akış Güveni” adı “Akış Veri Kalitesi” olarak düzeltildi.
- V4.8.4 ayrı uygulama kimliği ve ayrı bildirim kanallarıyla paketlendi.

Uygulama emir göndermez ve kâr garantisi vermez. 200 coinlik tam teknik tarama uygulama ekranı açıkken çalışır; Android arka planında order-flow ve açık plan sonucu takibi sürer.
