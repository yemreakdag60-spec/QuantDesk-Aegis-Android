# QuantDesk Aegis V4.8.2 Professional

- V4.8.2 uygulama kimliği `com.quantdesk.aegis.professional.v482` olarak ayrıldı. V4.8.1 ile yan yana kurulabilir; eski uygulamanın cihaz verisini değiştirmez.
- Canlı liste her yenilendiğinde açık ayrıntı panelinin kapanması düzeltildi. Açılan coin analizi, kart yeniden çizilse bile açık kalır.
- Risk ve emir planının eski TP/SL değerlerinde kalması düzeltildi. Seçilen coin canlı doğrulandıkça giriş, SL, TP1 ve net R/R otomatik eşitlenir; sinyal geçerliliğini kaybederse miktar önerisi de kaldırılır.
- PRO seçiminin `genel tarama` görünmesi ve birleşik skorun `—/100` kalması düzeltildi. Kart artık gerçek seçim ailesini ve PRO birleşik skorunu gösterir.
- Grafik ile canlı fiyatın anlamı değiştirilmedi: grafik son kapanmış 15 dakikalık mumu, kart başlığı ayrı doğrulanan canlı fiyatı gösterir.
