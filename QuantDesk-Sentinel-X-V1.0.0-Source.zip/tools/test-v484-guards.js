const fs = require('fs');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');

for (const invariant of [
  'proGuardBlocks',
  "...(r.proGuardBlocks||[])",
  'opposingFlowCount>=2',
  "order-flow güçlü ters (iki kontrol)",
  'refreshBtcContext',
  'fetchBtcDerivatives',
  'correlationProfile',
  'corrStability',
  'downsideCorr',
  'düşük R/R için iki canlı güçlü akış onayı yok',
  'supportiveFlowCount',
  'bağımsız 15dk pencere',
  'btcRegime',
  'importBackgroundOutcomes',
  'BTC_REFRESH_MS=60000',
  'journalSignals();render()',
  'Akış Veri Kalitesi',
  'türetilmiş TF\'ler bağımsız örnek değildir',
  'yükseliş sonrası ters akış / geç giriş riski'
]) {
  if (!html.includes(invariant)) throw new Error(`V4.8.4 guard is missing: ${invariant}`);
}

const service = fs.readFileSync('app/src/main/java/com/quantdesk/aegis/MarketDataService.java', 'utf8');
const activity = fs.readFileSync('app/src/main/java/com/quantdesk/aegis/MainActivity.java', 'utf8');
for (const invariant of ['ACTION_SET_PLANS', 'checkPlans(s,price)', 'background_outcomes', 'plans_json']) {
  if (!service.includes(invariant)) throw new Error(`Background plan guard is missing: ${invariant}`);
}
for (const invariant of ['watchPlans(String json)', 'backgroundOutcomes()']) {
  if (!activity.includes(invariant)) throw new Error(`Native background bridge is missing: ${invariant}`);
}

const complete = html.indexOf('scanComplete=true;journalSignals()');
if (complete < 0) throw new Error('Learning journal must run only after scan completion');
if (html.includes('journalSignals();scanComplete=true')) {
  throw new Error('Learning journal still runs before scan completion');
}

console.log('V4.8.4 persistent PRO guards, live BTC refresh and outcome-learning invariants passed');
