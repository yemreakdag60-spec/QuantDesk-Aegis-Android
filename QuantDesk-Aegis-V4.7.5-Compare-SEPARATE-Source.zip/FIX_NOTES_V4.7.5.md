## V4.7.5 Compare — ayrı kurulum ve canlı eşik denetimi

- Ayrı Android paketi: `com.quantdesk.aegis.professional.v475`, versionCode `475`; kurulu v4.7.4 (`.v474`) ile yan yana kurulabilir.
- Aday puan alt sınırı 64→62, girişe yakın alt sınırı 56→54 olarak bir kademe gevşetildi.
- BTC güçlü ters yön, minimum 5/13 çoklu zaman dilimi uyumu, TP/SL bütünlüğü, hedef erişim örneklemi, maliyet sonrası R/R, spread, aşırı volatilite/uzama, hacim, taze fiyat, yön olasılığı ve güncel order-flow doğrulaması korunmuştur.
- Minimum iki gerçek işlem sinyali garanti edilmez. Piyasa şartları filtreleri karşılamıyorsa sıfır onay doğru sonuçtur; adaylar işlem sinyali gibi etiketlenmez.
- Sadece 62/54 puan sınırlarını kullanmayı ve sert veto kapılarını korumayı doğrulayan test eklendi.

## Doğrulama

- `node tools/validate-ui.js`
- `node tools/test-live-score-thresholds.js`
- Mevcut analiz motoru testleri

APK, ayrı uygulama olarak kurulacak şekilde `Aegis V4.7.5 Compare` etiketiyle derlenmelidir.
