QUANTDESK AEGIS V4.7.5 COMPARE — AYRI KURULUM

Paket adı: com.quantdesk.aegis.professional.v475
V4.4, V4.5, V4.6 ve V4.7.x sürümleriyle yan yana kurulabilir.


V4.7.5 İYİLEŞTİRMELER
- Ayrı karşılaştırma kurulumu: paket kimliği v475, uygulama adı Aegis V4.7.5 Compare; mevcut v474 kurulumunu değiştirmez.
- Canlı giriş skoru tabanı 64’ten 62’ye, izleme eşiği 56’dan 54’e bir kademe indirildi. Yalnızca skor tabanı gevşetildi; BTC ters yön, TP erişimi, maliyet sonrası R/R, gecikmiş giriş, spread, hacim ve canlı order-flow korumaları aynen durur.
- Piyasa koşulları en az iki gerçek, doğrulanmış adayı her taramada garanti etmez; liste dolsun diye koruma kapıları atlanmaz.
- TP seçimi artık yalnız en yakın hedefe bakmaz: tarihsel stop-öncelikli erişim ve tahmini maliyet sonrası net R/R kapılarını geçen en yakın hedef seçilir. Uygun hedef yoksa sinyal verilmez; izleme satırında hedef erişimi/R/R engeli korunur.
- TP1 uygunluğu ile işlemdeki net R/R eşiği aynı seçim adımında uygulanır; uygun bir sonraki hedefin gözden kaçması önlenir.
- ATR ve ADX, Wilder RMA/DMI yumuşatmasıyla hesaplanır; Supertrend adı verilen değer artık ATR orta bant tahmini değil, sürüklenen bant ve yön dönüş koşullarını kullanan Supertrend hesabıdır.
- Açık mum indikatör hesaplarına katılmaz; hacim karşılaştırması son kapanan mumu kullanır. Canlı fiyat ve emir defteri ayrıca canlı doğrulamada okunur.
- Spot modunda SHORT işlem talimatı üretilmez; Spot yalnız alım yönünü canlı işlem adayı yapar.
- Küçük ve zayıf walk-forward örneği artık tek başına sert veto değildir; skoru düşürür. En az 30 örnekte %25 altı belirgin başarısızlık sert koruma olarak kalır.
- Ulaşılabilir TP2/TP3 koşulları sağlanmadığında bu hedefler boş bırakılır; seviye doğrulaması yalnızca mevcut, ulaşılabilir hedefleri sıralı denetler. Eksik opsiyonel hedefler artık geçerli TP1 planını hatalı biçimde veto etmez.
- EMA21 uzaklığı orta düzeydeyken aday artık tek başına sert biçimde elenmez; bu uzaklık fırsat puanında ceza almaya devam eder. 2 ATR üzerindeki aşırı uzaklık sert engeldir. TP tazeliği ve giriş bölgesi kontrolleri aynen uygulanır.
- Binance USDⓈ-M Futures ve Binance Spot için ayrı piyasa modu eklendi. Spot modunda yalnız Spot mum, ticker, order-book ve aggTrade verisi kullanılır; funding, açık pozisyon, long/short hesap oranları, tasfiye ve kaldıraç gösterilmez.
- İlk 200 USDT paritesi veya perpetual sözleşmesi 24 saatlik quote hacmine göre taranır.
- PRO adaylarda 15 dakikalık mum ve hacim grafiği gösterilir.
- “Canlı Fırsatlar”da anlık onaylı işlem yoksa en güçlü beş izleme adayı ve elenme/ bekleme gerekçesi gösterilir; izleme adayı işlem sinyali değildir.
- TP1 yalnız stop-öncelikli tarihsel erişim örneği en az 20 pencere ve %35 temas eşiğini karşılarsa hedef olarak gösterilir. TP2 için en az 20 pencere ve %35; TP3 için en az 20 pencere ve %25 tarihsel temas gerekir. Stop ve hedef aynı mumda görülürse stop önce olmuş sayılır. Eşik altındaki uzak TP kademeleri gösterilmez.
- TP geçmiş erişim oranı gerçek kazanma olasılığı değildir; tarihsel, örtüşen pencerelere dayanır.
- Spot modunda Futures order-flow kullanılmaz. Spot adayları güncel Spot fiyatı, order-book, aggTrade akışı, BTC uyumu, hedef tazeliği ve risk kontrolleriyle ayrıca canlı doğrulanır. Yalnız doğrulamayı geçen adaylar “Şimdi Gir/Girişe Yakın” olarak görünür; uygulama emir göndermez.
- GitHub Actions sürüm kontrolü v4.7.5 ayrı kurulumu ile hizalandı.


## Son işlem kartı ve güvenlik kontrolü
- İşlem kartında LONG/SHORT yönü başlıkta görünür; reddedilen TP1 için R/R sayısı geçerli hedefmiş gibi gösterilmez. 15 dakikalık grafikte son kapanmış mumun O/H/L/C ve hacmi ile giriş bandı, stop, uygun TP1 ve son fiyat işaretlenir.
- Karttaki durum “CANLI ADAY” olarak adlandırılır; emir talimatı değildir. Pozisyon boyutu yalnızca taze canlı doğrulama, yön, TP1 uygunluğu ve doğru SL/TP geometrisi birlikte geçerse hesaplanır. Spot için yalnız LONG boyutlandırılır.
- Pozisyon hesabı yuvarlanmış miktardaki stop+kayma+komisyon tahminini gösterir; Binance minimum miktar/notional koşulu tutmuyorsa emir miktarı uygun değildir uyarısı verir.
- Uygulama Binance hesap bakiyesini, açık pozisyonları veya bekleyen emirleri okumaz; çakışan/ters işlemi engelleyemez.
- WebView yerel arayüzü artık file:// yerine AndroidX WebViewAssetLoader ile yükler; dosya evrensel erişimi kapalı, sayfa gezinmesi uygulama kaynağına sınırlandırılmıştır.
