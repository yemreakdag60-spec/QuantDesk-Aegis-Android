const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const start = html.indexOf('function balancedEntry(');
const end = html.indexOf('\nfunction signalAge(', start);
if (start < 0 || end < 0) throw new Error('balancedEntry function was not found');

const intervals = ['1m', '5m', '10m', '15m', '30m', '45m', '1h', '2h', '3h', '4h', '6h', '12h', '24h'];
const context = { clamp: (x, lo, hi) => Math.max(lo, Math.min(hi, x)), intervals, btcScore: 0, MAX_STRETCH_ATR: 2.0, MIN_ACTION_SCORE: 62, MIN_NEAR_SCORE: 54, levelsValid: () => true };
vm.createContext(context);
vm.runInContext(html.slice(start, end), context);

function evaluateStretch(stretchAtr) {
  const price = 100;
  const atr = 1;
  const tfs = { '15m': { taker: 0.53, adx: 20, vr: 1, rsi: 50, mfi: 50, e21: price - stretchAtr * atr } };
  const levels = { rr1: 1, historicalSamples: 40, historicalReach: 70 };
  const fresh = { status: 'TAZE', blocked: false };
  return context.balancedEntry(tfs, 'LONG', 70, 70, 8, true, 20, 0.01, levels, fresh, price, atr);
}

const moderate = evaluateStretch(1.8);
if (moderate.hard.includes('fiyat aşırı uzamış')) throw new Error('Moderate EMA stretch should lower score without becoming a hard veto');

const extreme = evaluateStretch(2.1);
if (!extreme.hard.includes('fiyat aşırı uzamış')) throw new Error('Extreme EMA stretch must remain a hard veto');

if (html.includes('if(stretchAtr>1.55)')) throw new Error('The old overlapping 1.55 ATR hard veto remains');
console.log('Moderate EMA stretch is scored; extreme stretch remains blocked');
