const fs = require('fs');

const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const constants = html.split(/\r?\n/).find((line) => line.startsWith('const MAX_COINS='));
if (!constants || !constants.includes('MIN_ACTION_SCORE=62') || !constants.includes('MIN_NEAR_SCORE=54')) {
  throw new Error('The one-step score thresholds must be explicit and consistent');
}

const entryGate = html.split(/\r?\n/).find((line) => line.startsWith(' let hard=[];'));
const entryScoreGate = html.split(/\r?\n/).find((line) => line.startsWith(' opportunity=clamp(opportunity'));
const proGate = html.split(/\r?\n/).find((line) => line.includes('let hard=[...base.hard'));
const liveGate = html.split(/\r?\n/).find((line) => line.includes('flowPending=(rawFlowPending'));
for (const [name, line] of [['technical', entryScoreGate], ['PRO', proGate], ['live', liveGate]]) {
  if (!line || !line.includes('MIN_ACTION_SCORE') || !line.includes('MIN_NEAR_SCORE')) {
    throw new Error(`${name} gate does not use the same score floors`);
  }
}

for (const invariant of [
  'align<5',
  'fresh&&fresh.blocked',
  'levels.rr1<.50',
  'levels.historicalSamples>=30&&levels.historicalReach<52',
  "!btcOK&&Math.abs(btcScore)>48",
  'stretchAtr>MAX_STRETCH_ATR',
]) {
  if (!entryGate || !entryGate.includes(invariant)) throw new Error(`Professional hard veto was removed: ${invariant}`);
}

if (!proGate.includes('hard.length===0') || !liveGate.includes('hard.length===0') || !liveGate.includes('!flowPending')) {
  throw new Error('A score floor must never bypass hard or live-flow validation');
}

console.log('Score floors softened by one step; TP/RR/BTC/stretch/live-flow hard protections remain active');
