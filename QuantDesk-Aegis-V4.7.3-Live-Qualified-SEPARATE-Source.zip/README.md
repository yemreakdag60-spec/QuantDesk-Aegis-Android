# QuantDesk Aegis V4.6.0 Professional — Separate Install

Standalone Android package: `com.quantdesk.aegis.professional.v460`.

This build is intentionally installable beside V4.4 and V4.5.

## Live-engine corrections
- 15m volume validation now uses the last closed candle instead of the still-forming candle.
- New TP1 targets are no longer retroactively tested against candles that existed before the target was created.
- Same-setup TP1 lifecycle is tracked from its issuance time using live aggTrade data.
- R/R and volume are graded with soft penalties; only genuinely poor cases become hard vetoes.
- Dynamic blockers such as R/R, volume, BTC conflict and anti-late conditions are allowed into live revalidation instead of being permanently excluded before the live stage.
- Existing spread, invalid structure, extreme volatility, PRO-flow, walk-forward and order-flow protections remain.
