QUANTSCOPE MOBILE PRO V2 - ANDROID APK PROJESI

Bu klasor, V2 telefon surumunun Android uygulama kabugudur.
Uygulama Binance public piyasa verilerini internet uzerinden ceker; API anahtari istemez.

APK OLUSTURMA (Android Studio):
1) Android Studio'yu acin.
2) Open > bu klasoru secin: QuantScopeMobilePro_Android
3) Gerekli Android SDK 36 ve Gradle bilesenlerinin indirilmesine izin verin.
4) Build > Build App Bundle(s) / APK(s) > Build APK(s)
5) APK genellikle app/build/outputs/apk/debug/app-debug.apk altinda olusur.

TELEFONA KURULUM:
- APK'yi telefona aktarip acin.
- Android isterse bu kaynaktan uygulama yukleme izni verin.

Not: Bu projedeki analiz skorlarinin hicbiri kar garantisi degildir.
