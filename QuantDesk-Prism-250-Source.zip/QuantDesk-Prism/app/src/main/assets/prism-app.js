(()=>{
'use strict';
const $=s=>document.querySelector(s),API='https://fapi.binance.com', state={candles:[],busy:false};
const fmt=(n,d=2)=>Number.isFinite(+n)?(+n).toLocaleString('en-US',{maximumFractionDigits:d}):'—';
const cash=n=>!Number.isFinite(+n)?'—':Math.abs(n)>1e6?(n/1e6).toFixed(2)+'m':Math.abs(n)>1e3?(n/1e3).toFixed(1)+'k':n.toFixed(2);
async function get(url){const r=await fetch(url,{cache:'no-store'});if(!r.ok)throw Error('Veri kaynağı HTTP '+r.status);return r.json()}
function setPrice(el,val){$(el).textContent=val}
function status(s,live=false){$('#connection').textContent=s;$('#connection').classList.toggle('live',live)}
async function overview(){
 try{
  const [tickResult,fngResult]=await Promise.allSettled([get(API+'/fapi/v1/ticker/24hr'),get('https://api.alternative.me/fng/?limit=1')]);if(tickResult.status!=='fulfilled')throw tickResult.reason;const tick=tickResult.value;const fng=fngResult.status==='fulfilled'?fngResult.value:{data:[]};
  for(const symbol of ['BTCUSDT','ETHUSDT']){const x=tick.find(z=>z.symbol===symbol);if(x){setPrice(symbol==='BTCUSDT'?'#btcPrice':'#ethPrice','$'+fmt(x.lastPrice));const el=$(symbol==='BTCUSDT'?'#btcChange':'#ethChange');el.textContent=(+x.priceChangePercent>=0?'+':'')+fmt(x.priceChangePercent)+'% / 24s';el.className=+x.priceChangePercent>=0?'positive':'negative'}}
  const list=tick.filter(x=>x.symbol.endsWith('USDT')&&+x.quoteVolume>=1e7).sort((a,b)=>+b.quoteVolume- +a.quoteVolume).slice(0,250);$('#symbols').innerHTML=list.map(x=>'<option value="'+x.symbol+'">').join('');$('#scanStatus').textContent=list.length+' likit USDT sözleşmesi • hacme göre sıralı';if(fng.data?.[0]){setPrice('#fear',fng.data[0].value+'/100');setPrice('#fearText',fng.data[0].value_classification)}
  status('BINANCE • CANLI',true);$('#updated').textContent='• '+new Date().toLocaleTimeString('tr-TR');return list;
 }catch(e){status('BAĞLANTI YOK');$('#updated').textContent='• veri alınamadı';$('#scanStatus').textContent=e.message;return []}
}
async function fetchCandles(sym,tf,limit=200){return PrismEngine.parseKlines(await get(API+'/fapi/v1/klines?symbol='+encodeURIComponent(sym)+'&interval='+tf+'&limit='+limit))}
async function analyze(sym=$('#symbol').value.trim().toUpperCase()){
 if(state.busy)return;state.busy=true;$('#signal').innerHTML='<div class="placeholder"><span class="pulse"></span>Çoklu zaman dilimi ve türev verisi yükleniyor…</div>';
 try{
  if(!/^[A-Z0-9]{3,24}USDT$/.test(sym))throw Error('Sembol USDT sürekli sözleşme biçiminde olmalı.');
  const tf=$('#interval').value;
  const [candles,higher,book,oi,premium,oiHistory,flow]=await Promise.all([
   fetchCandles(sym,tf,200),Promise.all(['1h','4h'].map(x=>fetchCandles(sym,x,100).catch(()=>[]))),
   get(API+'/fapi/v1/depth?symbol='+sym+'&limit=100').catch(()=>null),
   get(API+'/fapi/v1/openInterest?symbol='+sym).catch(()=>null),
   get(API+'/fapi/v1/premiumIndex?symbol='+sym).catch(()=>null),
   get(API+'/futures/data/openInterestHist?symbol='+sym+'&period=15m&limit=2').catch(()=>[]),
   get(API+'/futures/data/takerlongshortRatio?symbol='+sym+'&period=15m&limit=4').catch(()=>[])
  ]);
  state.candles=candles;const last=candles.at(-1),higherScores={};
  for(let i=0;i<higher.length;i++)if(higher[i].length>=60){const a=higher[i],e=PrismEngine.ema(a.map(x=>x.c),50).at(-1);higherScores[i===0?'1h':'4h']=Math.tanh((a.at(-1).c-e)/(PrismEngine.atr(a)||1)*1.5)}
  let bookScore=0;
  if(book?.bids?.length&&book?.asks?.length){const mid=(+book.bids[0][0]+ +book.asks[0][0])/2,near=(side)=>book[side].filter(x=>Math.abs(+x[0]-mid)/mid<.005).reduce((s,x)=>s+(+x[0])*(+x[1]),0),b=near('bids'),a=near('asks');bookScore=(b+a)?(b-a)/(b+a):0}
  const oid=oi?+oi.openInterest:0, price=last.c, openInterestUsd=oid*price;
  const funding=premium?+premium.lastFundingRate:0;
  const oiChange=oiHistory?.length>1&&+oiHistory[0].sumOpenInterestValue?((+oiHistory.at(-1).sumOpenInterestValue/+oiHistory[0].sumOpenInterestValue)-1)*100:0;
  let ratio=flow?.length?+flow.at(-1).buySellRatio:NaN;
  
  const result=PrismEngine.analyze({candles,higher:higherScores,book:bookScore,funding,oiChange,hasDerivatives:!!premium});
  renderSignal(sym,result,last.t);
  state.flowSnapshot={flow,candles,bookScore,oi:openInterestUsd,oiChange,funding};renderFlow(sym,state.flowSnapshot);
  draw(candles);renderTable(candles);$('#chartTitle').textContent=sym+' • OHLCV';
  $('#chartStatus').textContent=candles.length+' mum • '+tf+' • Binance USDⓈ-M';
  $('#flowBadge').textContent=book?(window.PrismNative?'REST + YEREL KAYIT':'REST SNAPSHOT'):'KISMİ VERİ';
  try{window.PrismNative?.setSymbol(sym)}catch(_){}
 }catch(e){$('#signal').innerHTML='<div class="placeholder">'+escapeHtml(e.message||'Analiz başarısız')+'</div>';$('#flowStatus').textContent='Veri alınamadı: '+(e.message||'hata');status('VERİ HATASI')}
 finally{state.busy=false}
}
function renderSignal(sym,x,at){
 const cls=x.side==='LONG'?'long':x.side==='SHORT'?'short':'wait';
 const levels=[['GİRİŞ',x.price],['ZARAR KES',x.sl],['HEDEF 1',x.tp1],['HEDEF 2',x.tp2]];
 $('#signal').innerHTML='<article class="signalcard"><div class="signalhead"><div><div class="side '+cls+'">'+x.side+' · '+sym+'</div><div class="price">$'+fmt(x.price,6)+'</div></div><div class="score">SİNYAL GÜCÜ<br><b>'+x.score+'/100</b><br><small>'+x.side+' yönü · '+x.coverage+'% veri</small></div></div><div class="levels">'+levels.map(a=>'<div class="level"><small>'+a[0]+'</small><b>$'+fmt(a[1],6)+'</b></div>').join('')+'</div><div class="why">'+x.reasons.join(' · ')+'</div><div class="factors">'+x.parts.map(p=>'<span class="factor">'+p.name+' '+(p.missing?'yok':(p.value>0?'+':'')+p.value)+' · '+Math.round(p.weight*100)+'%</span>').join('')+'</div><div class="scanrow"><span>'+x.method+' · '+x.expiresBars+' mumluk model ufku</span><button id="saveSignal" class="textbtn">Günlüğe ekle +</button></div></article>';
 $('#saveSignal').onclick=()=>save({sym,side:x.side,score:x.score,price:x.price,sl:x.sl,tp1:x.tp1,tp2:x.tp2,at});
}
function renderFlow(sym,d){
 const trades=d.flow||[],buy=trades.length?+trades.at(-1).buySellRatio:NaN;
 const total=d.candles.slice(-4).reduce((s,x)=>s+x.q,0),taker=d.candles.slice(-4).reduce((s,x)=>s+x.tq,0),buyQ=taker,sellQ=Math.max(0,total-taker);
 let stored={};try{if(window.PrismNative)stored=JSON.parse(PrismNative.flow(sym))}catch(_){}
 const metrics=[['Agresif alış • '+d.candles.length+' mum',cash(buyQ)],['Agresif satış • '+d.candles.length+' mum',cash(sellQ)],['Mum CVD • '+d.candles.length+' mum',cash(buyQ-sellQ)],['Yerel CVD • 15 dk',cash((stored.buy||0)-(stored.sell||0))],['Taker oranı',Number.isFinite(buy)?fmt(buy,3):'—'],['Defter ±0,5%',(d.bookScore*100).toFixed(1)+'%'],['Açık pozisyon',cash(d.oi)+' USDT'],['OI değişimi • 15m',fmt(d.oiChange,2)+'%'],['Fonlama',fmt(d.funding*100,4)+'%'],['Gözlenen long tasfiye',cash(stored.longLiquidations||0)+' USDT'],['Gözlenen short tasfiye',cash(stored.shortLiquidations||0)+' USDT']];
 $('#flowMetrics').innerHTML=metrics.map((x,i)=>'<div class="metric"><small>'+x[0]+'</small><b class="'+(i===0?'positive':i===1?'negative':'')+'">'+x[1]+'</b></div>').join('');
 const nativeStatus=window.PrismNative?PrismNative.status():'yerel Android servisi yok';$('#flowStatus').textContent='Binance USDⓈ-M REST snapshot • '+(stored.trades?stored.trades+' yerel işlem kaydı':'yerel işlem bekleniyor')+' • '+nativeStatus+' • '+(d.bookScore>0?'bid ağırlığı':d.bookScore<0?'ask ağırlığı':'defter nötr');
}
function renderTable(c){$('#ohlcv').innerHTML=c.slice(-20).reverse().map(x=>'<tr><td>'+new Date(x.t).toLocaleString('tr-TR')+'</td><td>'+fmt(x.o,6)+'</td><td>'+fmt(x.h,6)+'</td><td>'+fmt(x.l,6)+'</td><td>'+fmt(x.c,6)+'</td><td>'+fmt(x.v,2)+'</td><td>'+fmt(x.q,2)+'</td></tr>').join('')}
function draw(c){const canvas=$('#chart'),rect=canvas.getBoundingClientRect(),dpr=devicePixelRatio||1;canvas.width=rect.width*dpr;canvas.height=rect.height*dpr;const ctx=canvas.getContext('2d');ctx.scale(dpr,dpr);const w=rect.width,h=rect.height,rows=c.slice(-55),lo=Math.min(...rows.map(x=>x.l)),hi=Math.max(...rows.map(x=>x.h)),pad=12,dx=(w-pad*2)/rows.length,scale=(h-24)/(hi-lo||1);ctx.strokeStyle='#23303e';ctx.lineWidth=1;for(let j=0;j<4;j++){const y=8+j*(h-16)/3;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke()}rows.forEach((x,i)=>{const xx=pad+i*dx+dx/2,y1=h-8-(x.h-lo)*scale,y2=h-8-(x.l-lo)*scale,yo=h-8-(x.o-lo)*scale,yc=h-8-(x.c-lo)*scale,color=x.c>=x.o?'#71e3c2':'#ff7d86';ctx.strokeStyle=color;ctx.fillStyle=color;ctx.beginPath();ctx.moveTo(xx,y1);ctx.lineTo(xx,y2);ctx.stroke();const top=Math.min(yo,yc),height=Math.max(1,Math.abs(yc-yo));ctx.fillRect(xx-Math.max(1,dx*.27),top,Math.max(2,dx*.55),height)})}
function save(x){let a=JSON.parse(localStorage.getItem('prism.journal')||'[]');a.unshift(x);localStorage.setItem('prism.journal',JSON.stringify(a.slice(0,40)));journal();$('#saveSignal').textContent='Kaydedildi ✓'}
function journal(){const a=JSON.parse(localStorage.getItem('prism.journal')||'[]');$('#journal').classList.toggle('empty',!a.length);$('#journal').innerHTML=a.length?a.map(x=>'<div class="journalitem"><b class="'+(x.side==='LONG'?'positive':x.side==='SHORT'?'negative':'')+'">'+x.side+'</b><div><b>'+x.sym+' · '+x.score+'/100</b><small>'+new Date(x.at).toLocaleString('tr-TR')+'</small></div><span>$'+fmt(x.price,5)+'</span></div>').join(''):'Henüz kaydedilmiş analiz yok.'}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
$('#analyze').onclick=()=>analyze();$('#refresh').onclick=async()=>{await overview();analyze()};$('#symbol').addEventListener('change',()=>analyze());$('#chartTf').onchange=async()=>{try{state.candles=await fetchCandles($('#symbol').value,$('#chartTf').value,100);draw(state.candles);renderTable(state.candles);$('#chartStatus').textContent=state.candles.length+' mum • '+$('#chartTf').value+' • Binance USDⓈ-M'}catch(e){$('#chartStatus').textContent=e.message}};
$('#scan').onclick=async()=>{const list=await overview(),tf=$('#interval').value,candidates=[];$('#scanStatus').textContent='250 adede kadar sözleşme taranıyor…';for(let i=0;i<list.length;i+=10){const batch=list.slice(i,i+10);const results=await Promise.all(batch.map(async x=>{try{const c=await fetchCandles(x.symbol,tf,120),m=PrismEngine.analyze({candles:c});return m.side!=='BEKLE'&&m.score>=68?{symbol:x.symbol,score:m.score,volume:+x.quoteVolume}:null}catch(_){return null}}));candidates.push(...results.filter(Boolean));$('#scanStatus').textContent='Tarama: '+Math.min(i+batch.length,list.length)+'/'+list.length+' • '+candidates.length+' uygun kurulum'}const best=candidates.sort((a,b)=>b.score-a.score||b.volume-a.volume)[0];if(best){$('#symbol').value=best.symbol;await analyze(best.symbol)}else $('#scanStatus').textContent='Taranan sözleşmelerde eşik üstü LONG/SHORT kurulumu bulunmadı.'};
$('#clearJournal').onclick=()=>{localStorage.removeItem('prism.journal');journal()};
window.addEventListener('resize',()=>{if(state.candles.length)draw(state.candles)});
overview().then(()=>analyze());journal();setInterval(overview,60000);setInterval(()=>{if(state.flowSnapshot)renderFlow($('#symbol').value.trim().toUpperCase(),state.flowSnapshot)},5000);
})();
