(function(root){
'use strict';
const mean=a=>a.reduce((x,y)=>x+y,0)/(a.length||1);
const clamp=(x,lo,hi)=>Math.max(lo,Math.min(hi,x));
const POSITIVE_NEWS=['approval','approved','adoption','inflow','inflows','partnership','integrates','integration','launches','launched','upgrade','upgrades','surge','surges','rally','rallies','gains','gain','record high','rebound','recovery','bullish','buying','etf inflow','etf approval','expands','growth','wins'];
const NEGATIVE_NEWS=['hack','hacked','exploit','exploited','breach','lawsuit','sued','investigation','probe','ban','banned','rejection','rejects','outflow','outflows','liquidation','liquidations','bankruptcy','fraud','scam','crash','crashes','plunge','plunges','falls','fell','drops','drop','losses','bearish','sell-off','delisting','delisted','warning','fine','fined'];
function newsSentiment(text,providerSentiment=''){
 const supplied=String(providerSentiment||'').toUpperCase();if(supplied==='POSITIVE')return .75;if(supplied==='NEGATIVE')return -.75;if(supplied==='NEUTRAL'||supplied==='MIXED')return 0;
 const s=String(text||'').toLowerCase();let p=0,n=0;for(const w of POSITIVE_NEWS)if(s.includes(w))p++;for(const w of NEGATIVE_NEWS)if(s.includes(w))n++;return clamp((p-n)/Math.max(2,p+n),-1,1);
}
function combineNews(assetScore,btcScore,isBitcoin=false){const a=clamp(Number(assetScore)||0,-1,1),b=clamp(Number(btcScore)||0,-1,1);return isBitcoin?a:clamp(a*.65+b*.35,-1,1)}
function ema(a,n){const k=2/(n+1),out=[];let v=a[0]||0;for(let i=0;i<a.length;i++){v=i===0?a[i]:a[i]*k+v*(1-k);out.push(v)}return out}
function rsi(a,n=14){if(a.length<n+1)return 50;let g=0,l=0;for(let i=a.length-n;i<a.length;i++){const d=a[i]-a[i-1];if(d>0)g+=d;else l-=d}return l===0?100:100-100/(1+(g/n)/(l/n))}
function atr(cs,n=14){if(cs.length<n+1)return 0;const tr=[];for(let i=1;i<cs.length;i++)tr.push(Math.max(cs[i].h-cs[i].l,Math.abs(cs[i].h-cs[i-1].c),Math.abs(cs[i].l-cs[i-1].c)));return mean(tr.slice(-n))}
function analyze(input){
 const c=input.candles||[], price=c.at(-1)?.c||0;
 if(c.length<80||!c.every(x=>[x.o,x.h,x.l,x.c,x.v,x.q].every(Number.isFinite)&&x.l>0&&x.h>=x.l&&x.o>=x.l&&x.o<=x.h&&x.c>=x.l&&x.c<=x.h&&x.v>=0&&x.q>=0))throw Error('Geçerli analiz için en az 80 adet hatasız OHLCV mumu gerekli.');
 const close=c.map(x=>x.c),fast=ema(close.slice(-100),20).at(-1),slow=ema(close.slice(-120),50).at(-1),r=rsi(close),vol=mean(c.slice(-21,-1).map(x=>x.v))||0,volRatio=vol?c.at(-1).v/vol:0,a=atr(c);
 const range=c.slice(-20,-1),swingLow=Math.min(...range.map(x=>x.l)),swingHigh=Math.max(...range.map(x=>x.h));
 const deltas=c.slice(-12).map(x=>Math.max(0,Math.min(1,(x.tb||0)/(x.v||1)))-.5),delta=mean(deltas);
 const trend=Math.tanh((fast-slow)/(a||price*.001)*1.8),momentum=Math.max(-1,Math.min(1,(r-50)/19)),participation=Math.max(-1,Math.min(1,delta*4))*Math.min(1,Math.max(.25,volRatio));
 const structure=Math.max(-1,Math.min(1,(price-(swingHigh+swingLow)/2)/((swingHigh-swingLow)/2||a||1)));
 const tf=input.higher||{},alignments=Object.values(tf).filter(Number.isFinite),htf=alignments.length?mean(alignments.map(x=>Math.max(-1,Math.min(1,x)))):0;
 const funding=Number(input.funding||0),oiChange=Number(input.oiChange||0),book=Number(input.book||0);
 const deriv=Math.max(-1,Math.min(1,-funding*1e4*.15+Math.tanh(oiChange*.18)*Math.sign(trend||1)*.25+book*.35));
 const parts=[['TREND',trend,.27],['MOMENTUM',momentum,.20],['STRUCTURE',structure,.16],['TAKER FLOW',participation,.15],['HIGHER TF',htf,.12],['DERIVATIVES',deriv,.10]];
 const coverage=parts.reduce((s,x)=>s+(x[0]==='HIGHER TF'&&!alignments.length?0:x[0]==='DERIVATIVES'&&!input.hasDerivatives?0:x[2]),0);
 const raw=parts.reduce((s,x)=>s+x[1]*x[2],0)/(coverage||1),technicalBiasScore=Math.round(50+raw*50),newsImpact=clamp(Number(input.newsImpact)||0,-1,1),newsAdjustment=Math.round(newsImpact*8),biasScore=clamp(technicalBiasScore+newsAdjustment,0,100);
 const side=biasScore>=63?'LONG':biasScore<=37?'SHORT':'BEKLE',score=side==='SHORT'?100-biasScore:biasScore,unit=Math.max(a,price*.0012),isLong=side!=='SHORT';
 const sl=isLong?Math.min(price-unit*1.45,swingLow-unit*.18):Math.max(price+unit*1.45,swingHigh+unit*.18);
 const risk=Math.abs(price-sl),tp1=isLong?price+risk*1.5:Math.max(Number.MIN_VALUE,price-risk*1.5),tp2=isLong?price+risk*2.3:Math.max(Number.MIN_VALUE,price-risk*2.3);
 const goodData=coverage>=.78&&price>0&&a>0;
 return {side:goodData?side:'BEKLE',score,biasScore,technicalBiasScore,newsImpact,newsAdjustment,coverage:Math.round(coverage*100),price,sl,tp1,tp2,atr:a,rsi:r,volRatio,parts:parts.map(x=>({name:x[0],value:Math.round(x[1]*100),weight:x[2],missing:(x[0]==='HIGHER TF'&&!alignments.length)||(x[0]==='DERIVATIVES'&&!input.hasDerivatives)})),reasons:[`EMA20/50: ${fast>slow?'yukarı':'aşağı'} eğim, RSI ${r.toFixed(1)}`,`Son mum hacmi 20 mum ortalamasının ${volRatio.toFixed(2)} katı; taker akış dengesi ${(delta*100).toFixed(1)} puan`,`ATR(${Math.min(14,c.length-1)}): ${a.toPrecision(4)}; SL ${(risk/(a||1)).toFixed(2)} ATR uzaklıkta`],expiresBars:12,method:'Prism Explainable Ensemble v1'};
}
function parseKlines(raw){return raw.map(k=>({t:+k[0],o:+k[1],h:+k[2],l:+k[3],c:+k[4],v:+k[5],q:+k[7],tb:+k[9],tq:+k[10]}))}
const api={ema,rsi,atr,analyze,parseKlines,newsSentiment,combineNews};
if(typeof module!=='undefined'&&module.exports)module.exports=api;root.PrismEngine=api;
})(typeof globalThis!=='undefined'?globalThis:this);
