package com.emreakdag.quantdesk.prism;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Xml;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONObject;
import java.io.IOException;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.xmlpull.v1.XmlPullParser;

public final class MainActivity extends Activity {
    private static final OkHttpClient NEWS_HTTP=new OkHttpClient.Builder().connectTimeout(3,TimeUnit.SECONDS).readTimeout(4,TimeUnit.SECONDS).callTimeout(5,TimeUnit.SECONDS).build();
    private static final ExecutorService NEWS_EXEC=Executors.newFixedThreadPool(4);
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(10, 15, 24));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(10, 15, 24));
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},71);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true); settings.setSupportZoom(false); settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false); settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW); settings.setAllowFileAccessFromFileURLs(true); settings.setAllowUniversalAccessFromFileURLs(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){String scheme=request.getUrl().getScheme();if("file".equalsIgnoreCase(scheme))return false;if("https".equalsIgnoreCase(scheme)){try{startActivity(new Intent(Intent.ACTION_VIEW,request.getUrl()));}catch(RuntimeException ignored){}}return true;}});
        webView.addJavascriptInterface(new PrismBridge(this,webView),"PrismNative");
        setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
    }
    public static final class PrismBridge {
        private final Context context;
        private final WebView webView; private final Handler main=new Handler(Looper.getMainLooper());
        PrismBridge(Context c,WebView w){context=c.getApplicationContext();webView=w;}
        @JavascriptInterface public void setSymbol(String symbol){if(symbol==null||!symbol.matches("[A-Z0-9]{3,24}USDT"))return;try{MarketDataService.start(context,symbol);}catch(RuntimeException ignored){}}
        @JavascriptInterface public String flow(String symbol){if(symbol==null||!symbol.matches("[A-Z0-9]{3,24}USDT"))return "{}";FlowDb db=new FlowDb(context);try{return db.summary(symbol,System.currentTimeMillis()/60000-14);}finally{db.close();}}
        @JavascriptInterface public String status(){long t=context.getSharedPreferences("quantdesk_prism",MODE_PRIVATE).getLong("last_data_ms",0);String s=context.getSharedPreferences("quantdesk_prism",MODE_PRIVATE).getString("service_status","Başlatılıyor");return s+(t>0?" • son kayıt "+Math.max(0,(System.currentTimeMillis()-t)/1000)+" sn önce":"");}
        @JavascriptInterface public void news(String requestId,String category,String lang){if(requestId==null||!requestId.matches("[a-z0-9]{8,40}"))return;NEWS_EXEC.execute(()->{String payload=newsData(category,lang);main.post(()->{try{webView.evaluateJavascript("window.PrismNews&&window.PrismNews.resolve("+JSONObject.quote(requestId)+","+JSONObject.quote(payload)+")",null);}catch(RuntimeException ignored){}});});}
        private String newsData(String category,String lang){String cleanLang="TR".equalsIgnoreCase(lang)?"TR":"EN";List<String> categories=new ArrayList<>();if(category!=null)for(String c:category.split(",")){String v=c.trim().toUpperCase();if(v.matches("[A-Z0-9]{1,16}")&&!categories.contains(v))categories.add(v);}if(categories.isEmpty())return newsError("Geçerli haber kategorisi yok");try{HttpUrl.Builder current=new HttpUrl.Builder().scheme("https").host("data-api.coindesk.com").addPathSegments("news/v1/article/list").addQueryParameter("lang",cleanLang).addQueryParameter("limit","50");for(String c:categories)current.addQueryParameter("categories",c);String body=request(current.build().toString());JSONObject data=new JSONObject(body);JSONArray found=data.optJSONArray("Data");if(found==null||found.length()==0)throw new IOException("Haber yok");return new JSONObject().put("provider","CoinDesk").put("data",data).toString();}catch(Exception currentError){try{HttpUrl legacy=new HttpUrl.Builder().scheme("https").host("min-api.cryptocompare.com").addPathSegments("data/v2/news").addQueryParameter("lang",cleanLang).addQueryParameter("categories",android.text.TextUtils.join(",",categories)).addQueryParameter("sortOrder","latest").build();String body=request(legacy.toString());JSONObject data=new JSONObject(body);JSONArray found=data.optJSONArray("Data");if("Error".equalsIgnoreCase(data.optString("Response"))||found==null||found.length()==0)throw new IOException("Haber yok");return new JSONObject().put("provider","CryptoCompare").put("data",data).toString();}catch(Exception fallbackError){try{return googleNews(categories.get(0),cleanLang);}catch(Exception rssError){return newsError("Haber servisine ulaşılamadı");}}}}
        private String googleNews(String category,String lang)throws Exception{boolean turkish="TR".equals(lang);String term="BTC".equals(category)?(turkish?"Bitcoin kripto":"Bitcoin cryptocurrency"):category+(turkish?" kripto":" cryptocurrency");HttpUrl url=new HttpUrl.Builder().scheme("https").host("news.google.com").addPathSegments("rss/search").addQueryParameter("q",term).addQueryParameter("hl",turkish?"tr":"en-US").addQueryParameter("gl",turkish?"TR":"US").addQueryParameter("ceid",turkish?"TR:tr":"US:en").build();String xml=request(url.toString());XmlPullParser parser=Xml.newPullParser();parser.setInput(new StringReader(xml));JSONArray articles=new JSONArray();JSONObject current=null;String source="";for(int event=parser.getEventType();event!=XmlPullParser.END_DOCUMENT;event=parser.next()){if(event==XmlPullParser.START_TAG&&"item".equals(parser.getName())){current=new JSONObject();source="";}else if(event==XmlPullParser.START_TAG&&current!=null){String tag=parser.getName();if("title".equals(tag)||"link".equals(tag)||"pubDate".equals(tag)||"source".equals(tag)){String text=parser.nextText();if("title".equals(tag))current.put("TITLE",text);else if("link".equals(tag))current.put("URL",text);else if("source".equals(tag))source=text;else try{Date d=new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z",Locale.US).parse(text);if(d!=null)current.put("PUBLISHED_ON",d.getTime()/1000);}catch(Exception ignored){}}}else if(event==XmlPullParser.END_TAG&&"item".equals(parser.getName())&&current!=null){if(!source.isEmpty())current.put("SOURCE_DATA",new JSONObject().put("NAME",source));current.put("LANG",lang);articles.put(current);current=null;if(articles.length()>=30)break;}}return new JSONObject().put("provider","Google News").put("data",new JSONObject().put("Data",articles)).toString();}
        private String request(String url)throws IOException{Request request=new Request.Builder().url(url).header("Accept","application/json").header("User-Agent","QuantDesk-Prism/2.1.0").get().build();try(Response response=NEWS_HTTP.newCall(request).execute()){if(!response.isSuccessful()||response.body()==null)throw new IOException("HTTP "+response.code());return response.body().string();}}
        private String newsError(String message){try{return new JSONObject().put("error",message).toString();}catch(Exception ignored){return "{}";}}
    }
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(webView!=null){webView.stopLoading();webView.destroy();webView=null;}super.onDestroy();}
}
