# QuantDesk Prism 250 2.0.1

Separate-install build of QuantDesk Prism for Binance USDⓈ-M perpetual contracts. Android application ID: `com.emreakdag.quantdesk.prism250`; it installs beside the original app. Version 2.0.2.

## Requested adjustments

- Directional signal strength is shown consistently for LONG and SHORT. A bearish bias of 15/100 is displayed as SHORT strength 85/100; classification thresholds, indicators and entry/stop/target calculations are unchanged. The score is not a win probability.
- The USDT perpetual list contains up to 250 contracts with at least 10,000,000 USDT 24-hour quote volume. Volume ranking is retained. Scan checks up to 250 symbols in batches of 10 and selects the strongest eligible LONG or SHORT setup.
- Analysis timeframe and chart timeframe selectors are unchanged.

All other market data, order-flow, chart, journal and application behavior is carried from the supplied source. The original ZIP was not modified.

## Verify and build

Run `node scripts/test-analysis.cjs` for synthetic directional regression checks, score and level bounds, OHLCV parsing, scanner pool and batch checks, UI/timeframe checks and the distinct application ID. Upload `QuantDesk-Prism-250-Source.zip` to the GitHub repository root, then run the provided Android Actions workflow. It runs these checks before building the debug APK and uploads `QuantDesk-Prism-250-2.0.1`. This environment has not run an Android build; the workflow does that on GitHub Actions.
