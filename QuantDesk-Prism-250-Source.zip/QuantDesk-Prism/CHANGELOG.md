# Changes

## 2.0.2
- Show signal strength in the direction of the displayed LONG or SHORT setup.
- Keep the eligible USDT perpetual list at up to 250 contracts with at least 10,000,000 USDT 24-hour quote volume; scan listed contracts in batches of 10.
- Assign a distinct Android application ID and display name so this version installs separately.
- Keep analysis and chart timeframe controls and the remaining app features unchanged.
