# Changes

## 1.0.0
- Package as a new app with a unique application ID and display name so it installs alongside all prior Prism versions.
- Include coin and Bitcoin news context while retaining the requested scan, directional scoring, timeframe and ATR level behavior.

## 2.1.0
- Search recent English and Turkish news for each selected coin and Bitcoin, with RSS fallback if API feeds are unavailable.
- Classify positive/negative headline tone and apply a capped directional score adjustment; preserve technical analysis when feeds are unavailable.
- Display recent matching headlines and publisher links.
- Retain the 10,000,000 USDT quote-volume floor, directional SHORT score, separate app identity, and existing timeframe and ATR target/stop rules.

## 2.0.2
- Show signal strength in the direction of the displayed LONG or SHORT setup.
- Keep the eligible USDT perpetual list at up to 250 contracts with at least 10,000,000 USDT 24-hour quote volume; scan listed contracts in batches of 10.
- Assign a distinct Android application ID and display name so this version installs separately.
- Keep analysis and chart timeframe controls and the remaining app features unchanged.
