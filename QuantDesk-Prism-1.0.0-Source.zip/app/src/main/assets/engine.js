(function(root){
'use strict';
const last=a=>a[a.length-1];
const mean=a=>a.reduce((s,v)=>s+v,0)/a.length;
const duration=tf=>Number(tf.slice(0,-1))*({m:60000,h:3600000,d:86400000,w:604800000}[tf.slice(-1)]||0);
const higher=tf=>({'1m':'15m','3m':'15m','5m':'1h','15m':'1h','30m':'4h','1h':'4h','2h':'12h','4h':'1d','6h':'1d','12h':'1d','1d':'1w'}[tf]||'4h');
function candles(raw,now=Date.now()) {
 if(!Array.isArray(raw)) throw Error('Mum verisi geçersiz');
 const rows=raw.filter(r=>Number(r[6])<now).map(r=>({t:+r[0],o:+r[1],h:+r[2],l:+r[3],c:+r[4],v:+r[5],end:+r[6]}));
 if(rows.some((r,i)=>![r.t,r.o,r.h,r.l,r.c,r.v,r.end].every(Number.isFinite)||r.c<=0||r.o<=0||r.l<=0||r.h<Math.max(r.o,r.c)||r.l>Math.min(r.o,r.c)||r.v<0||(i&&r.t<=rows[i-1].t)))throw Error('Mum verisi doğrulanamadı');
 return rows;
}
function ema(a,n) {
 let out=Array(a.length).fill(null); if(a.length<n)return out;
 let value=mean(a.slice(0,n));out[n-1]=value;
 for(let i=n;i<a.length;i++){value=a[i]*2/(n+1)+value*(1-2/(n+1));out[i]=value;}return out;
}
function rsi(a,n=14){if(a.length<n+1)return null;let gain=0,loss=0;for(let i=1;i<=n;i++){const d=a[i]-a[i-1];gain+=Math.max(d,0)/n;loss+=Math.max(-d,0)/n;}for(let i=n+1;i<a.length;i++){const d=a[i]-a[i-1];gain=(gain*(n-1)+Math.max(d,0))/n;loss=(loss*(n-1)+Math.max(-d,0))/n;}return !gain&&!loss?50:!loss?100:100-100/(1+gain/loss);}
function atr(rows,n=14){const tr=rows.slice(1).map((r,i)=>Math.max(r.h-r.l,Math.abs(r.h-rows[i].c),Math.abs(r.l-rows[i].c)));if(tr.length<n)return null;let a=mean(tr.slice(0,n));for(const x of tr.slice(n))a=(a*(n-1)+x)/n;return a;}
function trend(rows){if(rows.length<55)return 0;const c=rows.map(x=>x.c),a=last(ema(c,21)),b=last(ema(c,55));return Math.abs(a-b)/b<0.0006?0:a>b?1:-1;}
function correlation(a,b){const bm=new Map(b.map(x=>[x.t,x.c]));const pairs=a.filter(x=>bm.has(x.t)).slice(-61);if(pairs.length<25)return null;const x=[],y=[];for(let i=1;i<pairs.length;i++){x.push(Math.log(pairs[i].c/pairs[i-1].c));y.push(Math.log(bm.get(pairs[i].t)/bm.get(pairs[i-1].t)));}const mx=mean(x),my=mean(y);let xy=0,xx=0,yy=0;x.forEach((v,i)=>{xy+=(v-mx)*(y[i]-my);xx+=(v-mx)**2;yy+=(y[i]-my)**2;});return xx*yy?xy/Math.sqrt(xx*yy):null;}
function analyze({rows,upper,btc=[],symbol,market='futures',tf='15m',now=Date.now()}){
 if(rows.length<100||upper.length<60)throw Error('Analiz için yeterli kapanmış mum yok');
 if(now-last(upper).end>duration(higher(tf))*2)throw Error('Üst zaman verisi güncel değil');
 if(now-last(rows).end>duration(tf)*2)throw Error('Mum verisi güncel değil');
 const c=rows.map(r=>r.c),entry=last(c),fast=last(ema(c,21)),slow=last(ema(c,55)),rv=rsi(c),av=atr(rows);
 const e26=ema(c,26),e12=ema(c,12),m=e12.map((v,i)=>e26[i]===null?null:v-e26[i]).filter(v=>v!==null),hist=last(m)-last(ema(m,9));
 const dir=fast>=slow?1:-1,ut=trend(upper),bt=trend(btc),volume=last(rows).v/Math.max(mean(rows.slice(-21,-1).map(r=>r.v)),1e-12);
 const factors=[{label:'Trend • EMA 21/55',max:25,value:Math.abs(fast-slow)/entry>0.0006?25:10},{label:'Üst zaman uyumu',max:25,value:ut===dir?25:ut===0?10:0},{label:'Momentum • RSI',max:15,value:dir===1?(rv>=50&&rv<=70?15:rv>70?4:0):(rv<=50&&rv>=30?15:rv<30?4:0)},{label:'MACD histogramı',max:15,value:Math.sign(hist)===dir?15:0},{label:'Hacim teyidi',max:10,value:volume>=1.2?10:volume>=0.7?5:0},{label:'BTC yön uyumu',max:10,value:bt===dir?10:bt===0?5:0}];
 const score=factors.reduce((a,f)=>a+f.value,0),support=Math.min(...rows.slice(-30).map(r=>r.l)),resistance=Math.max(...rows.slice(-30).map(r=>r.h));
 const risk=Math.max(av*1.5,entry*0.002),stop=entry-dir*risk;
 // Nearby structural barriers cap the first target; they never inflate the score.
 const barrier=dir===1?resistance:support,dist=(barrier-entry)*dir;
 const reward=dist>0?Math.min(risk*1.4,dist*0.95):risk*1.4;
 const tp1=entry+dir*reward,tp2=entry+dir*risk*2.2;
 const fee=market==='spot'?0.001:0.0005,friction=entry*(2*fee+0.0004),rr=(reward-friction)/(risk+friction);
 const corr=correlation(rows,btc);
 const blocked=[];if(market==='spot'&&dir<0)blocked.push('Spot alım için düşüş yönü');if(rr<0.9)blocked.push('TP1 net risk/getiri yetersiz');if(ut===-dir)blocked.push('Üst zaman dilimi ters yönde');if(Math.abs(entry-fast)>av*3)blocked.push('Fiyat ortalamadan fazla uzak');if(!Number.isFinite(rr)||av<=0||stop<=0||tp1<=0||tp2<=0)blocked.push('Geçersiz fiyat yapısı');
 return{symbol,market,tf,dir,score,entry,stop,tp1,tp2,rr,atr:av,rsi:rv,fast,slow,hist,volume,support,resistance,corr,factors,blocked,upperTrend:ut,btcTrend:bt,at:now,candleEnd:last(rows).end,rows};
}
function eligible(s,threshold=70,now=Date.now()){return s.score>=threshold&&!s.blocked.length&&now-s.at<=duration(s.tf)&&now-s.candleEnd<=duration(s.tf)*2;}
function validateEntry(s,price,now=Date.now(),quoteAt=now){if(!Number.isFinite(price)||price<=0)return 'Fiyat geçersiz';if(now-quoteAt>45000)return 'Fiyat 45 saniyeden eski';if(!eligible(s,0,now))return 'Analiz yenilenmeli veya koşullar uygun değil';if(Math.abs(price-s.entry)>s.atr*0.4)return 'Fiyat giriş bölgesinden uzaklaştı';if((s.tp1-price)*s.dir<=0||(price-s.stop)*s.dir<=0)return 'Hedef veya stop aşılmış';return '';}
function pnl(position,price){const exit=price*(1-position.dir*0.0002);return (exit-position.entry)*position.dir*position.qty-position.entryFee-exit*position.qty*position.feeRate;}
function openPaper(s,price,size,at=Date.now()){if(!Number.isFinite(size)||size<10||size>10000)throw Error('Sanal tutar 10–10.000 USDT olmalı');const feeRate=s.market==='spot'?0.001:0.0005,entry=price*(1+s.dir*0.0002),qty=size/entry;return{id:at+'-'+s.symbol,symbol:s.symbol,market:s.market,dir:s.dir,entry,qty,size,entryFee:size*feeRate,feeRate,stop:s.stop,tp:s.tp1,opened:at,mark:price,markAt:at};}
const api={ema,rsi,atr,candles,trend,correlation,analyze,eligible,validateEntry,pnl,openPaper,duration,higher};
if(typeof module!=='undefined')module.exports=api;root.PrismEngine=api;
})(typeof window!=='undefined'?window:globalThis);
