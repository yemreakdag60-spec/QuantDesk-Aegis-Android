package com.quantdesk.prism;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

public final class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService network = Executors.newFixedThreadPool(3);
    private volatile boolean destroyed;
    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setBackgroundColor(0xff090e1b);
        setContentView(web);
        web.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new MarketBridge(), "MarketNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return true; }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String name = request.getUrl().getPath();
                if (!"app.quantdesk.local".equals(request.getUrl().getHost()) || name == null || !name.matches("/(index.html|style.css|engine.js|app.js)")) {
                    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                }
                try {
                    String mime = name.endsWith(".html") ? "text/html" : name.endsWith(".css") ? "text/css" : "application/javascript";
                    return new WebResourceResponse(mime, "UTF-8", getAssets().open(name.substring(1)));
                } catch (Exception error) { return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0])); }
            }
        });
        web.loadUrl("https://app.quantdesk.local/index.html");
    }
    private void complete(String id, String body, String error) {
        if (destroyed) return;
        String script = "window.nativeResult(" + JSONObject.quote(id) + "," + JSONObject.quote(body) + "," + JSONObject.quote(error) + ")";
        runOnUiThread(() -> { if (!destroyed) web.evaluateJavascript(script, null); });
    }
    private String compactResponse(String path, String body) throws Exception {
        if (path.endsWith("/exchangeInfo")) {
            JSONArray raw = new JSONObject(body).getJSONArray("symbols"), result = new JSONArray();
            for (int i = 0; i < raw.length(); i++) {
                JSONObject item = raw.getJSONObject(i);
                if (!"USDT".equals(item.optString("quoteAsset"))) continue;
                JSONObject row = new JSONObject();
                for (String key : new String[]{"symbol", "status", "quoteAsset", "baseAsset", "contractType", "isSpotTradingAllowed"}) if (item.has(key)) row.put(key, item.get(key));
                result.put(row);
            }
            return new JSONObject().put("symbols", result).toString();
        }
        if (path.endsWith("/ticker/24hr")) {
            JSONArray raw = new JSONArray(body), result = new JSONArray();
            for (int i = 0; i < raw.length(); i++) {
                JSONObject item = raw.getJSONObject(i);
                if (!item.optString("symbol").endsWith("USDT")) continue;
                JSONObject row = new JSONObject();
                for (String key : new String[]{"symbol", "lastPrice", "priceChangePercent", "quoteVolume", "highPrice", "lowPrice"}) row.put(key, item.get(key));
                result.put(row);
            }
            return result.toString();
        }
        return body;
    }
    public final class MarketBridge {
        @JavascriptInterface public void request(String id, String market, String path) {
            if (destroyed || id == null || !id.matches("[0-9]{1,10}")) return;
            if (!path.matches("/(api/v3|fapi/v1)/(time|exchangeInfo|klines|ticker/24hr|ticker/price|depth|premiumIndex)(\\?[A-Za-z0-9=&]+)?") || !(market.equals("spot") || market.equals("futures")) || (market.equals("spot") != path.startsWith("/api/v3/"))) {
                complete(id, "", "İzin verilmeyen veri isteği"); return;
            }
            network.execute(() -> {
                HttpsURLConnection connection = null;
                try {
                    String host = market.equals("spot") ? "https://data-api.binance.vision" : "https://fapi.binance.com";
                    connection = (HttpsURLConnection) new URL(host + path).openConnection();
                    connection.setConnectTimeout(20000); connection.setReadTimeout(20000);
                    connection.setInstanceFollowRedirects(false);
                    connection.setRequestProperty("Accept", "application/json");
                    int code = connection.getResponseCode();
                    if (code != 200) throw new Exception("HTTP " + code + ((code == 429 || code == 418) ? " — istek sınırı" : " — veri erişimi başarısız"));
                    try (InputStream stream = connection.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                        byte[] bytes = new byte[8192]; int count;
                        while ((count = stream.read(bytes)) != -1) { output.write(bytes, 0, count); if (output.size() > 32000000) throw new Exception("Yanıt sınırı aşıldı"); }
                        complete(id, compactResponse(path, output.toString("UTF-8")), "");
                    }
                } catch (Exception error) { complete(id, "", error.getMessage() == null ? "Bağlantı başarısız" : error.getMessage()); }
                finally { if (connection != null) connection.disconnect(); }
            });
        }
    }
    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onDestroy() { destroyed = true; network.shutdownNow(); web.removeJavascriptInterface("MarketNative"); web.destroy(); super.onDestroy(); }
}
