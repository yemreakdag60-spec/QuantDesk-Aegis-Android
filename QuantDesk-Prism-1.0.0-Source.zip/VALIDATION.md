# Doğrulama ve bilinen sınırlar

## Yapılan kontroller

- Analiz motoru: 13 otomatik test. EMA başlangıcı/reküransı; RSI artış/azalış/yatay; ATR fiyat boşluğu; açık/bozuk/eski mum; long/short seviye sırası; spot short engeli; TP1 yapısal sınırı; zamana hizalanmış korelasyon; eski fiyat ve giriş uzaklığı; sanal ücret/kayma ve pozisyon PnL; süre dolumu.
- Tarayıcı akışları: 1440 px masaüstü ve 393 px telefon görünümü; yatay taşma kontrolü. Tarama, sinyal ayrıntısı, güncel analiz doğrulama, sanal açılış/kapanış, emir defteri, favori, ayarlar, piyasa değişimi, fiyat alarmı ve tekrar açılışta kalıcı kayıt kontrolü. Sentetik veriler yalnız testte kullanıldı; uygulamada demo veri yolu yok.
- Canlı Binance Spot: saat, exchangeInfo, 24s ticker ve mum yanıtları alındı. Kaydedilmiş gerçek BTC, ETH, SOL, XRP, BNB ve DOGE yanıtlarıyla analiz ve arayüz akışı doğrulandı. Ekran önizlemesi bu kayıtları gösterir; canlı öneri değildir.
- USDⓈ-M: bu çalışma ortamındaki ağdan HTTP 451 döndü. Hata gösterimi kontrol edildi. Vadeli uçların bu ortamdan başarılı canlı testi yapılamadı; telefon/ağ üzerinde bağlantı teşhisi kullanılmalı.

## Yapılmayan doğrulamalar

Fiziksel Android cihaz testi, Android emülatöründe çalışma testi, uzun süreli arka plan/batarya testi, gerçek emir yürütme testi, kazanma oranı veya OOS strateji doğrulaması yapılmadı. APK üretimi tek başına cihazda hatasız çalışmayı veya stratejinin kârlı olmasını ispatlamaz.

## Bilinen işlevsel sınırlar

- Sanal TP/SL takibi, uygulama açıkken alınan fiyat örneklerine dayanır. Ara fiyat dokunuşlarını yakalama garantisi yoktur.
- Android uygulamayı durdurursa takip kesilir. Sonradan geçmişte işlem gerçekleşmiş gibi rapor oluşturulmaz.
- Kaynaklar ve grafikler halka açık veri erişimine bağlıdır; ağ/bölge/API limitleri çalışmayı engelleyebilir.
- Türkçe analiz kurallıdır. Skor kalibre edilmiş olasılık değildir. Öğrenme, backtest, haber, topluluk ve gerçek emir özellikleri bu sürümde yoktur.
- Sanal işlemde yalnızca komisyon ve sabit kayma varsayılır; fonlama, kaldıraç ve likidasyon hesaplanmaz.
- Debug imzalı kişisel kurulum APK'sıdır. Play Store dağıtımı için release imzası ve mağaza hazırlığı ayrıca gerekir.

Android derleme, lint ve APK içerik doğrulamasının sonuçları teslim edilen BUILD-RESULT.txt dosyasında bulunur.
