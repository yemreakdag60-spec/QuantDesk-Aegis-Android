# QuantDesk Prism 1.0.0

Türkçe Android kripto analiz terminali. Paket kimliği `com.quantdesk.prism`; önceki QuantDesk uygulamalarından ayrı kurulur. Android 8.0 ve üzeri; güncel Android System WebView gerekir.

## Özellikler

- Özgün koyu arayüz; telefon ve geniş ekrana uyumlu beş çalışma alanı.
- Binance Spot ve USDⓈ-M perpetual piyasaları, yalnızca halka açık veri.
- Hacme göre 25/50/100/200/250 USDT paritesi; geçerli işlem durumu filtresi.
- 1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 6h, 12h ve 1d mumlar; otomatik üst zaman teyidi.
- EMA21/55, Wilder RSI14, ATR14, MACD12/26/9, hacim oranı, BTC yönü ve zamana hizalanmış korelasyon.
- Giriş referansı, stop, yakın yapıyla sınırlanan TP1 ve ayrıca TP2 uzatma senaryosu.
- Skor sıralaması, tüm adaylar / uygun adaylar / long / short / favori filtreleri.
- Canvas mum ve hacim grafiği; EMA çizgileri, görünür aralıktaki giriş/TP1/stop çizgileri, dokununca mum bilgisi.
- Gerekçeli Türkçe analiz. Bu metin deterministik kurallardan üretilir; LLM servisi veya eğitilmiş model değildir.
- İlk 10 emir defteri kademesi, spread ve vadeli fonlama oranı.
- 10.000 USDT sanal portföy; 1× nominal tutarlı long/short, spotta yalnız long, TP1/SL gözlemli kapanış ve geçmiş.
- Cihazda kalan favoriler, sanal portföy ve uygulama içi fiyat uyarıları.
- İstek aralığı, zaman aşımı, hatada açık mesaj ve 429/418 sonrası 3 dakika bekleme.

## Telefonda kullanım

1. APK'yı kur, **QuantDesk Prism** uygulamasını aç.
2. **Vadeli** veya **Spot** seç. Ana ekranda **Piyasayı tara** düğmesine bas.
3. Tarama seçilen zaman dilimi ve onun üst zamanında yapılır. 250 parite birkaç dakika sürebilir.
4. Bir karta dokun. Skorun gerekçelerini ve bekleme nedenlerini incele.
5. **Fiyatı ve analizi doğrula** güncel veriyi yeniden alır. **Sanal işlem aç** aynı doğrulamayı tekrar yapar.
6. Sanal portföyden sonuçları izle; **Terminal** bölümünde parite grafiği ve emir defterini aç.

Piyasa listesi açık uygulamada 60 saniyede yenilenir. Analiz taraması kullanıcı başlatmalıdır; otomatik sonsuz tarama yapılmaz. Grafikte yalnızca kapanmış mumlar vardır. Son fiyat ile son kapanmış mum fiyatı aynı olmak zorunda değildir.

## Sanal işlem modelinin sınırları

Gerçek borsa emri, API anahtarı, para yatırma/çekme veya kimlik doğrulama yoktur. Sanal işlem tutarı kaldıraçsız nominal tutardır; fonlama, margin ve likidasyon muhasebesi yapılmaz. TP1'de tüm pozisyon kapanır; TP2 görsel senaryodur.

Uygulama açıkken yaklaşık 15 saniyede fiyat sorgulanır. TP1/SL, gözlenen fiyat hedefi aştığında gözlenen fiyattan ve kayma eklenerek kapanır. Hedefe tam dokunup geri gelen hareket kaçabilir. Telefon uygulamayı durdurduğunda izleme devam etmez; açılınca geçmişte hedefe ulaşılmış gibi kayıt oluşturulmaz. Bu nedenle geçmiş sonuçları bir strateji backtesti olarak kullanmayın.

Skor başarı yüzdesi değildir. Zorunlu iki sinyal, garantili hedef veya her işlemde kazanç yoktur. Bu sürümün OOS doğrulaması, öğrenen modeli, likidasyon haritası, footprint grafiği, haber akışı, sohbet/topluluk ve arka plan foreground servisi yoktur. Emir defteri anlık bir fotoğraftır.

Komisyon varsayımı: spot %0,10/yön, vadeli %0,05/yön. Kayma: %0,02/yön. Gerçek maliyet hesabını veya borsa gerçekleşmesini temsil etmez.

## APK'yı GitHub'da üretme — iki dosya

1. Depo ana dizinine **QuantDesk-Prism-1.0.0-Source.zip** dosyasını yükle. ZIP'i GitHub'da açmana gerek yok.
2. Depoda **Add file → Create new file** seç. Dosya adı alanına **`.github/workflows/build-apk.yml`** yaz.
3. Verilen **build-apk.yml** dosyasının içeriğinin tamamını yapıştır, **Commit changes** yap. İstersen dosyayı `.github/workflows` klasörüne yükle.
4. **Actions → Build QuantDesk Prism APK → Run workflow** seç. `push` ile de başlar.
5. Başarılı çalışmayı aç, alttaki **Artifacts → QuantDesk-Prism-1.0.0-APK** dosyasını indir.
6. İndirilen ZIP'i aç ve içindeki APK'yı kur. `build-reports` uygulama değildir.

Workflow hem kaynakları doğrudan depoda hem de tek kaynak ZIP halinde kabul eder. Eski Prism kaynak ZIP'lerini aynı depoda birlikte bırakmayın; belirsiz sürümü derlemek yerine açık hata verir.

APK debug imzasıyla kişisel test kurulumu içindir. Ayrı derleme ortamları farklı debug imzası üretebilir; sonraki sürümler için aynı kişisel release anahtarını kullanmak gerekir. Farklı imzalı APK mevcut Prism üzerine yüklenmeyebilir. Kaldırıp kurmak cihazdaki sanal kayıtları siler. Önceki başka QuantDesk paketleri etkilenmez.

## Yerel geliştirme

JDK 17, Android SDK platform 35, build-tools 34.0.0 ve Gradle 8.9 gerekir. Android Studio bu Gradle projesini açabilir.

```sh
node --test tests/engine.test.cjs
gradle :app:assembleDebug :app:lintDebug
```

Bağımsız analiz motoru `app/src/main/assets/engine.js`, arayüz `app.js`, `style.css`, `index.html`. Java kabuk yalnızca izin verilen HTTPS piyasa uçlarına bağlanır. Harici sayfalara gitmez. UI JavaScript'i sadece paketlenmiş dosyalardan çalışır. API anahtarı istemez veya saklamaz.

Tarayıcıda geliştirme: `python3 -m http.server 8080 --directory app/src/main/assets`, sonra `http://localhost:8080`. Binance erişimi tarayıcı CORS/bölge koşullarına tabidir. Android sürümü HTTPS isteğini Java katmanından yapar.

## Resmi teknik kaynaklar

- https://developers.binance.com/en/docs/catalog/core-trading-spot-trading/api/rest-api/market
- https://developers.binance.com/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data
- https://github.com/binance/binance-spot-api-docs/blob/master/faqs/market_data_only.md
- https://developer.android.com/build/releases/agp-8-7-0-release-notes

Başka uygulamaların özel kodu, markası, ücretli sinyalleri veya gizli özellikleri kopyalanmamıştır. Verilen ekran görüntülerindeki kullanıcı işlevleri esas alınarak özgün uygulama geliştirilmiştir.
