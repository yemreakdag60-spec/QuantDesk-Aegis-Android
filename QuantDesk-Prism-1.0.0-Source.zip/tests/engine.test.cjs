const test=require('node:test');const assert=require('node:assert/strict');const E=require('../app/src/main/assets/engine.js');
function rows(n=180,drift=.2,tf='15m'){const dt=E.duration(tf),end=Math.floor(Date.now()/dt)*dt;return Array.from({length:n},(_,i)=>{const o=100+i*drift,c=o+drift*.6;return{t:end-(n-i)*dt,end:end-(n-i-1)*dt-1,o,c,h:Math.max(o,c)+.6,l:Math.min(o,c)-.6,v:100+i%4*10};});}
function signal(drift=.2,market='futures'){return E.analyze({rows:rows(180,drift),upper:rows(130,drift,'1h'),btc:rows(180,drift),symbol:'TESTUSDT',market,tf:'15m'});}
test('EMA SMA seed and recurrence',()=>assert.deepEqual(E.ema([1,2,3,4,5],3),[null,null,2,3,4]));
test('RSI increasing/decreasing/flat boundaries',()=>{assert.equal(E.rsi(Array.from({length:50},(_,i)=>i)),100);assert.equal(E.rsi(Array.from({length:50},(_,i)=>50-i)),0);assert.equal(E.rsi(Array(50).fill(1)),50);});
test('ATR accounts for price gaps',()=>{const r=rows(30,0);r[29]={...r[29],o:110,c:110,h:111,l:109};assert.ok(E.atr(r)>1.8);});
test('Reject open candles and corrupt market data',()=>{const r=[Date.now()-60000,10,12,9,11,100,Date.now()+1000];assert.equal(E.candles([r]).length,0);r[6]=Date.now()-1;r[2]=8;assert.throws(()=>E.candles([r]));});
test('Reject stale data and insufficient history',()=>{const s=signal();assert.throws(()=>E.analyze({...s,upper:rows(130,.2,'1h'),rows:rows(30)}));assert.throws(()=>E.analyze({...s,upper:rows(130,.2,'1h'),now:Date.now()+86400000}));});
test('Long levels ordered and score is bounded',()=>{const s=signal();assert.equal(s.dir,1);assert.ok(s.stop<s.entry&&s.entry<s.tp1&&s.tp1<=s.tp2);assert.ok(s.score>=0&&s.score<=100);assert.equal(s.factors.reduce((a,b)=>a+b.value,0),s.score);});
test('Short levels ordered and spot short blocked',()=>{const s=signal(-.2);assert.equal(s.dir,-1);assert.ok(s.stop>s.entry&&s.entry>s.tp1&&s.tp1>=s.tp2);assert.ok(signal(-.2,'spot').blocked.some(x=>x.includes('Spot')));});
test('Nearby resistance caps TP1 and blocks weak net reward',()=>{const s=signal();assert.ok(s.tp1<=s.resistance);assert.ok(s.blocked.some(x=>x.includes('risk/getiri')));});
test('Correlation joins candle times instead of array position',()=>{const r=rows();assert.ok(Math.abs(E.correlation(r,r)-1)<1e-10);assert.equal(E.correlation(r,r.map(x=>({...x,t:x.t+1}))),null);});
test('Expired quotes and drift are blocked',()=>{const s={...signal(),blocked:[],score:90};assert.match(E.validateEntry(s,s.entry,Date.now(),Date.now()-46000),/45/);assert.match(E.validateEntry(s,s.entry+s.atr,Date.now()),/uzaklaştı/);assert.equal(E.validateEntry(s,s.entry,Date.now()),'');});
test('Paper fees/slippage yield a loss at unchanged price',()=>{const s=signal(),p=E.openPaper(s,100,1000);assert.ok(E.pnl(p,100)<-1);assert.ok(E.pnl(p,105)>0);assert.throws(()=>E.openPaper(s,100,-50));assert.throws(()=>E.openPaper(s,100,NaN));});
test('Short paper accounting reverses direction',()=>{const p=E.openPaper({...signal(),dir:-1},100,1000);assert.ok(E.pnl(p,95)>0);assert.ok(E.pnl(p,105)<0);});
test('No signal is eligible forever',()=>{const s={...signal(),blocked:[]};assert.equal(E.eligible(s,0,Date.now()+E.duration(s.tf)*3),false);});
