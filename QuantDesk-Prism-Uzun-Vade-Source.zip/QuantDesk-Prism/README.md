# QuantDesk Prism Uzun Vade 1.0.0

Independent Android app for Binance USDⓈ-M perpetual analysis. Android application ID: `com.emreakdag.quantdesk.prism250longterm`, distinct from the original app, Prism Haber and earlier Prism installs. It installs as a separate app and does not replace or update them. Display name: QuantDesk Prism Uzun Vade. Version 1.0.0.

## Requested adjustments

- Directional signal strength is shown consistently for LONG and SHORT. A bearish bias of 15/100 is displayed as SHORT strength 85/100; classification thresholds, indicators and entry/stop/target calculations are unchanged. The score is not a win probability.
- The USDT perpetual list contains up to 250 contracts with at least 10,000,000 USDT 24-hour quote volume. Volume ranking is retained. Scan checks up to 250 symbols in batches of 10 and selects the strongest eligible LONG or SHORT setup.
- Each analyzed contract checks the latest 72 hours of asset-specific and Bitcoin-tagged headlines in English and Turkish. Headline tone is classified from provider sentiment when available, otherwise by a compact positive/negative keyword model. Asset news contributes 65% and BTC news 35% to a bounded adjustment of at most 8 points. When the feed is unavailable or has no relevant articles, the technical score is unchanged. Headlines link to their publisher.
- CoinDesk is tried first, then CryptoCompare, then Google News RSS as a no-key fallback. News calls are cached for five minutes. The automatic headline classifier can misread context and is not a verified causal market signal.
- Add 12-hour, 1-day, 2-day, 3-day, 5-day, 1-week, 15-day, 1-month, 3-month and 6-month options to both analysis and chart selectors; keep all previous options.
- Use Binance-native intervals where available. Aggregate 2-day, 5-day and 15-day OHLCV from daily candles, and 3-month and 6-month OHLCV from monthly candles.
- When history is shorter than the model's 80-candle requirement, still show the chart and a historical range summary, and suppress the scored signal.

All other market data, order-flow, chart, journal and application behavior is carried from the supplied source.

## Verify and build

Run `node scripts/test-analysis.cjs` for synthetic directional regression checks, score and level bounds, news sentiment and impact checks, OHLCV parsing and aggregation, scanner pool and batch checks, UI/timeframe checks and the distinct application ID. Upload `QuantDesk-Prism-Uzun-Vade-Source.zip` to the GitHub repository root, then run the provided Android Actions workflow. It runs these checks before building the debug APK and uploads `QuantDesk-Prism-Uzun-Vade-1.0.0`. This environment has not run an Android build; the workflow does that on GitHub Actions.
