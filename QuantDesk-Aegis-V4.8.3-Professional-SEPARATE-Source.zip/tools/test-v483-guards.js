const fs = require('fs');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');

for (const invariant of [
  'proGuardBlocks',
  "...(r.proGuardBlocks||[])",
  'opposingFlowCount>=2',
  "order-flow güçlü ters (iki kontrol)",
  'refreshBtcContext',
  'BTC_REFRESH_MS=60000',
  'journalSignals();render()',
  'Akış Veri Kalitesi',
  'türetilmiş TF\'ler bağımsız örnek değildir',
  'yükseliş sonrası ters akış / geç giriş riski'
]) {
  if (!html.includes(invariant)) throw new Error(`V4.8.3 guard is missing: ${invariant}`);
}

const complete = html.indexOf('scanComplete=true;journalSignals()');
if (complete < 0) throw new Error('Learning journal must run only after scan completion');
if (html.includes('journalSignals();scanComplete=true')) {
  throw new Error('Learning journal still runs before scan completion');
}

console.log('V4.8.3 persistent PRO guards, live BTC refresh and outcome-learning invariants passed');
