# QuantDesk Aegis FlowGuard V4.2

Side-by-side Android test edition of QuantDesk Aegis Pro (`com.quantdesk.aegis.flowguard`).

## Runtime design

- Scans 200 Binance USD-M perpetual markets in the bundled UI.
- Reads 13 chart timeframes from 1 minute through 24 hours.
- Keeps a foreground service alive for background market collection.
- Tracks the 20 highest-volume USDT perpetuals with aggregate trades and depth streams.
- Stores one-minute buy/sell notional, trade count, depth pressure, separate long/short liquidations, cancellation anomalies, freshness, and sample quality in local SQLite.
- Calibrates reachable TP levels from rolling 1m/5m/15m favorable excursions and nearby market barriers.
- Calibrates SL distance from adverse excursions and structure, then learns with bounded weight from resolved on-device signals.
- Uses order-flow in the final score only when freshness and quality thresholds pass; strong contrary flow can veto a signal.
- Retains seven days of aggregated order-flow data and reconnects automatically.
- Starts after device reboot or application update.
- Uses no API key and does not submit orders.

Android may stop background collection if the user force-stops the app or restricts its battery use. Set battery usage to unrestricted for continuous collection.

## APK

The GitHub Actions workflow builds a debug-signed installable APK and publishes it as the `QuantDesk-Aegis-FlowGuard-V4.2` workflow artifact.
