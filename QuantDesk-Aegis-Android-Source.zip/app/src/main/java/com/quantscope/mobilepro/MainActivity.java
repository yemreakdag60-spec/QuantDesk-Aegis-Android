package com.quantdesk.aegis;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.content.Intent;
import android.os.Build;
import android.Manifest;
import android.webkit.JavascriptInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7, 17, 31));
        getWindow().setNavigationBarColor(Color.rgb(7, 17, 31));

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setAllowContentAccess(false);
        s.setAllowFileAccess(true);
        // Required because the bundled local UI retrieves HTTPS public market data.
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AegisBridge(), "AegisNative");

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 41);
        Intent svc = new Intent(this, MarketDataService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc); else startService(svc);

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    public final class AegisBridge {
        @JavascriptInterface public String status() {
            return getSharedPreferences("aegis", MODE_PRIVATE).getString("status", "Başlatılıyor");
        }
        @JavascriptInterface public String flow(String symbol) {
            String s=symbol==null?"BTCUSDT":symbol.replaceAll("[^A-Z0-9]","");
            double buy=0,sell=0,bid=0,ask=0,liq=0,spoof=0; int trades=0;
            try(SQLiteDatabase db=openOrCreateDatabase("aegis_flow.db",MODE_PRIVATE,null); Cursor c=db.rawQuery("SELECT SUM(buy),SUM(sell),SUM(trades),AVG(bid_depth),AVG(ask_depth),SUM(liquidations),MAX(spoof) FROM flow_minute WHERE symbol=? AND minute>?",new String[]{s,String.valueOf(System.currentTimeMillis()/60000-60)})){
                if(c.moveToFirst()){buy=c.getDouble(0);sell=c.getDouble(1);trades=c.getInt(2);bid=c.getDouble(3);ask=c.getDouble(4);liq=c.getDouble(5);spoof=c.getDouble(6);}
            }catch(Exception ignored){}
            double delta=buy-sell,imb=(bid+ask)>0?(bid-ask)/(bid+ask)*100:0;
            return "{\"symbol\":\""+s+"\",\"buy\":"+buy+",\"sell\":"+sell+",\"delta\":"+delta+",\"trades\":"+trades+",\"bookImbalance\":"+imb+",\"liquidations\":"+liq+",\"spoofRisk\":"+spoof+"}";
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
