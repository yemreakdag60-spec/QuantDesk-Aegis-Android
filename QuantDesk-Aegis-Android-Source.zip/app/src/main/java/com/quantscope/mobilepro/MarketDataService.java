package com.quantdesk.aegis;

import android.app.*;
import android.content.*;
import android.database.sqlite.SQLiteDatabase;
import android.os.*;
import org.json.*;
import java.util.*;
import java.util.concurrent.*;
import okhttp3.*;

public class MarketDataService extends Service {
    private static final String CHANNEL="aegis_market", REST="https://fapi.binance.com", WS="wss://fstream.binance.com/stream?streams=";
    private final OkHttpClient http=new OkHttpClient.Builder().pingInterval(20,TimeUnit.SECONDS).retryOnConnectionFailure(true).build();
    private final ScheduledExecutorService timer=Executors.newSingleThreadScheduledExecutor();
    private final Map<String,Bucket> buckets=new ConcurrentHashMap<>(), depthPrev=new ConcurrentHashMap<>();
    private volatile WebSocket socket; private volatile String[] symbols={"BTCUSDT","ETHUSDT","SOLUSDT","BNBUSDT","XRPUSDT","DOGEUSDT","ADAUSDT","LINKUSDT","AVAXUSDT","SUIUSDT"};
    private SQLiteDatabase db; private int retry=1;

    static final class Bucket { long minute; double buy,sell,bid,ask,liq,spoof; int trades; }

    @Override public void onCreate(){super.onCreate();channel();startForeground(41,notification("Order-flow başlatılıyor"));db=openOrCreateDatabase("aegis_flow.db",MODE_PRIVATE,null);db.execSQL("CREATE TABLE IF NOT EXISTS flow_minute(symbol TEXT,minute INTEGER,buy REAL DEFAULT 0,sell REAL DEFAULT 0,trades INTEGER DEFAULT 0,bid_depth REAL DEFAULT 0,ask_depth REAL DEFAULT 0,liquidations REAL DEFAULT 0,spoof REAL DEFAULT 0,PRIMARY KEY(symbol,minute))");connect();timer.scheduleAtFixedRate(this::flush,20,20,TimeUnit.SECONDS);timer.scheduleAtFixedRate(this::refreshUniverse,2,30,TimeUnit.MINUTES);timer.scheduleAtFixedRate(()->{if(socket!=null)socket.close(1000,"scheduled refresh");connect();},6,6,TimeUnit.HOURS);}
    @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
    @Override public IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){flush();if(socket!=null)socket.cancel();timer.shutdownNow();http.dispatcher().executorService().shutdown();super.onDestroy();}

    private void channel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"QuantDesk piyasa verisi",NotificationManager.IMPORTANCE_LOW);c.setDescription("Order-flow verilerini arka planda toplar");getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    private Notification notification(String text){Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);return b.setContentTitle("QuantDesk Aegis Pro").setContentText(text).setSmallIcon(android.R.drawable.stat_notify_sync).setOngoing(true).setContentIntent(pi).build();}
    private void status(String s){getSharedPreferences("aegis",MODE_PRIVATE).edit().putString("status",s).putLong("last",System.currentTimeMillis()).apply();getSystemService(NotificationManager.class).notify(41,notification(s));}
    private synchronized void connect(){if(socket!=null)socket.cancel();StringBuilder u=new StringBuilder(WS);for(int i=0;i<symbols.length;i++){String s=symbols[i].toLowerCase(Locale.US);if(i>0)u.append('/');u.append(s).append("@aggTrade/").append(s).append("@depth20@500ms");}u.append("/!forceOrder@arr");socket=http.newWebSocket(new Request.Builder().url(u.toString()).build(),new WebSocketListener(){@Override public void onOpen(WebSocket w,Response r){retry=1;status("Canlı • "+symbols.length+" coin order-flow");}@Override public void onMessage(WebSocket w,String text){parse(text);}@Override public void onFailure(WebSocket w,Throwable t,Response r){status("Bağlantı yenileniyor");int d=Math.min(60,retry*=2);timer.schedule(MarketDataService.this::connect,d,TimeUnit.SECONDS);}});}
    private Bucket bucket(String symbol){long m=System.currentTimeMillis()/60000;String key=symbol+":"+m;return buckets.computeIfAbsent(key,k->{Bucket b=new Bucket();b.minute=m;return b;});}
    private void parse(String text){try{JSONObject root=new JSONObject(text);String stream=root.optString("stream");Object raw=root.opt("data");if(stream.equals("!forceOrder@arr")){JSONArray a=raw instanceof JSONArray?(JSONArray)raw:new JSONArray();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i).optJSONObject("o");if(o==null)continue;String s=o.optString("s");bucket(s).liq+=o.optDouble("ap",o.optDouble("p"))*o.optDouble("q");}return;}JSONObject d=(JSONObject)raw;String s=d.optString("s");if(s.isEmpty())return;Bucket b=bucket(s);if(stream.contains("@aggTrade")){double n=d.optDouble("p")*d.optDouble("q");if(d.optBoolean("m"))b.sell+=n;else b.buy+=n;b.trades++;}else if(stream.contains("@depth")){double bid=sum(d.optJSONArray("b")),ask=sum(d.optJSONArray("a"));double[] p=depthPrev.get(s);if(p!=null){double disappear=Math.max(0,p[0]-bid)+Math.max(0,p[1]-ask);double base=Math.max(1,p[0]+p[1]);if(disappear/base>.28&&b.trades<4)b.spoof=Math.max(b.spoof,Math.min(100,disappear/base*100));}depthPrev.put(s,new double[]{bid,ask});b.bid=bid;b.ask=ask;}}catch(Exception ignored){}}
    private double sum(JSONArray a){double x=0;if(a!=null)for(int i=0;i<a.length();i++){JSONArray r=a.optJSONArray(i);if(r!=null)x+=r.optDouble(0)*r.optDouble(1);}return x;}
    private synchronized void flush(){if(db==null)return;for(Map.Entry<String,Bucket> e:new ArrayList<>(buckets.entrySet())){Bucket b=e.getValue();db.execSQL("INSERT OR REPLACE INTO flow_minute(symbol,minute,buy,sell,trades,bid_depth,ask_depth,liquidations,spoof) VALUES(?,?,?,?,?,?,?,?,?)",new Object[]{e.getKey().split(":")[0],b.minute,b.buy,b.sell,b.trades,b.bid,b.ask,b.liq,b.spoof});if(b.minute<System.currentTimeMillis()/60000)buckets.remove(e.getKey());}db.execSQL("DELETE FROM flow_minute WHERE minute<?",new Object[]{System.currentTimeMillis()/60000-7*24*60});}
    private void refreshUniverse(){Request q=new Request.Builder().url(REST+"/fapi/v1/ticker/24hr").build();http.newCall(q).enqueue(new Callback(){public void onFailure(Call c,java.io.IOException e){}public void onResponse(Call c,Response r){try(ResponseBody body=r.body()){if(!r.isSuccessful()||body==null)return;JSONArray a=new JSONArray(body.string());List<JSONObject> rows=new ArrayList<>();for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);if(x.optString("symbol").endsWith("USDT"))rows.add(x);}rows.sort((x,y)->Double.compare(y.optDouble("quoteVolume"),x.optDouble("quoteVolume")));String[] next=new String[Math.min(20,rows.size())];for(int i=0;i<next.length;i++)next[i]=rows.get(i).optString("symbol");if(!Arrays.equals(next,symbols)){symbols=next;connect();}}catch(Exception ignored){}}});}
}
