# QuantDesk Aegis Pro Android

Android foreground-service edition of QuantDesk Aegis Pro.

## Runtime design

- Scans 200 Binance USD-M perpetual markets in the bundled UI.
- Reads 13 chart timeframes from 1 minute through 24 hours.
- Keeps a foreground service alive for background market collection.
- Tracks the 20 highest-volume USDT perpetuals with aggregate trades and depth streams.
- Stores one-minute buy/sell notional, trade count, depth pressure, liquidation value, and spoofing-risk observations in local SQLite.
- Retains seven days of aggregated order-flow data and reconnects automatically.
- Starts after device reboot or application update.
- Uses no API key and does not submit orders.

Android may stop background collection if the user force-stops the app or restricts its battery use. Set battery usage to unrestricted for continuous collection.

## APK

The GitHub Actions workflow builds a debug-signed installable APK and publishes it as the `QuantDesk-Aegis-Pro-Android` workflow artifact.
