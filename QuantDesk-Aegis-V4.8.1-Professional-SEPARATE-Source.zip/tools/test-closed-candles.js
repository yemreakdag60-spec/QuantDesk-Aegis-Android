const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const lines = html.split(/\r?\n/);
const parseLine = lines.find((x) => x.startsWith('function parseK('));
const directionLine = lines.find((x) => x.startsWith('function spotTradeDirection('));
const stopLine = lines.find((x) => x.startsWith('function priorStopBreached('));
const aggregateLine = lines.find((x) => x.startsWith('function aggregateMs('));
if (!parseLine || !directionLine || !stopLine || !aggregateLine) throw new Error('Closed-candle, derived-candle, Spot direction, or prior-stop rule was not found');

class FixedDate extends Date { static now() { return 1000; } }
const context = { Date: FixedDate };
vm.createContext(context);
vm.runInContext(`${parseLine}\n${aggregateLine}\n${directionLine}\n${stopLine}`, context);

const bars = [
  [0, 10, 12, 9, 11, 100, 999, 0, 1, 60],
  [60000, 11, 15, 10, 14, 500, 1001, 0, 8, 400],
];
const parsed = context.parseK(bars);
if (parsed.c.length !== 1 || parsed.c[0] !== 11 || parsed.v[0] !== 100) {
  throw new Error('An unfinished kline must not affect indicator inputs');
}
const fiveMinuteBars = [
  [0,10,12,9,11,100,299999,0,1,60],
  [300000,11,13,10,12,120,599999,0,1,70],
  [600000,12,14,11,13,140,899999,0,1,80],
];
const derivedTenMinute = context.aggregateMs(fiveMinuteBars, 600000);
if (derivedTenMinute.length !== 1 || derivedTenMinute[0][4] !== 12 || derivedTenMinute[0][5] !== 220) {
  throw new Error('An incomplete derived timeframe bucket must never enter indicator inputs');
}
if (context.spotTradeDirection('LONG') !== 'LONG') throw new Error('Spot long entries should remain eligible');
if (context.spotTradeDirection('SHORT') !== 'BEKLE' || context.spotTradeDirection('BEKLE') !== 'BEKLE') {
  throw new Error('Spot must never present a short sale as an executable entry');
}
if (!context.priorStopBreached('LONG', 98, 99, true) || !context.priorStopBreached('SHORT', 102, 101, true)) {
  throw new Error('A previously published same-setup stop must remain an invalidation boundary');
}
if (context.priorStopBreached('LONG', 98, 99, false)) throw new Error('A new setup must not inherit an old setup stop');

console.log('Closed-candle inputs and Spot-only long direction scenarios passed');
