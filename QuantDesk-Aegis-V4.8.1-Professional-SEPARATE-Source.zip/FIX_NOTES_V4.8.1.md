# QuantDesk Aegis V4.8.1 Professional

V4.8.1, V4.8.0 karar mimarisini koruyan doğruluk ve veri bütünlüğü sürümüdür. Ayrı uygulama kimliği `com.quantdesk.aegis.professional.v480` değişmediği için V4.8.0 üzerine güncellenir; eski V4.7.4 kurulumundan ayrı kalır.

## Düzeltilen kritik noktalar

- Türetilmiş 10m, 20m, 25m, 30m, 45m, 2h, 3h, 6h, 12h ve 24h zaman dilimlerine artık tamamlanmamış son kova alınmaz.
- TP erişim ve stop-öncelikli yol ölçümü her tarihsel pencereyi o pencerenin kendi Wilder ATR değeriyle normalize eder. Güncel ATR geçmişin tamamına uygulanmaz.
- Kritik 1m, 5m, 15m, 1h, 4h veya 24h veri geçmişi yetersizse işlem kapısı kapanır.
- Cihaz modeli en az 24 sonuçtan sonra aynı bağlamda ağırlıklı isabeti %32'nin altına düşerse yeni işlem yayınını engeller. Öğrenme modeli hiçbir zaman BTC, veri, TP/SL, maliyet, order-flow veya risk kapısını geçersiz kılamaz.
- Aynı mumda TP ve SL görülürse muhafazakâr biçimde stop önce kabul edilmeye devam eder.

## Profesyonel karar sırası

1. Binance işlem gören USDT evreni ve 24 saatlik likidite
2. Kapanmış mum ve veri yeterliliği
3. BTC rejimi, korelasyon ve güçlü ters-yön vetosu
4. 6 doğal + 10 kapanmış-türetilmiş zaman dilimi
5. Likidite, tanınırlık, spread ve teknik uyumla 50 sözleşmelik PRO havuzu
6. Ulaşılabilir TP, stop-öncelikli tarihsel yol ve maliyet sonrası beklenti
7. Canlı fiyat, spread, aggTrade, order-book ve Futures türev akışı
8. 90–180 saniyelik volatiliteye bağlı yeniden doğrulama
9. Yalnız tüm kapıları geçen plan için pozisyon boyutu

Uygulama yapay biçimde en az iki işlem üretmez. En az iki güçlü kurulum canlı izleme rafında tutulur; bunlar işlem sinyali sayılmaz. Bu ayrım, boş listeyi doldurmak için risk kapılarının gevşetilmesini önler.

## Doğrulama

Kaynak paketindeki Node testleri kapanmış mum, Wilder ATR/ADX, Spot yönü, TP/SL geometrisi, stop-öncelikli TP erişimi, walk-forward koruması, canlı izleme, order-flow, pozisyon boyutu ve Android bildirim sözleşmesini kontrol eder. GitHub Actions ayrıca Android birim testi, debug APK derlemesi ve Android Lint çalıştırır.
