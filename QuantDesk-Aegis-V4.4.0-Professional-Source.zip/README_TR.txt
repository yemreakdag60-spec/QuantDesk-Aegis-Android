QUANTDESK AEGIS V4.4.0 PROFESSIONAL - ANDROID APK PROJESI

Ayri kurulum paketi: com.quantdesk.aegis.professional.v440

CALISMA MIMARISI:
- Binance USD-M uzerindeki aktif 200 USDT perpetual sozlesmeyi tarar.
- 5 dogal Binance zaman dilimi ile bunlardan acikca turetilen 8 zaman dilimini kullanir.
- PRO dogrulamayi en likit 50 uygun sozlesmeye uygular; bu evren Android order-flow servisiyle aynidir.
- Ilk 20 kademe derinlik, aggTrade ve zorunlu likidasyon verilerini gorunur on plan servisinde toplar.
- Order-flow yalnizca tazelik, kapsam, islem sayisi ve derinlik ornegi esiklerini gecerse karara katilir.
- Canli adaylar donusumlu kuyrukla yaklasik 20 saniyede bir yeniden dogrulanir; son basarili kontrol 90 saniyeyi asarsa yeni giris gecici olarak durur ve kosullar uygunsa otomatik geri gelir.
- Giris, adaptif SL ve TP1/TP2/TP3 seviyelerinde yon/siralama ve net R/R kontrolleri vardir. TP2/TP3 kosulludur.
- Pozisyon boyutu yalnizca canli dogrulanmis SIMDI GIR adayinda, komisyon ve kayma dahil hesaplanir.
- Uygulama emir gondermez ve gercek borsa kar/zararini izlemez.

APK OLUSTURMA:
1) GitHub Actions icinde Build QuantDesk APK is akisini calistirin veya projeyi Android Studio ile acin.
2) Android SDK 36 ve gerekli Gradle bilesenlerini kurun.
3) Build APKs secenegiyle derleyin.
4) Cikti: app/build/outputs/apk/debug/app-debug.apk

Uygulama zorla durdurulursa veya telefon pil kisitlamasi uygularsa servis durabilir. Uygulamayi acmak servisi yeniden baslatir. Kesintisiz toplama icin agresif pil optimizasyonunu kapatin.

Sinyaller, TP/SL ve skorlar kar garantisi veya yatirim tavsiyesi degildir.
