@echo off
setlocal
cd /d "%~dp0"
where gradle >nul 2>nul
if %errorlevel%==0 (
  echo Gradle bulundu. APK derleniyor...
  gradle :app:assembleDebug
  if exist "app\build\outputs\apk\debug\app-debug.apk" (
    echo.
    echo TAMAMLANDI: app\build\outputs\apk\debug\app-debug.apk
  ) else (
    echo Derleme tamamlanamadi. Android Studio ile projeyi acin.
  )
) else (
  echo Sistem Gradle bulunamadi.
  echo Android Studio ile bu klasoru acin ve Build APKs secenegini kullanin.
  start "" .
)
pause
