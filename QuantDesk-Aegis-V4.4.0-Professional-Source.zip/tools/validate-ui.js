const fs = require('fs');
const vm = require('vm');

const file = 'app/src/main/assets/index.html';
const html = fs.readFileSync(file, 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/);

if (!script) throw new Error('Bundled UI script was not found');
new vm.Script(script[1], { filename: file });

const ids = [...html.matchAll(/\sid="([^"]+)"/g)].map((match) => match[1]);
const duplicates = ids.filter((id, index) => ids.indexOf(id) !== index);
if (duplicates.length) throw new Error(`Duplicate HTML IDs: ${[...new Set(duplicates)].join(', ')}`);

const referencedIds = [...script[1].matchAll(/\$\('#([^']+)'\)/g)].map((match) => match[1]);
const missing = referencedIds.filter((id) => !ids.includes(id));
if (missing.length) throw new Error(`Missing HTML IDs: ${[...new Set(missing)].join(', ')}`);

for (const name of ['klines', 'isActionable', 'isLiveNear', 'refreshLiveSignals', 'riskCalc']) {
  const count = (script[1].match(new RegExp(`function\\s+${name}\\b`, 'g')) || []).length;
  if (count !== 1) throw new Error(`${name} definition count is ${count}, expected 1`);
}

for (const required of ['Net R/R TP1', 'Net R/R TP2', 'Net R/R TP3', 'Adaptif Stop Loss']) {
  if (!html.includes(required)) throw new Error(`Required TP/SL field is missing: ${required}`);
}

console.log('Bundled UI validation passed');
