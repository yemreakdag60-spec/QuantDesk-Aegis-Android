# QuantDesk Aegis V4.4.0 Professional

Standalone Android package: `com.quantdesk.aegis.professional.v440`.

## Runtime design

- Scans 200 active Binance USDⓈ-M USDT perpetual contracts.
- Uses 5 native Binance intervals and 8 explicitly derived intervals.
- Applies PRO derivatives validation to the 50 most liquid eligible contracts, matching the native order-flow universe.
- Collects first-20-level depth, aggregate trades and forced liquidations in a user-visible foreground service.
- Stores 15-minute order-flow windows in local SQLite and reconnects automatically.
- Uses order-flow only after freshness, coverage, trade-count and depth-sample gates pass.
- Revalidates live candidates about every 20 seconds with a rotating queue. A candidate becomes temporarily non-actionable when its last successful validation is older than 90 seconds and automatically returns if revalidation still passes.
- Calculates entry, adaptive SL and TP1/TP2/TP3 with direction, ordering and net R/R integrity checks. TP2 and TP3 are conditional targets.
- Calculates position size only for a currently validated `NOW ENTER` candidate and includes configurable fees and slippage.
- Uses public data only. It does not send orders or track actual exchange P/L.

Android may stop the service after a force-stop or an OEM battery restriction. Opening the app starts it again. For continuous collection, exclude the app from aggressive battery optimization.

## Build

Run the GitHub Actions `Build QuantDesk APK` workflow or open the project in Android Studio with SDK 36. The workflow publishes `QuantDesk-Aegis-Professional-V4.4.0` containing `app-debug.apk`.

Signals and levels are decision-support outputs, not profit guarantees or investment advice.
