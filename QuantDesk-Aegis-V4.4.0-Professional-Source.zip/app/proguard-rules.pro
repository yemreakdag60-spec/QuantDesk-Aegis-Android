# QuantScope Mobile Pro - no custom ProGuard rules required.
