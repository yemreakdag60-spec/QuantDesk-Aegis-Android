package com.quantdesk.prism;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

public final class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService network = Executors.newFixedThreadPool(3);
    private volatile boolean destroyed;
    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setBackgroundColor(0xff090e1b);
        setContentView(web);
        web.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new MarketBridge(), "MarketNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return true; }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String name = request.getUrl().getPath();
                if (!"app.quantdesk.local".equals(request.getUrl().getHost()) || name == null || !name.matches("/(index.html|style.css|engine.js|app.js|live.js|quant.js|pro.js|charts.js|research.js|analytics.js|advanced.js)")) {
                    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                }
                try {
                    String mime = name.endsWith(".html") ? "text/html" : name.endsWith(".css") ? "text/css" : "application/javascript";
                    return new WebResourceResponse(mime, "UTF-8", getAssets().open(name.substring(1)));
                } catch (Exception error) { return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0])); }
            }
        });
        web.loadUrl("https://app.quantdesk.local/index.html");
    }
    private void complete(String id, String body, String error) {
        if (destroyed) return;
        String script = "window.nativeResult(" + JSONObject.quote(id) + "," + JSONObject.quote(body) + "," + JSONObject.quote(error) + ")";
        runOnUiThread(() -> { if (!destroyed) web.evaluateJavascript(script, null); });
    }
    private String compactResponse(String path, String body) throws Exception {
        if (path.endsWith("/exchangeInfo")) {
            JSONArray raw = new JSONObject(body).getJSONArray("symbols"), result = new JSONArray();
            for (int i = 0; i < raw.length(); i++) {
                JSONObject item = raw.getJSONObject(i);
                if (!"USDT".equals(item.optString("quoteAsset"))) continue;
                JSONObject row = new JSONObject();
                for (String key : new String[]{"symbol", "status", "quoteAsset", "baseAsset", "contractType", "isSpotTradingAllowed"}) if (item.has(key)) row.put(key, item.get(key));
                result.put(row);
            }
            return new JSONObject().put("symbols", result).toString();
        }
        if (path.endsWith("/ticker/24hr") || path.endsWith("/ticker/price")) {
            JSONArray raw = new JSONArray(body), result = new JSONArray();
            for (int i = 0; i < raw.length(); i++) {
                JSONObject item = raw.getJSONObject(i);
                if (!item.optString("symbol").endsWith("USDT")) continue;
                JSONObject row = new JSONObject();
                for (String key : (path.endsWith("/ticker/price") ? new String[]{"symbol", "price"} : new String[]{"symbol", "lastPrice", "priceChangePercent", "quoteVolume", "highPrice", "lowPrice"})) row.put(key, item.get(key));
                result.put(row);
            }
            return result.toString();
        }
        return body;
    }
    private String exportBody = "";
    private void serviceRequest(String id, String address, String token, String method, String body) {
        network.execute(() -> {
            HttpsURLConnection c = null;
            try {
                c = (HttpsURLConnection)new URL(address).openConnection();
                c.setConnectTimeout(20000); c.setReadTimeout(65000); c.setInstanceFollowRedirects(false);
                c.setRequestMethod(method); c.setRequestProperty("Accept", "application/json");
                if (!token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
                if ("POST".equals(method)) {
                    c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json");
                    try (java.io.OutputStream out = c.getOutputStream()) { out.write(body.getBytes(java.nio.charset.StandardCharsets.UTF_8)); }
                }
                int code = c.getResponseCode();
                try (InputStream in = code < 400 ? c.getInputStream() : c.getErrorStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    if (in == null) throw new Exception("HTTP " + code);
                    byte[] buffer = new byte[8192]; int count;
                    while ((count = in.read(buffer)) != -1) { out.write(buffer, 0, count); if (out.size() > 4000000) throw new Exception("Yanıt çok büyük"); }
                    String result = out.toString("UTF-8");
                    if (code >= 400) { String message = "HTTP " + code; try { message += " • " + new JSONObject(result).optString("error"); } catch (Exception ignored) {} throw new Exception(message); }
                    complete(id, result, "");
                }
            } catch (Exception e) { complete(id, "", e.getMessage() == null ? "Servis hatası" : e.getMessage()); }
            finally { if (c != null) c.disconnect(); }
        });
    }
    @Override protected void onActivityResult(int request, int result, android.content.Intent data) {
        super.onActivityResult(request, result, data);
        if (request == 700 && result == RESULT_OK && data != null && data.getData() != null) {
            try (java.io.OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out != null) out.write(exportBody.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            } catch (Exception e) { android.widget.Toast.makeText(this, "Dosya kaydedilemedi", android.widget.Toast.LENGTH_LONG).show(); }
        }
        exportBody = "";
    }
    public final class MarketBridge {
        @JavascriptInterface public void service(String id, String origin, String path, String token, String method, String body) {
            if (destroyed || id == null || !id.matches("[0-9]{1,10}")) return;
            if (origin == null || !origin.matches("https://[a-zA-Z0-9.-]+(:[0-9]{1,5})?") || path == null || !path.matches("/(health|api/(state|alerts|events|radar|paper|chat|news|whales))") || !("GET".equals(method) || "POST".equals(method)) || token == null || token.length() > 512 || token.contains("\r") || token.contains("\n") || body == null || body.length() > 1000000) {
                complete(id, "", "Geçersiz servis isteği"); return;
            }
            serviceRequest(id, origin + path, token, method, body);
        }
        @JavascriptInterface public void publicData(String id, String kind) {
            String url;
            if ("sentiment".equals(kind)) url = "https://api.alternative.me/fng/?limit=7";
            else if ("okx".equals(kind)) url = "https://www.okx.com/api/v5/market/tickers?instType=SPOT";
            else if ("coinbase".equals(kind)) url = "https://api.coinbase.com/v2/exchange-rates?currency=BTC";
            else { complete(id, "", "Bilinmeyen veri kaynağı"); return; }
            serviceRequest(id, url, "", "GET", "");
        }
        @JavascriptInterface public void exportFile(String name, String mime, String body) {
            if (name == null || !name.matches("[A-Za-z0-9._-]{1,100}") || body == null || body.length() > 2000000 || !("text/csv".equals(mime) || "application/json".equals(mime) || "text/plain".equals(mime))) return;
            runOnUiThread(() -> { if (destroyed) return; exportBody = body; android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT); intent.addCategory(android.content.Intent.CATEGORY_OPENABLE); intent.setType(mime); intent.putExtra(android.content.Intent.EXTRA_TITLE, name); startActivityForResult(intent, 700); });
        }
        @JavascriptInterface public void enableNotifications() {
            runOnUiThread(() -> { if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 701); });
        }
        @JavascriptInterface public void notify(String title, String text) {
            if (destroyed || title == null || text == null) return;
            if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
            android.app.NotificationManager manager = getSystemService(android.app.NotificationManager.class);
            manager.createNotificationChannel(new android.app.NotificationChannel("prism-alerts", "Prism alarmları", android.app.NotificationManager.IMPORTANCE_DEFAULT));
            android.app.Notification n = new android.app.Notification.Builder(MainActivity.this, "prism-alerts").setSmallIcon(com.quantdesk.prism.R.drawable.ic_prism).setContentTitle(title.substring(0, Math.min(100, title.length()))).setContentText(text.substring(0, Math.min(300, text.length()))).setAutoCancel(true).build();
            manager.notify((int)(System.currentTimeMillis() % Integer.MAX_VALUE), n);
        }

        @JavascriptInterface public void request(String id, String market, String path) {
            if (destroyed || id == null || !id.matches("[0-9]{1,10}")) return;
            if (!path.matches("/(api/v3|fapi/v1)/(time|exchangeInfo|klines|ticker/24hr|ticker/price|depth|premiumIndex|openInterest)(\\?[A-Za-z0-9=&]+)?") || !(market.equals("spot") || market.equals("futures")) || (market.equals("spot") != path.startsWith("/api/v3/"))) {
                complete(id, "", "İzin verilmeyen veri isteği"); return;
            }
            network.execute(() -> {
                HttpsURLConnection connection = null;
                try {
                    String host = market.equals("spot") ? "https://data-api.binance.vision" : "https://fapi.binance.com";
                    connection = (HttpsURLConnection) new URL(host + path).openConnection();
                    connection.setConnectTimeout(20000); connection.setReadTimeout(20000);
                    connection.setInstanceFollowRedirects(false);
                    connection.setRequestProperty("Accept", "application/json");
                    int code = connection.getResponseCode();
                    if (code != 200) throw new Exception("HTTP " + code + ((code == 429 || code == 418) ? " — istek sınırı" : " — veri erişimi başarısız"));
                    try (InputStream stream = connection.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                        byte[] bytes = new byte[8192]; int count;
                        while ((count = stream.read(bytes)) != -1) { output.write(bytes, 0, count); if (output.size() > 32000000) throw new Exception("Yanıt sınırı aşıldı"); }
                        complete(id, compactResponse(path, output.toString("UTF-8")), "");
                    }
                } catch (Exception error) { complete(id, "", error.getMessage() == null ? "Bağlantı başarısız" : error.getMessage()); }
                finally { if (connection != null) connection.disconnect(); }
            });
        }
    }
    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onDestroy() { destroyed = true; network.shutdownNow(); web.removeJavascriptInterface("MarketNative"); web.destroy(); super.onDestroy(); }
}
