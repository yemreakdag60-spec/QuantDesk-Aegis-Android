'use strict';
// Quote updates never move the original signal's entry or targets.
const liveQuotes=new Map();
window.PrismLive={quotes:liveQuotes};
let liveBusy=false,liveError='',liveSequence=0,livePaused=false,lastQuoteBatch=0;
const liveKey=(market,symbol)=>market+':'+symbol;
function liveMetrics(s){
 const q=liveQuotes.get(liveKey(s.market,s.symbol));
 if(!q)return {ready:false,text:liveError||'Güncel fiyat bekleniyor',q:null};
 const fresh=Date.now()-q.at<=45000,lower=s.entry-s.atr*.4,upper=s.entry+s.atr*.4;
 const risk=(q.price-s.stop)*s.dir,reward=(s.tp1-q.price)*s.dir;
 const fees=q.price*((s.market==='spot'?.001:.0005)*2+.0004);
 const netRR=risk>0?(reward-fees)/(risk+fees):null;
 const valid=E.eligible(s,state.settings.threshold),inZone=q.price>=lower&&q.price<=upper;
 let text=!fresh?'Veri eski — giriş kapalı':!valid?'Analiz koşulları uygun değil':!inZone?'Giriş aralığının dışında':reward<=0?'İlk hedef aşılmış':risk<=0?'Stop seviyesi aşılmış':netRR<.9?'Güncel risk/getiri yetersiz':'Giriş aralığında • yeniden doğrula';
 return {q,fresh,lower,upper,netRR,ready:fresh&&valid&&inZone&&risk>0&&reward>0&&netRR>=.9,text,gap:(q.price/s.entry-1)*100,tpGap:reward/q.price*100,slGap:risk/q.price*100};
}
function liveBox(s){const m=liveMetrics(s);return `<div class="live-box" data-live-symbol="${s.symbol}" data-live-market="${s.market}">${liveBody(s,m)}</div>`;}
function liveBody(s,m){return `<div class="live-top"><span><i class="live-dot ${m.fresh?'fresh':''}"></i> GÜNCEL FİYAT</span><b>${m.q?price(m.q.price):'—'}</b></div><div class="live-status ${m.ready?'green':'yellow'}">${escapeHTML(m.text)}</div><div class="live-grid"><div><small>GİRİŞ ARALIĞI</small><b>${price(s.entry-s.atr*.4)} – ${price(s.entry+s.atr*.4)}</b></div><div><small>REFERANSA UZAKLIK</small><b>${m.q?num(m.gap)+'%':'—'}</b></div><div><small>TP1’E MESAFE</small><b>${m.q?num(m.tpGap)+'%':'—'}</b></div><div><small>GÜNCEL NET R/G</small><b>${m.netRR!=null?num(m.netRR):'—'}</b></div></div><div class="live-foot">${m.q?'Fiyat alındı: '+new Date(m.q.at).toLocaleTimeString('tr-TR')+' • '+age(m.q.at)+' önce':'Bağlantı bekleniyor'} · ${m.q?.source==='WebSocket'?'WebSocket akışı':'REST yedek · 5 sn'}</div>`;}
const originalCard=card;
card=function(s){const html=originalCard(s);return html.replace('</article>',liveBox(s)+'</article>');};
const originalDetail=renderDetail;
renderDetail=function(s){originalDetail(s);const container=$('#detail-content');container.querySelector('.detail-levels').insertAdjacentHTML('afterend',liveBox(s));};
const originalRadar=radar;
radar=function(){return `<section class="live-banner"><div><strong>Canlı giriş takibi</strong><p>Son fiyat değişir; giriş referansı ve hedefler tarama anına aittir.</p></div><button id="live-refresh" class="subtle">Fiyatları yenile ↻</button><span id="live-health">Bağlantı bekleniyor</span></section>`+originalRadar();};
function updateLiveBoxes(){
 $$('[data-live-symbol]').forEach(el=>{const s=el.closest('dialog')&&state.selected?.symbol===el.dataset.liveSymbol&&state.selected?.market===el.dataset.liveMarket?state.selected:state.signals.find(x=>x.symbol===el.dataset.liveSymbol&&x.market===el.dataset.liveMarket);if(s)el.innerHTML=liveBody(s,liveMetrics(s));});
 const health=$('#live-health');if(health)health.textContent=livePaused?'Uygulama görünür olunca devam eder':liveError?'Fiyat alınamadı: '+liveError:lastQuoteBatch?'Son yenileme '+age(lastQuoteBatch)+' önce':'Bağlantı bekleniyor';
 const q=liveQuotes.get(liveKey(state.market,state.symbol));
 const el=$('.chart-top .price');if(el&&q){el.innerHTML=price(q.price)+`<small class="${Date.now()-q.at<=45000?'green':'yellow'}">${Date.now()-q.at<=45000?'Güncel fiyat':'VERİ ESKİ'} · ${age(q.at)} önce</small>`;}
}
async function livePoll(){
 if(liveBusy||document.hidden)return;
 const market=state.market,sequence=++liveSequence;
 liveBusy=true;
 try{
  const raw=await api('ticker/price',{},market);
  if(!Array.isArray(raw))throw Error('Fiyat listesi geçersiz');
  if(market!==state.market||sequence!==liveSequence)return;
  const now=Date.now();let count=0;
  for(const r of raw){const p=+r.price;if(!/^[A-Z0-9]{3,24}USDT$/.test(r.symbol)||!Number.isFinite(p)||p<=0)continue;const previous=liveQuotes.get(liveKey(market,r.symbol));if(previous?.source!=='WebSocket'||now-previous.at>10000)liveQuotes.set(liveKey(market,r.symbol),{price:p,at:now,source:'REST'});count++;}
  if(!count)throw Error('USDT fiyatı bulunamadı');
  liveError='';lastQuoteBatch=now;
  updateLiveBoxes();drawChart();
 }catch(e){if(market===state.market){liveError=/451/.test(e.message)?'Bu ağ için borsa erişim kısıtı (451)':e.message;updateLiveBoxes();}}
 finally{liveBusy=false;}
}
const originalRender=render;
render=function(){originalRender();updateLiveBoxes();};
const originalChangeMarket=changeMarket;
changeMarket=async function(market){if(market!==state.market){liveSequence++;lastQuoteBatch=0;liveError='';}await originalChangeMarket(market);await livePoll();};
document.addEventListener('click',e=>{if(e.target.closest('#live-refresh'))livePoll();});
document.addEventListener('visibilitychange',()=>{livePaused=document.hidden;if(!document.hidden)livePoll();});
setInterval(livePoll,5000);
setInterval(updateLiveBoxes,1000);
render();livePoll();
