# Kişisel analiz sunucusu

Tek kullanıcı için Node.js 24 hizmeti. Gerçek borsa emri/bakiye/para transferi ucu yoktur. `/api/paper` yalnız analiz senaryolarının sanal takibidir. Telefon kapalıyken hizmetin çalışması için kendi bilgisayarınızın veya sunucunuzun açık kalması gerekir.

## Kurulum

1. `.env.example` dosyasını `.env` olarak kopyalayın.
2. `openssl rand -hex 32` ile özel bir erişim anahtarı oluşturup PRISM_TOKEN alanına yazın.
3. `mkdir -p data` ve `sudo chown 1000:1000 data` ile Docker'ın Node kullanıcısına yazma izni verin.
4. `docker compose up -d --build` komutunu çalıştırın.
5. Kendi alan adınızda HTTPS reverse proxy kurun; `Caddyfile.example` örneğini uyarlayın.
6. Uygulamada Araştırma → Bulut & alarmlar bölümüne HTTPS kök adresini ve PRISM_TOKEN anahtarını girin.

Docker olmadan `.env` içinde yazılabilir DATA_DIR ve BIND=127.0.0.1 belirleyip `node --env-file=.env server.cjs` çalıştırabilirsiniz. Sürekli çalışma için işletim sisteminin servis yöneticisini kullanın. Bu paket hazır uzak sunucu/alan adı sağlamaz.

## İsteğe bağlı sağlayıcılar

- **AI:** Ollama kurun ve seçtiğiniz modeli indirin. OLLAMA_MODEL / OLLAMA_URL tanımlayın. Docker örneği host.docker.internal kullanır. Model APK'ya gömülü değildir; bağlantı yoksa cevap üretilmez.
- **Bildirim:** TELEGRAM_BOT_TOKEN ve TELEGRAM_CHAT_ID sunucunun kendi Telegram bildirimini göndermesini sağlar. Bu teslimde gerçek hesaba mesaj gönderilmedi. FCM/APNs push yoktur.
- **Balina:** Whale Alert uyumlu abonelik/anahtar gerektirir. API anahtarı olmadan zincir üstü transfer üretmez.
- **Haber:** CoinDesk/Cointelegraph RSS başlık/kaynak/tarih, 5 dakikalık önbellek.

`/api/radar` telefon kapalıyken tarama; `/api/alerts` kalıcı fiyat alarmı; `/api/events` olaylar; `/api/state` sürüm korumalı favori/çizim/model eşitleme; `/api/chat` gerçek Ollama cevabı. Sunucu radarı varsayılan kapalı; uygulamadan başlatılır. Cihaz ve sunucu senaryo portföyleri ayrıdır. Terminaldeki kişisel JSON filtreleri ve öğrenilmiş ATR ayarı cihaz analizine uygulanır; sunucu radarı standart motoru kullanır.

Veri `data/state.json` içinde atomik yazılır; düzenli yedekleyin. Tek süreç kullanın, aynı dosya üzerinde birden fazla sunucu çalıştırmayın. .env ve erişim anahtarını depoya yüklemeyin.

WebSocket tekrar bağlantısı ve REST yedeği vardır. Kesintide kaçan TP/SL dokunuşları uydurulmaz. Yaklaşık sanal likidasyon sabit %0,5 bakım marjıdır, gerçek borsa kademeli hesaplaması değildir. Fonlama yalnız gözlenen dönem geçişlerinde yaklaşık işlenir. Sonradan eksiksiz piyasa geçmişi üretilmez.
