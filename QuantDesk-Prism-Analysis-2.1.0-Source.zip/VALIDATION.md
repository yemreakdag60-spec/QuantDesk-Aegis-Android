# Prism Analiz 2.1.0 doğrulama

- 40 Node testi: gösterge hesapları, geçersiz/eski veri, özel periyot hizası, TP1/TP2 ve tek kapanış muhasebesi, ücret/kayma, yaklaşık marjin, eğitim/test ayrımı, walk-forward pencereleri, güvenli filtre kuralları, sunucu yetkilendirmesi/kayıt sürümleri/alarmlar ve gerçek emir uçlarının bulunmaması.
- Playwright/Chromium testi: WebSocket olaylarının ekranı güncellemesi, oluşan mum, çizim, replay, sanal TP1/TP2, backtest, walk-forward, altı zaman dilimi, kişisel filtre, özel 25 dakika, yapılandırılmamış sunucu hatası, otomatik tarama, masaüstü/mobil taşma kontrolü. Sağlayıcı yanıtları kontrollü örnek veridir.
- Java 17 / Gradle 8.9 / SDK 35 ile assembleDebug ve lintDebug çalıştırıldı. Sonuç ve APK hash'i BUILD-RESULT.txt dosyasında.
- APK içindeki tüm varlıkların teslim edilen kaynaklarla byte eşitliği ve APK imzası kontrol edildi.

Testlerin kapsamı: fiziksel Android cihaz/emülatör üzerinde kurulum denenmedi. Gerçek kullanıcı hesabı veya para kullanılmadı; zaten bu sürüm gerçek emir göndermez. AI/Whale Alert/Telegram için kullanıcı hesabı bağlanmadı; sunucu dış makineye dağıtılmadı. Arayüz test ekranları canlı piyasa performansının kanıtı değildir. GitHub workflow'unun tamamı GitHub üzerinde bu oturumda çalıştırılmadı; yerel derleme başarılı ve action referansları doğrulandı.
