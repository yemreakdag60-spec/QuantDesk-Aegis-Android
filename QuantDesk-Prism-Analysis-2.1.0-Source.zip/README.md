# Prism Analiz 2.1.0

Emre Akdağ'ın son kapsam düzeltmesi: **yalnız analiz, gerçek alım satım yok.** Android uygulaması, analiz motorları ve isteğe bağlı kişisel sunucu kaynakları birlikte verilir. Borsa API anahtarı girişi, bakiye, gerçek emir gönderme ve ödeme/para transferi kodu bulunmaz. Sanal senaryo takibi analizlerin TP/SL sonuçlarını ölçmek içindir.

## Kurulum

Android 8.0+; güncel Android System WebView gerekir. `Prism-Analiz-2.1.0.apk` doğrudan kurulabilir. Paket kimliği `com.quantdesk.prism.analysis`; eski uygulamaları silmeden ayrı kurulur. Eski uygulamadaki veriler otomatik taşınmaz. Teslim debug/test imzalıdır, mağaza yayını değildir.

1. Uygulamayı aç, Spot veya Vadeli analiz seç. Canlı veriler halka açık borsa uçlarından alınır.
2. Radar, otomatik taramayı tamamlandıktan 120 saniye sonra tekrarlar. Ayarlarda 30/60/120/300 saniye seçilebilir. Ağ kısıtı varsa açık hata gösterilir.
3. Kartta son fiyat, giriş referansı/bandı, hedef uzaklığı ve güncel net risk/getiri görünür. Sinyalin hedefleri fiyatı izleyerek sonradan kaydırılmaz.
4. Terminal: oluşan mum, çizimler, RSI/Bollinger, hacim, replay, yaklaşık POC, ADX/DMI, Stoch RSI, VWAP, MACD, mum biçimi ve altı zaman dilimi matrisi.
5. Araştırma: ayrı eğitim/test backtest, walk-forward, dört parite mum görünümü, piyasa akışı, duyarlılık ve isteğe bağlı gerçek AI bağlantısı.
6. Senaryo takibi: sanal giriş yeniden doğrulanır; TP1 yarısını kapatır, kalan stop girişe taşınır, TP2 kalanını kapatır. Gerçek emir oluşturulmaz.

## Tam kaynak ve GitHub

ZIP adını değiştirmeden depo köküne yükleyin: `QuantDesk-Prism-Analysis-2.1.0-Source.zip`.
Teslim edilen `Prism-Analiz-2.1.0-android.yml` içeriğini **`.github/workflows/android.yml`** dosyasına koyun. Actions → **Build Prism Analysis 2.1 APK** → Run workflow.
Başarılı çalışmanın Artifacts bölümündeki `Prism-Analiz-2.1.0-APK` paketini indirin. Eski Autopilot/Aegis workflow'ları farklı işlerdir; bu iş akışını seçin. ZIP açılmış proje olarak da derlenebilir.

Java 17, Gradle 8.9, SDK 35 / build-tools 34.0.0:

```sh
node --test tests/engine.test.cjs tests/quant.test.cjs tests/analytics.test.cjs tests/server.test.cjs tests/monitor.test.cjs
gradle --no-daemon :app:assembleDebug :app:lintDebug
```

Tarayıcı testi için Playwright kurulur; `node tests/pro-ui.test.cjs`. Kendi Chromium ikilisi varsa `CHROMIUM_PATH` ile yolu verilir. Ekran görüntüleri örnek veriyle oluşturulan arayüz testleridir.

## Sunucu gerekir mi?

Cihaz açıkken temel canlı analiz için gerekmez. Telefon kapalıyken 7/24 tarama, kayıt, Telegram alarmı, bulut eşitleme ve Ollama AI için sürekli çalışan kendi bilgisayarınız veya sunucunuz gerekir. Sunucu bu teslimde uzak bir makineye kurulmuş değildir. Kurulum: `server/README.md`.

## Sınırlar

`OZELLIK-DURUMU.md`, doğrudan çalışan, dış bağlantı isteyen ve tamamlanmamış özelliklerin tamamını ayırır. Pine Script motoru ve tüm ticari uygulamaların bütün kapalı özellikleri kopyalanmış değildir. Kazanma olasılığı doğrulanmadan yüzde sunulmaz; uygun sinyal yokken iki sahte fırsat üretilmez.
